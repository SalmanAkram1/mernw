const admin = require('../utils/firebaseUtility/firebaseUtility');
const logger = require('../utils/logger');

const getAuthToken = (req, res, next) => {
  logger.debug('server.utils.firebaseUtility.getAuthToken.start');
  if (
    req.headers.authorization &&
    req.headers.authorization.split(' ')[0] === 'Bearer'
  ) {
    req.authToken = req.headers.authorization.split(' ')[1];
    logger.debug('server.utils.firebaseUtility.getAuthToken.success');
  } else {
    req.authToken = null;
    logger.debug('server.utils.firebaseUtility.getAuthToken.authTokenNA');
  }
  logger.debug('server.utils.firebaseUtility.getAuthToken.end');
  next();
};

const isAuthenticated = (req, res, next) => {
  logger.debug('server.utils.firebaseUtility.isAuthenticated.start');
  getAuthToken(req, res, async () => {
    try {
      const { authToken } = req;
      const userInfo = await admin.auth().verifyIdToken(authToken);
      req.authId = userInfo.uid;
      logger.debug('server.utils.firebaseUtility.isAuthenticated.success');
      logger.debug('server.utils.firebaseUtility.isAuthenticated.end');
      return next();
    } catch (e) {
      logger.error(`server.utils.firebaseUtility.isAuthenticated.error:${e}`);
      return res
        .status(401)
        .send({ error: 'You are not authorized to make this request' });
    }
  });
};

module.exports = isAuthenticated;
