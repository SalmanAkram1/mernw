import sgMail from '@sendgrid/mail';
import getEmailTemplate from './emailTemplates.js';
import logger from '../logger.js';

// using Twilio SendGrid's v3 Node.js Library
// https://github.com/sendgrid/sendgrid-nodejs

// const emailInfo = {
//   to: 'Raz.Meridor@gmail.com',
//   firstName: 'Raz',
//   templateType: 'newRunnerInvitation', // 'runnerWelcome', 'newRunnerInvitation' & 'trainerWelcome'
//   trainerName: 'Nir',
//   runningGroupName: 'Green Runners',
//   inviteURL: 'https://sub.cx/sign-up/1234567890',
// };

const sendEmail = (emailInfo) => {
  logger.debug('server.utils.transactionalEmail.sendEmail.start');
  sgMail.setApiKey('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');
  // sgMail.setApiKey(process.env.SENDGRID_API_KEY);
  const emailTemplate = getEmailTemplate(emailInfo);
  const msg = {
    to: emailInfo.to, // Change to your recipient
    from: 'info@sub.cx', // Change to your verified sender
    subject: emailTemplate.subject,
    // text: 'and easy to do anywhere, even with Node.js',
    html: emailTemplate.body,
  };

  sgMail
    .send(msg)
    .then(() => {
      logger.debug('server.utils.transactionalEmail.sendEmail.success');
    })
    .catch((error) => {
      logger.error(`server.utils.transactionalEmail.sendEmail.error.${error}`);
      console.error(error);
    });

  logger.debug('server.utils.transactionalEmail.sendEmail.end');
};

export default sendEmail;
