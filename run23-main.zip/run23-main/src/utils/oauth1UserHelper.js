import crypto from 'crypto';
import oauth1a from 'oauth-1.0a';
import axios from 'axios';
import logger from './logger.js';

class Oauth1UserHelper {
  constructor(garminUserAccessToken, garminUserAccessSecret) {
    this.TOKENKEY = garminUserAccessToken;
    this.TOKENSECRET = garminUserAccessSecret;
    this.CONSUMERKEY = process.env.GARMIN_CONSUMER_KEY;
    this.CONSUMERSECRET = process.env.GARMIN_CONSUMER_SECRET;
  }

  getAuthHeaderForRequest(request) {
    const oauth = oauth1a({
      consumer: { key: this.CONSUMERKEY, secret: this.CONSUMERSECRET },
      signature_method: 'HMAC-SHA1',
      hash_function(base_string, key) {
        return crypto.createHmac('sha1', key).update(base_string).digest('base64');
      },
    });

    const authorization = oauth.authorize(request, {
      key: this.TOKENKEY,
      secret: this.TOKENSECRET,
    });

    return oauth.toHeader(authorization);
  }

  async getGarminUserId() {
    logger.debug(`server.utils.oauth1UserHelper.getGarminUserId.start`);
    const request = {
      url: 'https://apis.garmin.com/wellness-api/rest/user/id',
      method: 'GET',
    };

    const authHeader = this.getAuthHeaderForRequest(request);
    const response = await axios
      .get(request.url, { headers: authHeader })
      .then((res) => res.data.userId)
      .catch(function (error) {
        logger.error(`server.utils.oauth1UserHelper.getGarminUserId:`);
        if (error.response) {
          // Request made and server responded
          logger.error(JSON.stringify(error.response.data));
          logger.error(JSON.stringify(error.response.status));
          logger.error(JSON.stringify(error.response.headers));
        } else if (error.request) {
          // The request was made but no response was received
          logger.error(JSON.stringify(error.request));
        } else {
          // Something happened in setting up the request that triggered an Error
          logger.error(JSON.stringify(error.message));
        }
      });
    logger.debug(`server.utils.oauth1UserHelper.getGarminUserId.end`);
    return response;
  }

  async syncGarminWorkout(workoutBody) {
    logger.debug(`server.utils.oauth1UserHelper.syncGarminWorkout.start`);
    const request = {
      url: 'https://apis.garmin.com/training-api/workout',
      method: 'POST',
    };
    const authHeader = this.getAuthHeaderForRequest(request);
    const respose = await axios
      .post(request.url, workoutBody, {
        headers: authHeader,
      })
      .catch(function (error) {
        logger.error(`server.utils.oauth1UserHelper.SyncGarminWorkout:`);
        if (error.response) {
          // Request made and server responded
          logger.error(JSON.stringify(error.response.data));
          logger.error(JSON.stringify(error.response.status));
          logger.error(JSON.stringify(error.response.headers));
        } else if (error.request) {
          // The request was made but no response was received
          logger.error(JSON.stringify(error.request));
        } else {
          // Something happened in setting up the request that triggered an Error
          logger.error(JSON.stringify(error.message));
        }
      });
    logger.debug(`server.utils.oauth1UserHelper.syncGarminWorkout.end`);
    return respose;
  }
}

export default Oauth1UserHelper;
