import getWorkoutTemplate from './Templates/workoutTemplate.js';
import getWarmupWorkoutTemplate from './Templates/warmupWorkoutStepTemplate.js';
import getCooldownWorkoutTemplate from './Templates/cooldownWorkoutTemplate.js';
import getNewStep from './Templates/workoutStepTemplate.js';
import getNewRepeatStep from './Templates/workoutRepeatStepTemplate.js';

class Running {
  constructor(workoutName, description = 'This workout was created using https://sub.cx') {
    this.data = getWorkoutTemplate(workoutName, description);
    this.workoutSteps = [];
    this.workoutInnerRepeatSteps = [];
  }

  get name() {
    return this.data.workoutName;
  }

  set name(name) {
    this.data.workoutName = `${name}`;
  }

  get description() {
    return this.data.description;
  }

  set description(description) {
    this.data.description = description;
  }

  get workoutId() {
    return this.data.workoutId;
  }

  set workoutId(workoutId) {
    this.data.workoutId = workoutId;
  }

  isValid() {
    // TODO - conditional check
    return true;
  }

  addStep(
    intensity,
    durationType,
    durationValue,
    durationValueType,
    targetType = null,
    targetValueLow = null,
    targetValueHigh = null,
  ) {
    const newStep = getNewStep(
      intensity,
      durationType,
      durationValue,
      durationValueType,
      targetType,
      targetValueLow,
      targetValueHigh,
    );
    this.workoutSteps.push(newStep);
  }

  addInnerRepeatStep(
    intensity,
    durationType,
    durationValue,
    durationValueType,
    targetType = null,
    targetValueLow = null,
    targetValueHigh = null,
  ) {
    const newStep = getNewStep(
      intensity,
      durationType,
      durationValue,
      durationValueType,
      targetType,
      targetValueLow,
      targetValueHigh,
    );
    this.workoutInnerRepeatSteps.push(newStep);
  }

  addRepeatStep(repeatValue) {
    const newRepeatStep = getNewRepeatStep(repeatValue);
    this.workoutInnerRepeatSteps.forEach((step) => newRepeatStep.steps.push(step));
    this.workoutInnerRepeatSteps = [];
    this.workoutSteps.push(newRepeatStep);
  }

  getMainWorkoutJson(workout) {
    workout.steps.forEach((step) => {
      if (step.repeatValue) {
        this.addInnerRepeatStep(
          step.steps[0].intensity,
          step.steps[0].durationType,
          step.steps[0].durationValue,
          step.steps[0].durationValueType,
          step.steps[0].runnerPace &&
            step.steps[0].runnerPace !== 'EASY' &&
            step.steps[0].runnerPace !== 'REST'
            ? 'PACE'
            : null, // step.steps[0].targetType,
          step.steps[0].runnerPace &&
            step.steps[0].runnerPace !== 'EASY' &&
            step.steps[0].runnerPace !== 'REST'
            ? 1000 / (step.steps[0].runnerPace - 10)
            : null, // step.steps[0].targetValueLow,
          step.steps[0].runnerPace &&
            step.steps[0].runnerPace !== 'EASY' &&
            step.steps[0].runnerPace !== 'REST'
            ? 1000 / (step.steps[0].runnerPace + 10)
            : null, // step.steps[0].targetValueHigh,
        );

        this.addInnerRepeatStep(
          step.steps[1].intensity,
          step.steps[1].durationType,
          step.steps[1].durationValue,
          step.steps[1].durationValueType,
          step.steps[1].runnerPace &&
            step.steps[1].runnerPace &&
            (step.steps[1].runnerPace !== 'REST') !== 'EASY'
            ? 'PACE'
            : null, // step.steps[1].targetType,
          step.steps[1].runnerPace &&
            step.steps[1].runnerPace &&
            (step.steps[1].runnerPace !== 'REST') !== 'EASY'
            ? 1000 / (step.steps[1].runnerPace - 10)
            : null, // step.steps[1].targetValueLow,
          step.steps[1].runnerPace &&
            step.steps[1].runnerPace !== 'EASY' &&
            step.steps[1].runnerPace !== 'REST'
            ? 1000 / (step.steps[1].runnerPace + 10)
            : null, // step.steps[1].targetValueHigh,
        );
        this.addRepeatStep(step.repeatValue);
      } else {
        this.addStep(
          step.intensity,
          step.durationType,
          step.durationValue,
          step.durationValueType,
          step.runnerPace && step.runnerPace !== 'EASY' && step.runnerPace !== 'REST'
            ? 'PACE'
            : null, // step.targetType,
          step.runnerPace && step.runnerPace !== 'EASY' && step.runnerPace !== 'REST'
            ? 1000 / (step.runnerPace - 10)
            : null, // step.targetValueLow,
          step.runnerPace && step.runnerPace !== 'EASY' && step.runnerPace !== 'REST'
            ? 1000 / (step.runnerPace + 10)
            : null, // step.targetValueHigh,
        );
      }
      if (step.intensity === 'WARMUP') this.addStep('WARMUP', 'OPEN');
    });
    return this.toJson();
  }

  addWarmupStep(distance = null) {
    this.workoutSteps.unshift(getWarmupWorkoutTemplate(distance));
  }

  addCooldownStep(distance = null) {
    this.workoutSteps.push(getCooldownWorkoutTemplate(distance));
  }

  toJson() {
    this.workoutSteps.forEach((step, i) => {
      step.stepOrder = i + 1;
      if (step.type === 'WorkoutRepeatStep') {
        step.steps.forEach((innerRepeatStep, j) => {
          innerRepeatStep.stepOrder = step.stepOrder * 10 + j;
        });
      }
      this.data.steps.push(step);
    });

    return this.data;
  }

  toString() {
    return `${JSON.stringify(this.data, null, 2)}`;
  }
}
export default Running;
