export default (workoutName, description = null) => ({
  workoutName,
  description,
  sport: 'RUNNING',
  steps: [],
});
