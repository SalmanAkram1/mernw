export default (distance = null) => ({
  type: 'WorkoutStep',
  stepOrder: 1,
  intensity: 'WARMUP',
  description: null,
  durationType: distance ? 'DISTANCE' : 'OPEN',
  durationValue: distance,
  durationValueType: null,
  targetType: null,
  targetValue: null,
  targetValueLow: null,
  targetValueHigh: null,
  targetValueType: null,
});
