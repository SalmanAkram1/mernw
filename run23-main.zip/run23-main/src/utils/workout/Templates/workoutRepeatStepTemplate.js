export default (repeatValue) => ({
  type: 'WorkoutRepeatStep',
  stepOrder: null,
  repeatType: 'REPEAT_UNTIL_STEPS_CMPLT',
  repeatValue,
  steps: [],
});
