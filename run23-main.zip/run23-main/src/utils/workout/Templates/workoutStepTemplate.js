const getDurationValue = (durationValue, durationValueType) => {
  if (durationValueType === 'KILOMETER') return durationValue * 1000;
  if (durationValueType === 'MINUTE') return durationValue * 60;
  return durationValue;
};

const getDurationValueType = (durationValueType) => {
  if (durationValueType === 'MINUTE') return null;
  return durationValueType;
};

export default (
  intensity,
  durationType,
  durationValue,
  durationValueType = null,
  targetType = null,
  targetValueLow = null,
  targetValueHigh = null,
) => ({
  type: 'WorkoutStep',
  stepOrder: null, // Int number
  intensity, // REST, WARMUP, COOLDOWN, RECOVERY, INTERVAL
  description: null,
  durationType, // TIME, DISTANCE, OPEN
  durationValue: getDurationValue(durationValue, durationValueType),
  durationValueType: getDurationValueType(durationValueType),
  targetType, // PACE
  targetValue: null,
  targetValueLow,
  targetValueHigh,
  targetValueType: null,
  strokeType: null,
  equipmentType: null,
  exerciseCategory: null,
  exerciseName: null,
  weightValue: null,
  weightDisplayUnit: null,
});
