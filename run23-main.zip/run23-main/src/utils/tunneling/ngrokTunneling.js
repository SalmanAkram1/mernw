import ngrok from 'ngrok';
import logger from '../logger.js';
import 'dotenv/config.js';

(async function () {
  const token = process.env.NGROK_TOKEN;

  const opts = {
    // proto: 'http', // http|tcp|tls, defaults to http
    addr: 4000, // port or network address, defaults to 80
    // auth: 'user:pwd', // http basic authentication for tunnel
    // subdomain: 'grunners', // reserved tunnel name https://alex.ngrok.io
    authtoken: token, // your authtoken from ngrok.com
    // region: 'us', // one of ngrok regions (us, eu, au, ap, sa, jp, in), defaults to us
    // configPath: '~/git/project/ngrok.yml', // custom path for ngrok config file
    // binPath: path => path.replace('app.asar', 'app.asar.unpacked'),
    // custom binary path, eg for prod in electron
    // onStatusChange: status => {}, // 'closed' - connection is lost, 'connected' - reconnected
    // onLogEvent: data => {}, // returns stdout messages from ngrok process
  };
  const url = await ngrok.connect(opts);

  //   await ngrok.authtoken(token);
  // const url = await ngrok.connect(5000);

  // const url = await ngrok.connect();
  logger.info(`server.tunnel.start.success.ngrok.url:${url}`);
})();
