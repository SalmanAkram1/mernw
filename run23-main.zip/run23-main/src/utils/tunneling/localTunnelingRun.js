// run localtunnel to expose local server to the internet

const runLocalTunnel = require('./localTunneling');

runLocalTunnel();
