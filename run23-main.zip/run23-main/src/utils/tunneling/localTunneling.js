const localtunnel = require('localtunnel');
const logger = require('../logger');

// run localtunnel to expose local server to the internet
module.exports = async () => {
  const tunnel = await localtunnel({
    // port: process.env.PORT || 4000,
    port: 4000,
    subdomain: 'run23',
  });

  logger.info(`server.tunnel.start.success.url:${tunnel.url}`);

  tunnel.on('request', (info) => {
    console.log(info);
  });

  tunnel.on('error', (err) => {
    logger.error(`server.tunnel.error: ${err}`);
  });

  tunnel.on('close', () => {
    logger.info('server.tunnel.close.success');
  });
};
