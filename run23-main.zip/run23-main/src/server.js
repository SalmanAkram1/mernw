import express from 'express';
import session from 'express-session';
import bodyParser from 'body-parser';
import grant from 'grant-express';
import mongoose from 'mongoose';
import cors from 'cors';
import logger from './utils/logger.js';
import dotenv from 'dotenv';
// const isAuthenticated = require('./middlewares/auth');
// import grantConfig from './config/grantConfig.json' assert { type: 'json' };
import grantConfig from '/etc/secrets/grantConfig.json' assert { type: 'json' };
import activityRouter from './routes/activityRouter.js';
import workoutRouter from './routes/workoutRouter.js';
import userRouter from './routes/userRouter.js';

dotenv.config();

// set up express
const app = express();
app.set('view engine', 'ejs');
app.set('views', './src/views');

app.use(bodyParser.json({ limit: '50mb' }));
app.use(bodyParser.urlencoded({ limit: '50mb', extended: true }));

app.use(cors());
app.use(
  session({
    secret: process.env.SESSION_SECRET,
    saveUninitialized: true,
    resave: true,
  }),
);

// set up mongoose
mongoose.connect(
  process.env.MONGODB_CONNECTION_STRING,
  {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  },
  (err) => {
    if (err) {
      logger.error(`server.MongoDB.connection.error:${err}`);
      throw err;
    }
    logger.info('server.MongoDB.connection.success');
  },
);

app.use((req, res, next) => {
  logger.debug(
    `server.url.(${req.originalUrl}).host.(${req.headers.host}).user-agent.(${req.headers['user-agent']})`,
  );
  next();
});

// app.use(isAuthenticated);

// // set up routes
app.use(grant(grantConfig));
// app.use('/user', require('./routes/userRouter'));
app.use('/activity', activityRouter);
app.use('/workout', workoutRouter);
app.use('/', userRouter);

// run the server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  logger.info('server.start.success');
  logger.info(`server.port.${PORT}`);
});
