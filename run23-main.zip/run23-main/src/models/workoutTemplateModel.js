import mongoose from 'mongoose';

const workoutTemplateSchema = new mongoose.Schema({
  trainerUserId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  workoutName: { type: String },
  description: { type: String },
  workoutNotes: { type: String },
  sport: { type: String, default: 'RUNNING' },
  steps: [{ type: Object }],
  subGroup: {type: String, default: 'General'}
});

export default mongoose.model('WorkoutTemplate', workoutTemplateSchema, 'workoutTemplates');

