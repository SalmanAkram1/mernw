import mongoose from 'mongoose';

const workoutSchema = new mongoose.Schema({
  runnerId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  trainerUserId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  dateObject: { type: Date },
  workout: {
    trainerUserId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    workoutName: { type: String },
    description: { type: String },
    workoutNotes: { type: String },
    sport: { type: String, default: 'RUNNING' },
    steps: [{ type: Object }],
  },
});

export default mongoose.model('Workout', workoutSchema, 'workouts');
