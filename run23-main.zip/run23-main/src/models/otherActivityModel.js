import mongoose from 'mongoose';

const otherActivitySchema = new mongoose.Schema({
  runnerId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  trainerUserId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  data: { type: Object },
});

export default mongoose.model('OtherActivity', otherActivitySchema, 'otherActivities');
