import mongoose from "mongoose";

const userSchema = new mongoose.Schema(
  {
    // _id: { type: String },
    trainerUserId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    runningGroup: { type: String }, //, required: true },
    subRunningGroup: { type: String },
    firstName: { type: String },
    lastName: { type: String },
    email: { type: String, lowercase: true }, // required: true, unique: true },
    mobile: { type: String, required: true },
    role: { type: String, required: true },
    basePace: { minutes: { type: Number }, seconds: { type: Number } },
    runsPerWeek: { type: Number },
    isActive: { type: Boolean },
    isRegistered: { type: Boolean, default: false },
    garminUserId: { type: String },
    garminUserAccessToken: { type: String },
    garminUserAccessSecret: { type: String },
    subGroups: { type: [String] },
    subGroup: { type: String, default: 'General' },
  },
  { timestamps: true },
);

export default mongoose.model('User', userSchema, 'users');
