import mongoose from 'mongoose';

// const summaryActivitySchema = new mongoose.Schema({
//   data: { type: Object },
// });

const summaryActivitySchema = new mongoose.Schema({
  runnerId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  trainerUserId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  userId: { type: String },
  userAccessToken: { type: String },
  summaryId: { type: String },
  activityId: { type: Number },
  activityName: { type: String },
  durationInSeconds: { type: Number },
  startTimeInSeconds: { type: Number },
  startTimeOffsetInSeconds: { type: Number },
  activityType: { type: String },
  averageHeartRateInBeatsPerMinute: { type: Number },
  averageRunCadenceInStepsPerMinute: { type: Number },
  averageBikeCadenceInRoundsPerMinute: { type: Number },
  averageSpeedInMetersPerSecond: { type: Number },
  averageSwimCadenceInStrokesPerMinute: { type: Number },
  averagePaceInMinutesPerKilometer: { type: Number },
  activeKilocalories: { type: Number },
  deviceName: { type: String },
  distanceInMeters: { type: Number },
  maxPaceInMinutesPerKilometer: { type: Object },
  maxSpeedInMetersPerSecond: { type: Number },
  maxRunCadenceInStepsPerMinute: { type: Number },
  maxBikeCadenceInRoundsPerMinute: { type: Number },
  maxHeartRateInBeatsPerMinute: { type: Number },
  numberOfActiveLengths: { type: Number },
  startingLatitudeInDegree: { type: Number },
  startingLongitudeInDegree: { type: Number },
  steps: { type: Number },
  totalElevationGainInMeters: { type: Number },
  totalElevationLossInMeters: { type: Number },
  Manual: { type: Boolean },
  isParent: { type: Boolean },
  parentSummaryId: { type: String },
});

export default mongoose.model('SummaryActivity', summaryActivitySchema, 'summaryActivities');
