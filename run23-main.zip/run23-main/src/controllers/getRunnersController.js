import User from '../models/userModel.js';
import logger from '../utils/logger.js';

const   getRunners = async (req, res) => {
  logger.debug('server.routes.userRouter.getRunners.start');

  try {
    // const isActive = req.body.isActive;
    // const trainerEmail = req.body.userEmail;

    // const allRunners = await User.find({ role: 'runner' });
    // const runnersList = isActive ? allRunners.filter((runner) => runner.isActive) : allRunners;

    const trainerUserId = req.body.trainerUserId;
    const runnerId = req.body.runnerId;

    let runnersList = [];
    if (trainerUserId) {
      runnersList = await User.find({ role: 'runner', trainerUserId });
    }
    if (runnerId) {
      runnersList = await User.find({ role: 'runner', runnerId });
    }

    const formatResponse = runnersList.map((user) => ({
      name: `${user.firstName} ${user.lastName}`,
      firstName: user.firstName,
      lastName: user.lastName,
      email: user.email,
      mobile: user.mobile,
      runnerId: user._id,
      basePace: user.basePace,
      runsPerWeek: user.runsPerWeek || 0,
      isActive: user.isActive,
      isRegistered: user.isRegistered,
      runningGroup: user.runningGroup || 'N/A',
      subGroup: user.subGroup,
      trainerUserId: user.trainerUserId,
    }));

    logger.debug(`server.routes.activityRouter.getRunners.end`);
    return res.status(200).json(formatResponse);
  } catch (error) {
    logger.debug(`server.routes.userRouter.getRunners.${error.message}`);
    return res.status(500).json({ message: error.message });
  }
};

export default getRunners;
