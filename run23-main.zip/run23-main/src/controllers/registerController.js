import User from '../models/userModel.js';
import logger from '../utils/logger.js';

import sendEmail from '../utils/transactionalEmails/sendEmail.js';

const sendAWelcomeEmail = (to, firstName, role) => {
  let emailInfo = { to, firstName };
  if (role === 'trainer') {
    emailInfo.templateType = 'trainerWelcome';
  } else {
    emailInfo.templateType = 'runnerWelcome';
  }
  sendEmail(emailInfo);
};

const registerUser = async (req, res) => {
  logger.info('server.routes.userRouter.registerUser.start');
  try {
    const { email, runningGroup, mobile, role, runnerId } = req.body;
    let { firstName, lastName } = req.body;
    if (!firstName) firstName = email;
    if (!lastName) lastName = '';
    logger.info(
      `server.routes.userRouter.registerUser:${JSON.stringify({
        firstName,
        lastName,
        email,
      })}`,
    );

    // const existingEmail = await User.findOne({ email });
    // if (existingEmail) {
    //   logger.info('server.routes.userRouter.registerUser.userAlreadyExists');
    //   return res
    //     .status(400)
    //     .json({ msg: 'error', value: 'An account with this email already exists.' });
    // }

    // // validate
    // if (!email || !mobile || !runningGroup || !role) {
    //   logger.info('server.routes.userRouter.registerUser.missingInputField');
    //   return res.status(400).json({ msg: 'error', value: 'Not all fields have been entered.' });
    // }

    let existingUser = await User.findOne({ _id: runnerId });
    if (existingUser) {
      logger.debug('server.routes.userRouter.registerUser.updateExistingUser.start');
      await User.updateOne(
        { _id: runnerId },
        {
          email,
          firstName,
          lastName,
          mobile,
          runningGroup,
          role,
          isActive: false,
          isRegistered: true,
        },
      );
      logger.debug(
        'server.routes.userRouter.registerUser.updateExistingUser.sendAWelcomeEmail.start',
      );
      sendAWelcomeEmail(email, firstName, role);
      logger.debug(
        'server.routes.userRouter.registerUser.updateExistingUser.sendAWelcomeEmail.end',
      );
      logger.debug('server.routes.userRouter.registerUser.updateExistingUser.success');
      return res.send({ msg: 'ok', value: 'Runner updated succesfully.' });
    }

    const newUser = new User({
      email,
      firstName,
      lastName,
      mobile,
      runningGroup,
      role,
      isActive: false,
      isRegistered: true,
    });

    const savedUser = await newUser.save();
    logger.debug('server.routes.userRouter.registerUser.NewUser.sendAWelcomeEmail.start');
    sendAWelcomeEmail(email, firstName, role);
    logger.debug('server.routes.userRouter.registerUser.NewUser.sendAWelcomeEmail.end');
    logger.debug('server.routes.userRouter.registerUser.savedUser.success');
    return res.json(savedUser);
  } catch (err) {
    logger.error(`server.routes.userRouter.registerUser:${err.message}`);
    return res.status(500).json({ msg: 'error', value: err.message });
  }
};

export default registerUser;
