import express from 'express';
import axios from 'axios';
import logger from '../utils/logger.js';
const router = express.Router();
import mongoose from 'mongoose';
const ObjectId = mongoose.Types.ObjectId;

// const auth = require('../middleware/auth');
import User from '../models/userModel.js';
import registerUser from '../controllers/registerController.js';
import getRunners from '../controllers/getRunnersController.js';
import sendEmail from '../utils/transactionalEmails/sendEmail.js';

import DeletedUsers from '../models/deletedUsersModel.js';
import Oauth1UserHelper from '../utils/oauth1UserHelper.js';

router.get('/', (req, res) => {
  logger.debug('server.routes.userRouter.index.served');
  res.render('index');
});

const hasGarminOAuth = async (email) => {
  const user = await User.findOne({ email });
  if (user.garminUserId) {
    return true;
  }
  return false;
};

router.post('/hasGarminOAuth', async (req, res) => {
  logger.debug('server.routes.userRouter.hasGarminOAuth.start');
  logger.debug(`server.routes.userRouter.hasGarminOAuth.{email: ${req.body.userEmail}}`);
  const response = await hasGarminOAuth(req.body.userEmail);
  logger.debug('server.routes.userRouter.hasGarminOAuth.end');
  res.send(response);
});

const getUser = async (email) => await User.findOne({ email });

router.post('/isUser', async (req, res) => {
  logger.debug('server.routes.userRouter.isUser.start');
  logger.debug(`server.routes.userRouter.isUser.{email: ${req.body.userEmail}}`);
  const userDataFromDB = await getUser(req.body.userEmail);
  if (userDataFromDB) {
    let userInfo = userDataFromDB._doc;
    delete userInfo.garminUserAccessSecret;
    delete userInfo.garminUserAccessToken;
    res.send(userInfo);
  } else {
    res.send(null);
  }
  logger.debug('server.routes.userRouter.isUser.end');
});

router.get('/garminSync', async (req, res) => {
  logger.debug('server.routes.userRouter.garminSync.start');
  if (!req.session.grant?.response) return res.redirect(`${process.env.REACT_APP_CLIENT_URL}`);

  const userEmail = req.session.grant?.dynamic?.state;
  const { access_token, access_secret } = req.session.grant?.response;
  if (userEmail && access_token && access_secret) {
    const oauth1User = new Oauth1UserHelper(access_token, access_secret);
    const garminUserId = await oauth1User.getGarminUserId();
    logger.debug(`server.routes.userRouter.garminSync.garminUserId.${garminUserId}`);
    logger.debug('server.routes.userRouter.garminSync.userUpdate.start');
    await User.updateOne(
      { email: userEmail },
      {
        $set: {
          garminUserAccessToken: access_token,
          garminUserAccessSecret: access_secret,
          garminUserId,
        },
      },
    );
    logger.debug('server.routes.userRouter.garminSync.userUpdate.success');
    logger.debug('server.routes.userRouter.garminSync.garminUserAccessCredentials.success');
  }
  logger.debug('server.routes.userRouter.garminSync.success');
  logger.debug('server.routes.userRouter.garminSync.dashboardView.redirected');
  res.redirect(`${process.env.REACT_APP_CLIENT_URL}`);
});

router.get('/details', (req, res) => {
  logger.debug('server.routes.userRouter.details.start');
  access_token = 1;
  access_secret = 2;
  if (req.session.grant) {
    var { access_token, access_secret } = req.session.grant.response;
    logger.debug('server.routes.userRouter.details.garminUserAccessCredentials.success');
  }
  logger.debug('server.routes.userRouter.details.success');
  logger.debug('server.routes.userRouter.details.runnerDetailsForm.served');
  res.render('runnerDetailsForm', { access_token, access_secret });
});

router.post('/thankyou', async (req, res) => {
  logger.debug('server.routes.userRouter.thankyou.start');
  const newRunner = req.body;
  if (newRunner.garminUserAccessToken == 1 || newRunner.garminUserAccessSecret == 2) {
    res.send('There seems to be a problem with your garmin connection, please try again');
    return;
  }
  logger.debug(`server.routes.userRouter.thankyou.newRunner.created`);
  const oauth1User = new Oauth1UserHelper(
    newRunner.garminUserAccessToken,
    newRunner.garminUserAccessSecret,
  );

  newRunner.garminUserId = await oauth1User.getGarminUserId();
  logger.debug(`server.routes.userRouter.thankyou.newRunner:${JSON.stringify(newRunner, null, 2)}`);
  logger.debug(`server.routes.userRouter.thankyou.newSavedRunner.start`);
  if (getUser(newRunner.email)) await User.deleteOne({ email: newRunner.email });
  const newSavedRunner = new User(newRunner);
  newSavedRunner.save();
  logger.debug(`server.routes.userRouter.thankyou.newSavedRunner.success:${newSavedRunner}`);
  logger.debug('server.routes.userRouter.thankyou.success');
  logger.debug('server.routes.userRouter.thankyou.served');
  res.render('thankyou');
});

// REGISTER USER
router.post('/register', registerUser);

//GET RUNNERS LIST.
router.post('/runners', getRunners);

router.delete('/', async (req, res) => {
  logger.info(`server.routes.userRouter.deleteRunner.start`);
  try {
    const runnerId = req.body.runnerId;
    const deletedRunner = await User.findById(runnerId);

    if (!deletedRunner) {
      logger.warn('server.routes.userRouter.deleteRunner.runnerNotFound');
      res.status({
        severity: 'warning',
        msg: `We couldnt find the runner. Please refresh the page`,
      });
    }

    await User.deleteOne({ _id: runnerId });

    logger.debug(`server.routes.userRouter.deleteRunner.success.id:${runnerId}`);

    await DeletedUsers.create({
      _id: deletedRunner._id,
      ...deletedRunner.toObject(),
      role: 'runner',
    });

    logger.info(`server.routes.userRouter.deleteRunner.end`);
    return res.json({
      severity: 'success',
      msg: `The runner - ${deletedRunner.firstName} ${deletedRunner.lastName}, was successfully deleted`,
    });
  } catch (error) {
    logger.error(
      `server.routes.userRouter.deleteRunner.success.id:${runnerId}.error.${error.message}`,
    );
    return res.json({
      severity: 'error',
      msg: `There was a problem deleting the runner: ${deletedRunner.firstName} ${deletedRunner.lastName}`,
    });
  }
});

router.post('/inviteRunner', async (req, res) => {
  logger.debug(`server.routes.userRouter.inviteRunner.start`);
  const runnerId = req.body.runnerId;

  const runner = await User.findById(runnerId);
  if (runner) {
    const trainer = await User.findById(runner.trainerUserId);
    logger.debug(`server.routes.userRouter.inviteRunner.${runnerId}.invitationSent.start`);

    const emailInfo = {
      to: runner.email,
      firstName: runner.firstName,
      templateType: 'newRunnerInvitation',
      trainerName: trainer.firstName,
      runningGroupName: runner.runningGroup,
      inviteURL: `${process.env.REACT_APP_CLIENT_URL}/sign-up/${runner._id}`,
    };
    logger.debug(`server.routes.userRouter.inviteRunner.${runnerId}.sendEmail.start`);
    logger.debug(
      `server.routes.userRouter.inviteRunner.${runnerId}.sendEmail.${JSON.stringify(emailInfo)}`,
    );
    sendEmail(emailInfo);
    logger.debug(`server.routes.userRouter.inviteRunner.${runnerId}.sendEmail.end`);

    logger.debug(`server.routes.userRouter.inviteRunner.${runnerId}.sendSMS.start`);
    const response = await axios.post(
      `https://www.019sms.co.il/api`,
      {
        sms: {
          user: {
            username: process.env.SMS_019_USERNAME,
          },
          source: '0543301488',
          destinations: {
            phone: [
              {
                _: runner.mobile.replace(/\s+/g, ''),
              },
            ],
          },
          message: `Hi ${runner.firstName}, Welcome to ${runner.runningGroup} running group! Sign up to receive your weekly workout plans and monitor your progress: ${process.env.REACT_APP_CLIENT_URL}/sign-up/${runner._id}`,
        },
      },
      {
        // headers: { Authorization: `Bearer ${token}` }
        headers: {
          Authorization: `Bearer ${process.env.SMS_019_BEARER_TOKEN}`,
        },
      },
    );
    logger.debug(
      `server.routes.userRouter.inviteRunner.${runnerId}.invitationSent.smsGatewayResponse.${JSON.stringify(
        response.data,
      )}`,
    );
    logger.debug(`server.routes.userRouter.inviteRunner.${runnerId}.sendSMS.end`);
    res.send({
      severity: 'info',
      msg: `An invite message was sent to ${runner.firstName} ${runner.lastName}`,
      runner: {
        name: `${runner.firstName} ${runner.lastName}`,
        firstName: runner.firstName,
        lastName: runner.lastName,
        email: runner.email || '',
        mobile: runner.mobile,
        runnerId: runner._id,
        basePace: runner.basePace || {},
        runsPerWeek: runner.runsPerWeek || 0,
        isActive: runner.isActive,
        isRegistered: runner.isRegistered || false,
        runningGroup: runner.runningGroup || '',
        subGroup: runner.subGroup || '',
      },
    });
  }
  logger.debug(`server.routes.userRouter.inviteRunner.end`);
});

router.post('/toggleRunner', async (req, res) => {
  logger.debug(`server.routes.userRouter.toggleRunner.start`);
  const runnerId = req.body.runnerId;
  const runner = await User.findById(runnerId);
  if (runner) {
    runner.isActive = !runner.isActive || false;
    await runner.save();
    logger.debug(`server.routes.userRouter.toggleRunner.${runnerId}.isActive.${runner.isActive}`);
    res.send({
      msg: 'ok',
      runner: {
        name: `${runner.firstName} ${runner.lastName}`,
        firstName: runner.firstName,
        lastName: runner.lastName,
        email: runner.email,
        mobile: runner.mobile,
        runnerId: runner._id,
        basePace: runner.basePace,
        runsPerWeek: runner.runsPerWeek || 0,
        isActive: runner.isActive,
        isRegistered: runner.isRegistered,
        runningGroup: runner.runningGroup || 'N/A',
        subGroup: runner.subGroup,
      },
    });
  }
  logger.debug(`server.routes.userRouter.toggleRunner.end`);
});

router.post('/runner', async (req, res) => {
  logger.debug(`server.routes.userRouter.runner.start`);
  const runnerNewInformation = req.body;
  const runnerId = runnerNewInformation.runnerId;
  const runnerEmail = runnerNewInformation.email;

  if (runnerId && !ObjectId.isValid(runnerId))
    return res.send({ msg: 'error', value: 'Invalid runner id' });

  if (!runnerId) {
    logger.debug(
      `server.routes.userRouter.runner.create.start.${JSON.stringify(runnerNewInformation)}`,
    );
    delete runnerNewInformation._id;

    const deletedRunner = await DeletedUsers.findOne({ email: runnerEmail });

    if (deletedRunner) {
      await DeletedUsers.deleteOne({ email: runnerEmail });

      const reinstatedRunner = new User({
        ...deletedRunner.toObject(),
        role: 'runner',
      });

      const savedReinstatedRunner = await reinstatedRunner.save();
      logger.debug(`server.routes.userRouter.runner.reinstate.success`);

      return res.send({
        msg: 'ok',
        runner: {
          runnerId: savedReinstatedRunner._id,
          ...savedReinstatedRunner.toObject(),
        },
      });
    }

    const newRunner = new User({
      ...runnerNewInformation,
      basePace: {
        minutes: runnerNewInformation.paceMinutes,
        seconds: runnerNewInformation.paceSeconds,
      },
      role: 'runner',
    });

    const savedRunner = await newRunner.save();
    logger.debug(`server.routes.userRouter./runner.create.success`);

    return res.send({
      msg: 'ok',
      runner: {
        runnerId: savedRunner._id,
        ...savedRunner.toObject(),
      },
    });
  }

  const updatedRunnerInformation = await User.updateOne(
    { _id: runnerId },
    {
      $set: {
        basePace: {
          minutes: runnerNewInformation.paceMinutes,
          seconds: runnerNewInformation.paceSeconds,
        },
        ...runnerNewInformation,
      },
    },
  );
  logger.debug(
    `server.routes.userRouter.runner.update.success.${JSON.stringify(runnerNewInformation)}`,
  );

  res.send({
    msg: 'ok',
    runner: {
      runnerId,
      ...runnerNewInformation,
    },
  });

  logger.debug(`server.routes.userRouter./runner.end`);
});

// THIS IS PART OF A NEW SIGN UP OF A RUNNER - BY INVITATION OF A TRAINER
// THIS IS A BAD SECURITY PRACTICE TO EXPOSE THE DB LIKE THIS
// REQUIRES ADDITIONAL THINKING (MAYBE 2FA WITH THE RUNNER'S MOBILE WHICH IS ALREADY INSERETED BY THE TRAINER)
router.post('/getRunner', async (req, res) => {
  logger.debug(`server.routes.userRouter./getRunner.start`);
  const runnerId = req.body.runnerId;

  if (!ObjectId.isValid(runnerId)) return res.send({ msg: 'error', value: 'Invalid runner id' });
  if (runnerId) {
    const runner = await User.findById(runnerId);
    res.send({ msg: 'ok', runner });
  }

  logger.debug(`server.routes.userRouter./getRunner.end`);
});

router.patch('/createSubgroup', async (req, res) => {
  logger.debug(`server.routes.userRouter./createSubgroup.start`);

  const trainerUserId = req.body.id;
  const { subgroup } = req.body;

  try {
    const trainer = await User.findById(trainerUserId);
    if (!trainer || trainer.role !== 'trainer') {
      return res.status(403).json({ msg: 'Permission Declined!' });
    }

    const updatedTrainer = await User.findOneAndUpdate(
      { _id: trainerUserId, role: 'trainer' },
      { $push: { subGroups: subgroup } },
      { new: true },
    );

    return res.json({ msg: 'Subgroup updated successfully', updatedTrainer });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ msg: 'Internal server error' });
  }
});

router.post('/getSubgroups', async (req, res) => {
  logger.debug(`server.routes.userRouter./getSubgroups.start`);
  try {
    const trainerUserId = req.body.trainerUserId;
    if (!trainerUserId) {
      return res.json({ subGroups: [] });
    }
    const trainer = await User.findById(trainerUserId);

    if (!trainer || trainer.role !== 'trainer') {
      return res.status(403).json({ msg: 'Permission Denied!' });
    }
    return res.json({ subGroups: trainer.subGroups });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ msg: 'Internal server error' });
  }
});

router.patch('/removeSubgroup', async (req, res) => {
  logger.debug(`server.routes.userRouter./removeSubgroup.start`);

  const trainerUserId = req.body.id;
  const { subgroup } = req.body;

  try {
    const trainer = await User.findById(trainerUserId);
    if (!trainer || trainer.role !== 'trainer') {
      return res.status(403).json({ msg: 'Permission Declined!' });
    }

    const updatedTrainer = await User.findOneAndUpdate(
      { _id: trainerUserId, role: 'trainer' },
      { $pull: { subGroups: subgroup } },
      { new: true },
    );

    await User.updateMany(
      { trainerUserId: trainerUserId, subGroup: subgroup },
      { $set: { subGroup: 'General' } },
    );

    return res.json({ msg: 'Subgroup removed successfully', updatedTrainer });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ msg: 'Internal server error' });
  }
});

router.patch('/addRunnerSubgroup', async (req, res) => {
  logger.debug(`server.routes.userRouter./addRunnerSubgroup.start`);

  const trainerId = req.body.id;
  const runnerId = req.body.runnerId;
  const subgroup = req.body.subgroup;

  if (subgroup === 'General') {
    return;
  }
  try {
    const trainer = await User.findById(trainerId);

    if (!trainer || trainer.role !== 'trainer') {
      return res.status(403).json({ msg: 'Permission Declined!' });
    }

    if (
      !trainer.subGroups ||
      trainer.subGroups.length === 0 ||
      !trainer.subGroups.includes(subgroup)
    ) {
      return res.status(400).json({ msg: 'Subgroup not found!' });
    }

    const updatedRunner = await User.findOneAndUpdate(
      { _id: runnerId },
      { $set: { subGroup: subgroup } },
      { new: true },
    );

    return res.json({ msg: 'Runners subgroup updated successfully' });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ msg: 'Internal server error' });
  }
});

router.patch('/removeRunnerSubgroup', async (req, res) => {
  logger.debug(`server.routes.userRouter./removeRunnerSubgroup.start`);

  const trainerId = req.body.id;
  const runnerId = req.body.runnerId;

  try {
    const trainer = await User.findById(trainerId);

    if (!trainer || trainer.role !== 'trainer') {
      return res.status(403).json({ msg: 'Permission Declinced' });
    }

    const updatedRunner = await User.findOneAndUpdate(
      { _id: runnerId },
      { $set: { subGroup: 'General' } },
      { new: true },
    );

    return res.json({
      msg: 'Runners subgroup removed successfully',
      updatedRunner,
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ msg: 'Internal server error' });
  }
});

router.post('/getRunnersWithSubgroup', async (req, res) => {
  logger.debug(`server.routes.userRouter./getRunnersWithSubgroup.start`);

  const { subgroup } = req.body;

  try {
    if (!subgroup) {
      return res.status(400).json({ msg: 'Subgroup not provided' });
    }

    const runners = await User.find({ role: 'runner', subGroup: subgroup });

    return res.json({ msg: 'Runners retrieved successfully', runners });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ msg: 'Internal server error' });
  }
});

export default router;
