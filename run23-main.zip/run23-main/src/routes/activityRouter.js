import express from 'express';
import logger from '../utils/logger.js';
const router = express.Router();

import SummaryActivity from '../models/summaryActivityModel.js';
import DetailedActivity from '../models/detailedActivityModel.js';
import OtherActivity from '../models/otherActivityModel.js';
import User from '../models/userModel.js';

const getUser = (id) => User.findOne({ garminUserId: id });

const handleActivitySummary = async (req, res) => {
  logger.info(`server.routes.activityRouter.summary.start`);
  if (req.body.activities) {
    req.body.activities.forEach(async (activity) => {
      const user = await getUser(activity.userId);
      logger.debug(
        `${activity.userId}.${user?.firstName}.${user?.lastName}.server.routes.activityRouter.saveActivity.start`,
      );
      const newSavedActivity = new SummaryActivity(activity);
      newSavedActivity.runnerId = user?._id;
      newSavedActivity.trainerUserId = user?.trainerUserId;
      await newSavedActivity.save();
      logger.debug(
        `${activity.userId}.${user?.firstName}.${user?.lastName}.server.routes.activityRouter.saveActivity.success`,
      );
    });
  }
  logger.info(`server.routes.activityRouter.summary.end`);
  return { msg: `summary! got it, thanks!` };
};

const handleActivityDetailed = async (req, res) => {
  logger.info(`server.routes.activityRouter.detailed.start`);

  req.body.activityDetails.forEach(async (activity) => {
    const user = await getUser(activity.userId);
    logger.debug(
      `${activity.userId}.${user?.firstName}.${user?.lastName}.server.routes.activityRouter.saveActivityDetails.start`,
    );
    const newSavedActivity = new DetailedActivity(activity);
    newSavedActivity.runnerId = user?._id;
    newSavedActivity.trainerUserId = user?.trainerUserId;
    await newSavedActivity.save();
    logger.debug(
      `${activity.userId}.${user?.firstName}.${user?.lastName}.server.routes.activityRouter.saveActivityDetails.success`,
    );
  });

  logger.info(`server.routes.activityRouter.detailed.end`);
  return { msg: `detailed! got it, thanks!` };
};

const handleActivityOther = async (req, res) => {
  logger.debug(`server.routes.activityRouter.saveOtherActivity.start`);
  // req.body.activityDetails.forEach(async (activity) => {
  const user = await getUser(activity.userId);
  const newSavedActivity = new OtherActivity({ data: req.body });
  newSavedActivity.runnerId = user?._id;
  newSavedActivity.trainerUserId = user?.trainerUserId;
  await newSavedActivity.save();
  logger.debug(`.server.routes.activityRouter.saveOtherActivity.success`);
  // });
  logger.debug(`server.routes.activityRouter.saveOtherActivity.end`);

  return { msg: `other! got it, thanks!` };
};

router.post('/', async (req, res) => {
  logger.info(`server.routes.activityRouter./.start`);
  let response;
  if (req.body.activities) {
    response = await handleActivitySummary(req, res);
  } else if (req.body.activityDetails) {
    response = await handleActivityDetailed(req, res);
  } else {
    response = await handleActivityOther(req, res);
  }
  logger.info(`server.routes.activityRouter./.end`);
  res.send(response);
});

const convertEpochToStartEndOfDay = (epoch) => {
  logger.debug(`server.routes.activityRouter.convertEpochToStartEndOfDay.start`);
  const epochDate = new Date(epoch);
  const startOfDay = epochDate.setHours(0, 0, 0, 0);
  const endOfDay = epochDate.setHours(23, 59, 59, 999);
  logger.debug(`server.routes.activityRouter.convertEpochToStartEndOfDay.end`);
  return [startOfDay, endOfDay];
};

const getAllRunningActivitiesByStartEndOfDay = (startOfDay, endOfDay, userId) => {
  logger.debug(`server.routes.activityRouter.getAllRunningActivitiesByStartEndOfDay.start`);
  return SummaryActivity.find({
    $or: [{ activityType: 'RUNNING' }, { activityType: 'TREADMILL_RUNNING' }],
    startTimeInSeconds: { $gt: startOfDay / 1000, $lt: endOfDay / 1000 },
    ...userId,
  });
};

const roundToTwoDigitsFloat = (number) => parseFloat(number?.toFixed(2).replace(/[.,]00$/, ''));

const parseAllDayRunningActivities = async (dayActivitiesData) => {
  logger.debug(`server.routes.activityRouter.parseAllDayRunningActivities.start`);
  return await Promise.all(
    dayActivitiesData.map(async (activity) => {
      const user = await getUser(activity.userId);
      const name = `${user?.firstName} ${user?.lastName}`;
      return {
        id: user?.garminUserId,
        name,
        distance: roundToTwoDigitsFloat(activity.distanceInMeters / 1000),
        time: roundToTwoDigitsFloat(activity.durationInSeconds),
        pace: roundToTwoDigitsFloat(activity.averagePaceInMinutesPerKilometer),
        elevationGain: roundToTwoDigitsFloat(activity.totalElevationGainInMeters),
        elevationLoss: roundToTwoDigitsFloat(activity.totalElevationLossInMeters),
        avgHr: roundToTwoDigitsFloat(activity.averageHeartRateInBeatsPerMinute),
        maxHr: roundToTwoDigitsFloat(activity.maxHeartRateInBeatsPerMinute),
      };
    }),
  );
};

router.post('/dayActivities', async (req, res) => {
  logger.info(`server.routes.activityRouter./dayActivities.start`);
  const { runnerId, trainerUserId } = req.body;
  const [startOfDay, endOfDay] = convertEpochToStartEndOfDay(req.body.epochDate);
  const userId = trainerUserId ? { trainerUserId } : { runnerId };
  const dayActivitiesData = await getAllRunningActivitiesByStartEndOfDay(
    startOfDay,
    endOfDay,
    userId,
  );
  logger.info(`server.routes.activityRouter./dayActivities.dayActivitiesData.success`);
  const dayActivities = await parseAllDayRunningActivities(dayActivitiesData);
  logger.info(`server.routes.activityRouter./dayActivities.end`);
  res.send(dayActivities);
});

const daysOfTheWeek = [
  'sunday',
  'monday',
  'tuesday',
  'wednesday',
  'thursday',
  'friday',
  'saturday',
];

const convertEpochToStartEndOfWeek = (epoch) => {
  logger.debug(`server.routes.activityRouter.convertEpochToStartEndOfWeek.start`);

  const epochDate = new Date(epoch);
  const firstDayOfWeek = epochDate.getDate() - epochDate.getDay();
  // First day is the day of the month - the day of the week

  const weekStartDate = new Date(epochDate.setDate(firstDayOfWeek));
  const weekEndDate = new Date(epochDate.setDate(weekStartDate.getDate() + 6));

  const startOfWeek = weekStartDate.setHours(0, 0, 0, 0);
  const endOfWeek = weekEndDate.setHours(23, 59, 59, 999);

  logger.debug(`server.routes.activityRouter.convertEpochToStartEndOfWeek.end`);

  return [startOfWeek, endOfWeek];
};

const getAllRunningActivitiesByStartEndOfWeek = (startOfWeek, endOfWeek, userId) =>
  SummaryActivity.find({
    $or: [{ activityType: 'RUNNING' }, { activityType: 'TREADMILL_RUNNING' }],
    startTimeInSeconds: { $gt: startOfWeek / 1000, $lt: endOfWeek / 1000 },
    ...userId,
  });

router.post('/weekActivities', async (req, res) => {
  logger.info(`server.routes.activityRouter./weekActivities.start`);

  const { runnerId, trainerUserId } = req.body;
  const userId = trainerUserId ? { trainerUserId } : { runnerId };
  const [startOfWeek, endOfWeek] = convertEpochToStartEndOfWeek(req.body.epochDate);
  const weekActivitiesData = await getAllRunningActivitiesByStartEndOfWeek(
    startOfWeek,
    endOfWeek,
    userId,
  );
  logger.info(`server.routes.activityRouter./weekActivities.weekActivitiesData.success`);

  const weekActivities = {};

  weekActivitiesData.forEach(async (activity) => {
    const date = new Date(activity.startTimeInSeconds * 1000);
    const activityDate = `${date.getDate()}/${date.getMonth() + 1}`;

    let runnerWeek = weekActivities[activity.userId];
    let runnerWeekRuns = weekActivities[activity.userId]?.weekRuns;

    if (runnerWeek) {
      if (runnerWeekRuns?.[activityDate]) {
        runnerWeek.weekTotal += activity.distanceInMeters;
        runnerWeekRuns[activityDate].distanceCovered += activity.distanceInMeters;
      } else {
        runnerWeek.weekTotal += activity.distanceInMeters;
        runnerWeekRuns[activityDate] = {};
        runnerWeekRuns[activityDate].distanceCovered = activity.distanceInMeters;
        runnerWeekRuns[activityDate].date = activityDate;
        runnerWeekRuns[activityDate].dayOfTheWeek = daysOfTheWeek[date.getDay()];
      }
    } else {
      runnerWeek = {};
      runnerWeek.weekTotal = activity.distanceInMeters;
      runnerWeekRuns = {};
      runnerWeekRuns[activityDate] = {};
      runnerWeekRuns[activityDate].distanceCovered = activity.distanceInMeters;
      runnerWeekRuns[activityDate].dayOfTheWeek = daysOfTheWeek[date.getDay()];
      runnerWeekRuns[activityDate].date = activityDate;
    }

    runnerWeek.weekRuns = runnerWeekRuns;
    weekActivities[activity.userId] = runnerWeek;
  });

  const weeklyData = [];
  const userIds = Object.keys(weekActivities);

  for (const userId of userIds) {
    const weekByRunner = {};
    const user = await getUser(userId);
    const userName = `${user?.firstName} ${user?.lastName}`;
    weekByRunner.name = userName;
    weekByRunner.userId = userId;
    weekByRunner.weekTotal = roundToTwoDigitsFloat(weekActivities[userId].weekTotal / 1000);

    const runnerWeekRunDates = Object.keys(weekActivities[userId].weekRuns);
    weekByRunner.weekRuns = {};
    for (const date of runnerWeekRunDates) {
      weekByRunner.weekRuns[weekActivities[userId].weekRuns[date].dayOfTheWeek] =
        weekActivities[userId].weekRuns[date];

      weekByRunner.weekRuns[weekActivities[userId].weekRuns[date].dayOfTheWeek].distanceCovered =
        roundToTwoDigitsFloat(
          weekByRunner.weekRuns[weekActivities[userId].weekRuns[date].dayOfTheWeek]
            .distanceCovered / 1000,
        );
    }
    weeklyData.push(weekByRunner);
  }

  logger.info(`server.routes.activityRouter./weekActivities.end`);
  res.send(weeklyData);
});

export default router;
