import express from 'express';
import logger from '../utils/logger.js';
const router = express.Router();

import User from '../models/userModel.js';
import Workout from '../models/workoutModel.js';
import WorkoutPlanTemplate from '../models/workoutPlanTemplateModel.js';
import WorkoutTemplate from '../models/workoutTemplateModel.js';
import Oauth1UserHelper from '../utils/oauth1UserHelper.js';
import Running from '../utils/workout/Running.js';

router.post('/garminSync', async (req, res) => {
  logger.info('server.routes.workoutRouter./.start');
  const workoutData = req.body.workout;

  // if (workoutData.workout[0].repeatValue == '1')
  //   workoutData.workout[0] = workoutData.workout[0].intervalStep;

  const newWorkout = new Running(`${req.body.date} - ${workoutData.workoutName} [sub.cx]`);
  const workoutReqBody = newWorkout.getMainWorkoutJson(workoutData);

  const runner = await User.findOne({ _id: req.body.runnerId });
  if (!runner)
    res.send({
      severity: 'warning',
      msg: `We couldn't find "${workoutData.userEmail}". Please switch to the email you used when you've subscribed`,
    });
  const oauth1User = new Oauth1UserHelper(
    runner.garminUserAccessToken,
    runner.garminUserAccessSecret,
  );

  const garminWorkoutResponse = await oauth1User.syncGarminWorkout(workoutReqBody);

  res.send({
    severity: 'info',
    msg: `Your workout: "${workoutData.workoutName}" was sent. Please sync your watch.`,
  });
  logger.info('server.routes.workoutRouter./.end');
});

const getTemplateByName = async (name) => {
  const template = await WorkoutTemplate.findOne({ workoutName: name });
  return template;
};

router.post('/template', async (req, res) => {
  logger.debug('server.routes.workoutRouter./template.start');
  const workoutTemplate = req.body;
  const trainerEmail = workoutTemplate.userEmail;
  const trainer = await User.findOne({ email: trainerEmail });
  workoutTemplate.trainerUserId = trainer._id;
  const isTemplateNameExists = await getTemplateByName(workoutTemplate.workoutName);
  delete workoutTemplate.userEmail;

  if (isTemplateNameExists) {
    logger.debug('server.routes.workoutRouter./template.workoutTemplateExists');
    logger.debug('server.routes.workoutRouter./template.workoutTemplate.update.start');
    await WorkoutTemplate.updateOne(
      {
        _id: isTemplateNameExists._id,
      },
      { $set: { ...workoutTemplate } },
    );
    logger.debug('server.routes.workoutRouter./template.workoutTemplate.update.success');
    logger.debug('server.routes.workoutRouter./template.workoutTemplate.update.end');
    return res.send({ severity: 'info', msg: `The workout template was updated successfully` });
  }

  const savedWorkoutTemplate = new WorkoutTemplate(workoutTemplate);
  savedWorkoutTemplate.save((err, book) => {
    if (err) {
      logger.error(
        `server.routes.workoutRouter./template.savedWorkoutTemplate.${savedWorkoutTemplate}`,
      );
      res.send({ severity: 'error', msg: `There was an error while saving the template to DB` });
    }
  });
  logger.debug('server.routes.workoutRouter./template.end');
  res.send({
    severity: 'info',
    msg: 'The workout template was saved to database',
    savedWorkoutTemplate,
  });
});

router.post('/templatesFromDB', async (req, res) => {
  logger.info('server.routes.workoutRouter./templatesFromDB.start');
  const trainerInfo = req.body;
  const trainerEmail = trainerInfo.email;
  const trainer = await User.findOne({ email: trainerEmail });

  // if (!trainer || trainer.role != 'trainer') {
  // if (!trainer) {
  //   return res.send({ severity: 'error', msg: `Error! trainer doesn't exists` });
  // }
  // if (trainer && trainer.role != 'trainer') res.send({ severity: 'info', msg: `all good` }); //`${}`
  const workoutTemplates = await WorkoutTemplate.find({ trainerUserId: trainer._id });
  res.send({
    severity: 'info',
    msg: `The workout template was retrieved successfully`,
    workoutTemplates,
  });

  logger.info('server.routes.workoutRouter./templateFromDB.end');
});

router.post('/toPlanTemplate', async (req, res) => {
  logger.info('server.routes.workoutRouter./toPlanTemplate.start');
  const workoutTemplatePlanInfo = req.body;
  const trainerEmail = workoutTemplatePlanInfo.userEmail;
  const trainer = await User.findOne({ email: trainerEmail });
  workoutTemplatePlanInfo.trainerUserId = trainer._id;
  workoutTemplatePlanInfo.workoutTemplate.trainerUserId = trainer._id;
  delete workoutTemplatePlanInfo.userEmail;
  delete workoutTemplatePlanInfo.workoutTemplate.userEmail;

  const startOfDate = new Date(workoutTemplatePlanInfo.dateObject).setHours(0, 0, 0, 0);
  const endOfDate = new Date(workoutTemplatePlanInfo.dateObject).setHours(23, 59, 59, 999);
  let savedWorkoutTemplatePlan = await WorkoutPlanTemplate.findOne({
    trainerUserId: workoutTemplatePlanInfo.trainerUserId,
    dateObject: { $gte: startOfDate, $lt: endOfDate },
    subGroup: workoutTemplatePlanInfo.subGroup,
  });

  if (savedWorkoutTemplatePlan) {
    savedWorkoutTemplatePlan = await WorkoutPlanTemplate.updateOne(
      {
        trainerUserId: workoutTemplatePlanInfo.trainerUserId,
        dateObject: { $gte: startOfDate, $lt: endOfDate },
      },
      { $set: { ...workoutTemplatePlanInfo } },
    );
  } else {
    savedWorkoutTemplatePlan = new WorkoutPlanTemplate(workoutTemplatePlanInfo);
    savedWorkoutTemplatePlan.save((err, workoutTemplatePlanInfo) => {
      if (err) {
        logger.error(
          `server.routes.workoutRouter./toPlanTemplate.savedWorkoutTemplate.${workoutTemplatePlanInfo}.error:${err}`,
        );
        res.send({ severity: 'error', msg: `There was an error while saving template to DB` });
      }
    });

    // savedWorkoutTemplatePlan = await WorkoutPlanTemplate.replaceOne(
    //   {
    //     trainerUserId: workoutTemplatePlanInfo.trainerUserId,
    //     dateObject: workoutTemplatePlanInfo.dateObject,
    //   },
    //   { ...workoutTemplatePlanInfo },
    // );
  }

  logger.info('server.routes.workoutRouter./toPlanTemplate.end');
  res.send({
    severity: 'info',
    msg: `The workout was saved to plan successfully`,
    savedWorkoutTemplatePlan,
  });
});

router.post('/removeFromPlanTemplate', async (req, res) => {
  logger.info('server.routes.workoutRouter./removeFromPlanTemplate.start');
  const workoutTemplatePlanToRemove = req.body;
  const trainerEmail = workoutTemplatePlanToRemove.userEmail;
  const trainer = await User.findOne({ email: trainerEmail });

  const date = workoutTemplatePlanToRemove.activeDateObject;
  const startOfDate = new Date(date).setHours(0, 0, 0, 0);
  const endOfDate = new Date(date).setHours(23, 59, 59, 999);

  const removedWorkoutFromPlanTemplate = await WorkoutPlanTemplate.findOneAndDelete({
    trainerUserId: trainer._id,
    dateObject: { $gte: startOfDate, $lt: endOfDate },
  });

  logger.info('server.routes.workoutRouter./removeFromPlanTemplate.end');
  res.send({
    severity: 'info',
    msg: `The workout template was removed`,
    removedWorkoutFromPlanTemplate,
  });
});

router.post('/workoutsPlan', async (req, res) => {
  logger.info('server.routes.workoutRouter./workoutsPlan.start');
  const body = req.body;
  const trainerEmail = body.userEmail;
  const trainer = await User.findOne({ email: trainerEmail });
  const startDate = new Date(body.startWeekDate);
  const startWeekDate = startDate.setHours(0, 0, 0, 0);
  const weekInMiliSec = 7 * 24 * 60 * 60 * 1000;
  const endWeekDate = new Date(startDate.getTime() + weekInMiliSec).setHours(23, 59, 59, 999);

  const workoutPlanTemplates = await WorkoutPlanTemplate.find({
    trainerUserId: trainer._id,
    dateObject: { $gte: startWeekDate, $lte: endWeekDate },
  });

  res.send({
    severity: 'info',
    msg: `All Weekly workout templates were retrieved successfully`,
    workoutPlanTemplates,
  });

  logger.info('server.routes.workoutRouter./workoutsPlan.end');
});

//@desc Get All Planned Workout Of a User
//@route /workout/getPlannedWorkout
//@access public
router.post('/getWorkoutTemplate', async (req, res) => {
  logger.info('server.routes.workoutRouter./getWorkoutTemplate.start');
  const body = req.body;
  const trainerEmail = body.userEmail;
  const trainer = await User.findOne({ email: trainerEmail });
  // const startDate = new Date(body.startWeekDate);
  // const startWeekDate = startDate.setHours(0, 0, 0, 0);
  // const weekInMiliSec = 7 * 24 * 60 * 60 * 1000;
  // const endWeekDate = new Date(startDate.getTime() + weekInMiliSec).setHours(23, 59, 59, 999);

  const workoutPlanTemplates = await WorkoutPlanTemplate.find({
    trainerUserId: trainer._id,
  });

  res.send({
    severity: 'info',
    msg: `All workout templates of this user were retrieved successfully`,
    workoutPlanTemplates,
  });

  logger.info('server.routes.workoutRouter./getWorkoutTemplate.end');
});

const saveOrUpdateWorkoutToDB = async (workout) => {
  logger.debug('server.routes.workoutRouter.saveOrUpdateWorkoutToDB.start');
  const { runnerId, trainerUserId, dateObject, ...workoutData } = workout;
  // const date = workout.dateObject;
  const startOfDate = new Date(dateObject).setHours(0, 0, 0, 0);
  const endOfDate = new Date(dateObject).setHours(23, 59, 59, 999);

  const newWorkout = {
    runnerId,
    trainerUserId,
    dateObject,
    workout: { ...workoutData.workout },
    // workout: { ...workoutData, trainerUserId },
  };

  let savedWorkout = await Workout.findOne({
    runnerId,
    dateObject: { $gte: startOfDate, $lt: endOfDate },
  });

  if (!savedWorkout) {
    savedWorkout = new Workout({ ...newWorkout });
    savedWorkout.save((err, newWorkout) => {
      if (err) {
        logger.error(
          `server.routes.workoutRouter.saveOrUpdateWorkoutToDB.${newWorkout}.error:${err}`,
        );
        res.send({ severity: 'error', msg: `There was an error while saving workout to DB` });
      }
    });
    logger.debug('server.routes.workoutRouter.saveOrUpdateWorkoutToDB.workoutSaved.success');
  } else {
    savedWorkout = await Workout.updateOne(
      {
        runnerId,
        dateObject: { $gte: startOfDate, $lt: endOfDate },
      },
      { $set: { ...newWorkout } },
    );
    logger.debug('server.routes.workoutRouter.saveOrUpdateWorkoutToDB.workoutupdated.success');
  }
  logger.debug('server.routes.workoutRouter.saveOrUpdateWorkoutToDB.end');

  return savedWorkout;
};

router.post('/toRunners', async (req, res) => {
  logger.info('server.routes.workoutRouter./toRunners.start');
  const body = req.body;
  const weeklyWorkoutPlan = body.weeklyWorkoutPlan;
  const trainerEmail = body.userEmail;
  const trainer = await User.findOne({ email: trainerEmail });
  if (!trainer) {
    logger.error(`server.routes.workoutRouter./toRunners.trainerNotFound.${trainerEmail}`);
    return res.send({ severity: 'error', msg: `Access problem. Trainer was not found` });
  }

  weeklyWorkoutPlan.forEach(async (runner) => {
    const runnerProfile = await User.findOne({ email: runner.email });
    runner.runnerWorkoutsPlan.forEach(async (runnerWorkout) => {
      if (runnerWorkout.isWorkout) {
        const date = runnerWorkout.dateObject;
        const startOfDate = new Date(date).setHours(0, 0, 0, 0);
        const endOfDate = new Date(date).setHours(23, 59, 59, 999);

        let savedWorkout = await Workout.findOne({
          runnerId: runnerProfile._id,
          dateObject: { $gte: startOfDate, $lt: endOfDate },
        });

        if (!savedWorkout) {
          const workout = {};
          workout.runnerId = runnerProfile._id;
          workout.dateObject = runnerWorkout.dateObject;
          workout.workout = runnerWorkout.workoutTemplate || runnerWorkout;
          workout.workout.trainerUserId = trainer._id;
          workout.trainerUserId = trainer._id; // runnerWorkout.workoutTemplate?.trainerUserId || runnerWorkout.trainerUserId;
          savedWorkout = new Workout(workout);
          savedWorkout.save((err, workout) => {
            if (err) {
              logger.error(
                `server.routes.workoutRouter./toRunners.savedWorkoutToRunnersDB.${workout}.error:${err}`,
              );
              res.send({
                severity: 'error',
                msg: `There was an error while saving template to DB`,
              });
            }
          });
          logger.info('server.routes.workoutRouter./toRunners.workoutSaved.success');
        } else {
          savedWorkout = await Workout.updateOne(
            {
              runnerId: runnerProfile._id,
              dateObject: { $gte: startOfDate, $lt: endOfDate },
            },
            { $set: { workout: runnerWorkout.workoutTemplate || runnerWorkout } },
          );
          logger.info('server.routes.workoutRouter./toRunners.workoutupdated.success');
        }
      }
    });
  });

  res.send({ severity: 'info', msg: `The workouts were saved in the database` });

  logger.info('server.routes.workoutRouter./toRunners.end');
});

function getStartOfWeek(date) {
  const day = date.getDay(); // Get the day of the week (0-6)

  // Calculate the number of days to subtract to get to the start of the week (assuming Sunday is the first day)
  const daysToSubtract = (day + 7) % 7;

  // Subtract the number of days from the current date
  let startOfWeek = new Date(date.setDate(date.getDate() - daysToSubtract));

  // Set the time to 00:00:00
  startOfWeek.setHours(0, 0, 0, 0);

  return startOfWeek;
}

function getEndOfWeek(date) {
  const day = date.getDay(); // Get the day of the week (0-6)

  // Calculate the number of days to add to get to the start of the next week (assuming Sunday is the first day)
  const daysToAdd = (6 - day) % 7;

  // Add the number of days to the current date
  let endOfWeek = new Date(date.setDate(date.getDate() + daysToAdd));

  // Set the time to 23:59:59
  endOfWeek.setHours(23, 59, 59, 999);

  return endOfWeek;
}

async function getActiveUsersWithWorkouts(trainerUserId, date) {
  try {
    const activeDate = date ? new Date(date) : new Date();
    const startOfWeek = getStartOfWeek(activeDate);
    const endOfWeek = getEndOfWeek(activeDate);
    let users = [];
    const user = await User.findOne({ _id: trainerUserId });
    if (user?.role == 'trainer') {
      // Fetch all active users of trainerUserId
      users = await User.find({ role: 'runner', trainerUserId, isActive: true });
    } else {
      users.push(user);
    }

    // Array to store the results
    const usersWithWorkouts = [];

    // Iterate through each user
    for (const user of users) {
      // Fetch workouts for the current user
      const workouts = await Workout.find({
        runnerId: user?._id,
        dateObject: { $gte: startOfWeek, $lte: endOfWeek },
      });

      // Add the workouts to the user object
      const userWithWorkouts = {
        ...user?.toObject(),
        workouts: workouts.map((workout) => workout.toObject()),
      };

      // Push the user with workouts to the result array
      usersWithWorkouts.push(userWithWorkouts);
    }
    // console.log(JSON.stringify(usersWithWorkouts, null, 2));

    // Return the users with their workouts
    return usersWithWorkouts.map((user) => {
      user.runnerId = user._id;
      delete user.garminUserAccessSecret;
      delete user.garminUserAccessToken;
      delete user.garminUserId;
      return user;
    });
  } catch (error) {
    // Handle any errors that occur during the process
    logger.error(
      `server.routes.workoutRouter./runnersWeeklyWorkoutPlan.getActiveUsersWithWorkouts.${error}`,
    );
    // res.send({ severity: 'error', msg: `Error fetching users' workouts` });
    // throw error;
  }
}

router.post('/runnersWeeklyWorkoutPlan', async (req, res) => {
  logger.info('server.routes.workoutRouter./runnersWeeklyWorkoutPlan.start');

  const body = req.body;
  const trainerEmail = body.userEmail;

  const trainer = await User.findOne({ email: trainerEmail });

  const trainerUserId = req.body.trainerUserId;
  const runnerId = req.body.runnerId;
  const date = req.body.date || null;

  let sortedWorkouts = [];
  if (trainerUserId) {
    sortedWorkouts = await getActiveUsersWithWorkouts(trainerUserId, date);
  }
  if (runnerId) {
    sortedWorkouts = await getActiveUsersWithWorkouts(runnerId, date);
  }

  res.send({ severity: 'info', msg: `Workouts were retrieved successfully`, sortedWorkouts });

  logger.info('server.routes.workoutRouter./runnersWeeklyWorkoutPlan.end');
});

router.post('/saveRunnerWorkoutToDB', async (req, res) => {
  logger.info('server.routes.workoutRouter./saveRunnerWorkoutToDB.start');
  // const { runnerId, trainerUserId, ...workout } = req.body;
  const workout = req.body;
  const trainer = await User.findOne({ _id: workout.trainerUserId });

  const savedWorkout = await saveOrUpdateWorkoutToDB(workout);
  res.send({ severity: 'info', msg: `The runner's workout was saved successfully`, savedWorkout });

  logger.info('server.routes.workoutRouter./saveRunnerWorkoutToDB.end');
});

const removeRunnerWorkoutFromDB = async (workout) => {
  const removedWorkout = await Workout.remove({ _id: workout._id });
  return removedWorkout;
};

router.post('/removeRunnerWorkoutFromDB', async (req, res) => {
  logger.info('server.routes.workoutRouter./removeRunnerWorkoutFromDB.start');

  const workout = req.body;
  const trainer = await User.findOne({ _id: workout.trainerUserId });
  const removedWorkout = await removeRunnerWorkoutFromDB(workout);

  res.send({
    severity: 'info',
    msg: `The runner's workout was removed successfully`,
    removedWorkout,
  });

  logger.info('server.routes.workoutRouter./removeRunnerWorkoutFromDB.end');
});

export default router;
