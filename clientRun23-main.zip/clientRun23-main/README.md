<p align="center">
  <img width="400" height="127" src="src/views/Home/assets/img/logo/sub-x-logo-blue.png">
</p>

Our revolutionary application empowers trainers to elevate their workout planning like never before. With Sub-X, trainers can say goodbye to manual pace calculations and embrace the power of automation.

Our cutting-edge technology enables automatic individual pace setting for each trainee in the group, tailoring workouts to their specific abilities and goals.

Say hello to efficiency and personalized training like never before.

Sub-X, your pathway to fitness success!

## Demo

https://www.youtube.com/watch?v=yX0Qn-XK9oA

## Features

- Track trainees' progress and performance instantly, making informed adjustments to optimize their training
- No need for juggling multiple tools or spreadsheets
- Tailor individual guidance and feedback based on performance metrics, ensuring each trainee reaches their full potential

## Get Started

open terminal and clone the repo

`git clone https://gitlab.com/RoiJovani/clientRun23.git`

after run

`cd clientRun23`

`npm install`

`npm run start`

Open your browser and head to http://localhost:4000

## Screens

<p align="center">
<img src="src/views/Home/assets/img/about/dashboard_web.png">
<img src="src/views/Home/assets/img/hero/Runners plans - Web.png">
<img src="src/views/Home/assets/img/hero/Screenshot_16.png">
</p>
