Cypress.Commands.add('removeAllSteps', () => {
  cy.getDataTest('repeatStep-deleteButton')
    .should('be.visible')
    .click({
      force: true
    });

  cy.getDataTest('repeatStep-deleteButton').should('not.exist');

  cy.getDataTest('workoutStepTemplate-deleteButton')
    .should('have.length', 3)
    .first() // Select only the first element
    .click({ force: true });

  cy.getDataTest('workoutStepTemplate-deleteButton')
    .should('have.length', 2)
    .first() // Select only the first element
    .click({ force: true });

  cy.getDataTest('workoutStepTemplate-deleteButton')
    .should('have.length', 1)
    .first() // Select only the first element
    .click({ force: true });

  cy.getDataTest('workoutStepTemplate-deleteButton').should('not.exist');
});

Cypress.Commands.add('createFullWorkout', () => {
  cy.get('#workoutName').type('Test Workout');

  //----------------Fill Warmup Data-----------------------------------
  cy.getDataTest('createWorkout-workoutStepTemplate-warmUp')
    .should('exist')
    .within(() => {
      cy.getDataTest('workoutInputFields-selectDurationType-select')
        .should('be.visible')
        .click();
    });
  cy.getDataTest('workoutInputFields-durationType-time')
    .should('exist')
    .should('be.visible')
    .click();

  cy.getDataTest('createWorkout-workoutStepTemplate-warmUp')
    .should('exist')
    .within(() => {
      cy.getDataTest('workoutInputFields-selectUnits-select')
        .should('exist')
        .should('be.visible')
        .click();
    });
  cy.getDataTest('workoutInputFields-units-minute')
    .should('be.visible')
    .click();

  cy.getDataTest('createWorkout-workoutStepTemplate-warmUp')
    .should('exist')
    .within(() => {
      cy.getDataTest('workoutInputFields-setDuration')
        .should('exist')
        .type('20');
    });

  //----------------Fill Workout Step Data-----------------------------------
  cy.getDataTest('createWorkout-workoutStepTemplate-workoutStep')
    .should('exist')
    .should('be.visible')
    .within(() => {
      cy.getDataTest('workoutInputFields-selectDurationType-select')
        .should('be.visible')
        .click();
    });
  cy.getDataTest('workoutInputFields-durationType-distance')
    .should('exist')
    .should('be.visible')
    .click();

  cy.getDataTest('createWorkout-workoutStepTemplate-workoutStep')
    .should('exist')
    .within(() => {
      cy.getDataTest('workoutInputFields-selectUnits-select')
        .should('exist')
        .should('be.visible')
        .click();
    });
  cy.getDataTest('workoutInputFields-units-meter')
    .should('be.visible')
    .click();

  cy.getDataTest('createWorkout-workoutStepTemplate-workoutStep')
    .should('exist')
    .within(() => {
      cy.getDataTest('workoutInputFields-setDuration')
        .should('exist')
        .type('500');
    });

  cy.getDataTest('createWorkout-workoutStepTemplate-workoutStep')
    .should('exist')
    .within(() => {
      cy.getDataTest('workoutInputFields-setPace-select')
        .should('exist')
        .should('be.visible')
        .click();
    });
  cy.getDataTest('workoutInputFields-setPace-menuItem-basePace')
    .should('be.visible')
    .click();

  //----------------Fill Repeat Step Data-----------------------------------

  cy.getDataTest('createWorkout-repeatStep')
    .should('exist')
    .within(() => {
      cy.getDataTest('repeatStep-reptitionsNumber-select').click();
    });
  cy.getDataTest('repeatStep-reptitionsNumber-menuItem-5')
    .should('exist')
    .should('be.visible')
    .click();

  //------Intense part------------

  cy.getDataTest('createWorkout-repeatStep')
    .should('exist')
    .within(() => {
      cy.getDataTest('workoutInputFields-selectDurationType-select')
        .eq(0)
        .should('be.visible')
        .click();
    });
  cy.getDataTest('workoutInputFields-durationType-distance')
    .should('exist')
    .should('be.visible')
    .click();

  cy.getDataTest('createWorkout-repeatStep')
    .should('exist')
    .within(() => {
      cy.getDataTest('workoutInputFields-selectUnits-select')
        .eq(0)
        .should('exist')
        .should('be.visible')
        .click();
    });
  cy.getDataTest('workoutInputFields-units-meter')
    .should('be.visible')
    .click();

  cy.getDataTest('createWorkout-repeatStep')
    .should('exist')
    .within(() => {
      cy.getDataTest('workoutInputFields-setDuration')
        .eq(0)
        .should('exist')
        .type('500');
    });

  cy.getDataTest('createWorkout-repeatStep')
    .should('exist')
    .within(() => {
      cy.getDataTest('workoutInputFields-setPace-select')
        .eq(0)
        .should('exist')
        .should('be.visible')
        .click();
    });
  cy.getDataTest('workoutInputFields-setPace-menuItem--10s')
    .should('be.visible')
    .click();

  //------Recovery part------------

  cy.getDataTest('createWorkout-repeatStep')
    .should('exist')
    .within(() => {
      cy.getDataTest('workoutInputFields-selectDurationType-select')
        .eq(1)
        .should('be.visible')
        .click();
    });
  cy.getDataTest('workoutInputFields-durationType-distance')
    .should('exist')
    .should('be.visible')
    .click();

  cy.getDataTest('createWorkout-repeatStep')
    .should('exist')
    .within(() => {
      cy.getDataTest('workoutInputFields-selectUnits-select')
        .eq(1)
        .should('exist')
        .should('be.visible')
        .click();
    });
  cy.getDataTest('workoutInputFields-units-meter')
    .should('be.visible')
    .click();

  cy.getDataTest('createWorkout-repeatStep')
    .should('exist')
    .within(() => {
      cy.getDataTest('workoutInputFields-setDuration')
        .eq(1)
        .should('exist')
        .type('500');
    });

  cy.getDataTest('createWorkout-repeatStep')
    .should('exist')
    .within(() => {
      cy.getDataTest('workoutInputFields-setPace-select')
        .eq(1)
        .should('exist')
        .should('be.visible')
        .click();
    });
  cy.getDataTest('workoutInputFields-setPace-menuItem-+10s')
    .should('be.visible')
    .click();

  //----------------Fill Cooldown Data-----------------------------------
  cy.getDataTest('createWorkout-workoutStepTemplate-coolDown')
    .should('exist')
    .within(() => {
      cy.getDataTest('workoutInputFields-selectDurationType-select')
        .should('be.visible')
        .click();
    });
  cy.getDataTest('workoutInputFields-durationType-distance')
    .should('exist')
    .should('be.visible')
    .click();

  cy.getDataTest('createWorkout-workoutStepTemplate-coolDown')
    .should('exist')
    .within(() => {
      cy.getDataTest('workoutInputFields-selectUnits-select')
        .should('exist')
        .should('be.visible')
        .click();
    });
  cy.getDataTest('workoutInputFields-units-kilometer')
    .should('be.visible')
    .click();

  cy.getDataTest('createWorkout-workoutStepTemplate-coolDown')
    .should('exist')
    .within(() => {
      cy.getDataTest('workoutInputFields-setDuration')
        .should('exist')
        .type('1');
    });

  //-----------------------------------------------------------

  cy.get('#workoutNotes').type('This is a test workout');
});
