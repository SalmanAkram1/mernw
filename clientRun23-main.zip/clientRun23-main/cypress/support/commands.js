const backendUrl = Cypress.config('backend');
const loginRequest = Cypress.config('loginRequest');
const login = Cypress.config('login');

Cypress.Commands.add('getDataTest', dataTestSelector => {
  return cy.get(`[data-test="${dataTestSelector}"]`);
});

Cypress.Commands.add('loginAsTrainner', (username, password) => {
  cy.visit('/sign-in');
  cy.intercept('POST', `${backendUrl}/isUser`, req => {
    req.reply({ fixture: '../fixtures/Trainer Login Flow/IsUserResponse' });
  }).as('isUser');

  cy.intercept('POST', loginRequest, req => {
    req.reply({ fixture: '../fixtures/Trainer Login Flow/Login.json' });
  }).as('loginRequest');
  cy.intercept('POST', login, req => {
    req.reply({ fixture: '../fixtures/Trainer Login Flow/LoginResponse.json' });
  }).as('login');
  cy.get('[name="email"]').type(username);
  cy.get('[name="password"]').type(password);
  cy.get('[type="submit"]')
    .should('be.visible')
    .click();
});

Cypress.Commands.add('loginRunner', (username, password) => {
  cy.visit('/sign-in');
  cy.intercept('POST', `${backendUrl}/isUser`, req => {
    req.reply({ fixture: '../fixtures/Runner/IsUserResponse.json' });
  }).as('isUser');

  cy.intercept('POST', loginRequest, req => {
    req.reply({ fixture: '../fixtures/Runner/LoginRequest.json' });
  }).as('loginRequest');
  cy.intercept('POST', login, req => {
    req.reply({
      fixture: '../fixtures/Runner/ApiResponse.json'
    });
  }).as('login');
  cy.get('[name="email"]').type(username);
  cy.get('[name="password"]').type(password);
  cy.get('[type="submit"]')
    .should('be.visible')
    .click();
});

Cypress.Commands.add('logoutUser', () => {
  cy.findByRole('button', { name: /logout/i })
    .should('be.visible')
    .click();
  cy.url().should('equal', `${Cypress.config().baseUrl}/`);
});
