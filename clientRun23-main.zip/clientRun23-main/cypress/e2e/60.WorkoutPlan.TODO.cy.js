import '../support/commands';
import trainer from './users/TrainerUser';
import runner from './users/RunnerUser';
const backendUrl = Cypress.config('backend');

describe('should assert workout plan changes as trainer and runner', () => {
  beforeEach(() => {
    cy.viewport(1920, 1080);
    cy.loginAsTrainner(trainer.email, trainer.password);
  });

  it('should assert runners workouts as trainer', () => {
    cy.findByText(/test runner/i)
      .should('be.visible')
      .click();

    cy.getDataTest('runnerWeeklyPlan-accordion-TestRunner').within(() => {
      cy.getDataTest('Monday').within(() => {
        cy.getDataTest('desktopWeeklyPlanWorkoutLine-workoutName')
          .should('exist')
          .should('be.visible')
          .contains('Test Workout');

        cy.getDataTest('desktopWeeklyPlanWorkoutLine-warmUpDuration')
          .should('be.visible')
          .contains('20min');

        cy.getDataTest('desktopWeeklyPlanWorkoutLine-mainPart-repeatValueCell')
          .should('be.visible')
          .contains('-')
          .contains('5');

        cy.getDataTest(
          'desktopWeeklyPlanWorkoutLine-mainPart-intenseDurationValueCell'
        )
          .should('be.visible')
          .contains('500m');

        cy.getDataTest(
          'desktopWeeklyPlanWorkoutLine-mainPart-intensePaceValueCell'
        )
          .should('be.visible')
          .contains('4:30')
          .contains('4:20');
      });

      cy.getDataTest(
        'desktopWeeklyPlanWorkoutLine-mainPart-recoveryDurationValueCell'
      )
        .should('be.visible')
        .contains('-')
        .contains('500m');

      cy.getDataTest(
        'desktopWeeklyPlanWorkoutLine-mainPart-recoveryPaceValueCell'
      )
        .should('be.visible')
        .contains('-')
        .contains('4:40');

      cy.getDataTest('desktopWeeklyPlanWorkoutLine-coolDownDuration')
        .should('be.visible')
        .contains('1km');

      cy.getDataTest('Wednesday').within(() => {
        cy.getDataTest('desktopWeeklyPlanWorkoutLine-workoutName')
          .should('exist')
          .should('be.visible')
          .contains('Test Workout - Wednesday');

        cy.getDataTest('desktopWeeklyPlanWorkoutLine-warmUpDuration')
          .should('be.visible')
          .contains('3km');

        cy.getDataTest('desktopWeeklyPlanWorkoutLine-mainPart-repeatValueCell')
          .should('be.visible')
          .contains('-');

        cy.getDataTest(
          'desktopWeeklyPlanWorkoutLine-mainPart-intenseDurationValueCell'
        )
          .should('be.visible')
          .contains('500m');

        cy.getDataTest(
          'desktopWeeklyPlanWorkoutLine-mainPart-intensePaceValueCell'
        )
          .should('be.visible')
          .contains('5:30');

        cy.getDataTest(
          'desktopWeeklyPlanWorkoutLine-mainPart-recoveryDurationValueCell'
        )
          .should('be.visible')
          .contains('-');

        cy.getDataTest(
          'desktopWeeklyPlanWorkoutLine-mainPart-recoveryPaceValueCell'
        )
          .should('be.visible')
          .contains('-');

        cy.getDataTest('desktopWeeklyPlanWorkoutLine-coolDownDuration')
          .should('be.visible')
          .contains('1km');
      });

      cy.getDataTest('Friday').within(() => {
        cy.getDataTest('desktopWeeklyPlanWorkoutLine-workoutName')
          .should('exist')
          .should('be.visible')
          .contains('Test Workout - Long Run');

        cy.getDataTest('desktopWeeklyPlanWorkoutLine-warmUpDuration').should(
          'be.empty'
        );

        cy.getDataTest('desktopWeeklyPlanWorkoutLine-mainPart-repeatValueCell')
          .should('be.visible')
          .contains('-');

        cy.getDataTest(
          'desktopWeeklyPlanWorkoutLine-mainPart-intenseDurationValueCell'
        )
          .should('be.visible')
          .contains('20km');

        cy.getDataTest(
          'desktopWeeklyPlanWorkoutLine-mainPart-intensePaceValueCell'
        )
          .should('be.visible')
          .contains('EASY');

        cy.getDataTest(
          'desktopWeeklyPlanWorkoutLine-mainPart-recoveryDurationValueCell'
        )
          .should('be.visible')
          .contains('-');

        cy.getDataTest(
          'desktopWeeklyPlanWorkoutLine-mainPart-recoveryPaceValueCell'
        )
          .should('be.visible')
          .contains('-');
      });
    });
  });

  it('should assert runners workouts as runner', () => {
    cy.logoutUser();
    cy.loginRunner(runner.email, runner.password);

    cy.getDataTest('runnerWeeklyPlan-accordion-TestRunner').within(() => {
      cy.getDataTest('Monday').within(() => {
        cy.getDataTest('desktopWeeklyPlanWorkoutLine-workoutName')
          .should('exist')
          .should('be.visible')
          .contains('Test Workout');

        cy.getDataTest('desktopWeeklyPlanWorkoutLine-warmUpDuration')
          .should('be.visible')
          .contains('20min');

        cy.getDataTest('desktopWeeklyPlanWorkoutLine-mainPart-repeatValueCell')
          .should('be.visible')
          .contains('-')
          .contains('5');

        cy.getDataTest(
          'desktopWeeklyPlanWorkoutLine-mainPart-intenseDurationValueCell'
        )
          .should('be.visible')
          .contains('500m');

        cy.getDataTest(
          'desktopWeeklyPlanWorkoutLine-mainPart-intensePaceValueCell'
        )
          .should('be.visible')
          .contains('4:30')
          .contains('4:20');

        cy.getDataTest(
          'desktopWeeklyPlanWorkoutLine-mainPart-recoveryDurationValueCell'
        )
          .should('be.visible')
          .contains('-')
          .contains('500m');

        cy.getDataTest(
          'desktopWeeklyPlanWorkoutLine-mainPart-recoveryPaceValueCell'
        )
          .should('be.visible')
          .contains('-')
          .contains('4:40');

        cy.getDataTest('desktopWeeklyPlanWorkoutLine-coolDownDuration')
          .should('be.visible')
          .contains('1km');
      });

      cy.getDataTest('Wednesday').within(() => {
        cy.getDataTest('desktopWeeklyPlanWorkoutLine-workoutName')
          .should('exist')
          .should('be.visible')
          .contains('Test Workout - Wednesday');

        cy.getDataTest('desktopWeeklyPlanWorkoutLine-warmUpDuration')
          .should('be.visible')
          .contains('3km');

        cy.getDataTest('desktopWeeklyPlanWorkoutLine-mainPart-repeatValueCell')
          .should('be.visible')
          .contains('-');

        cy.getDataTest(
          'desktopWeeklyPlanWorkoutLine-mainPart-intenseDurationValueCell'
        )
          .should('be.visible')
          .contains('500m');

        cy.getDataTest(
          'desktopWeeklyPlanWorkoutLine-mainPart-intensePaceValueCell'
        )
          .should('be.visible')
          .contains('5:30');

        cy.getDataTest(
          'desktopWeeklyPlanWorkoutLine-mainPart-recoveryDurationValueCell'
        )
          .should('be.visible')
          .contains('-');

        cy.getDataTest(
          'desktopWeeklyPlanWorkoutLine-mainPart-recoveryPaceValueCell'
        )
          .should('be.visible')
          .contains('-');

        cy.getDataTest('desktopWeeklyPlanWorkoutLine-coolDownDuration')
          .should('be.visible')
          .contains('1km');
      });

      cy.getDataTest('Friday').within(() => {
        cy.getDataTest('desktopWeeklyPlanWorkoutLine-workoutName')
          .should('exist')
          .should('be.visible')
          .contains('Test Workout - Long Run');

        cy.getDataTest('desktopWeeklyPlanWorkoutLine-warmUpDuration').should(
          'be.empty'
        );

        cy.getDataTest('desktopWeeklyPlanWorkoutLine-mainPart-repeatValueCell')
          .should('be.visible')
          .contains('-');

        cy.getDataTest(
          'desktopWeeklyPlanWorkoutLine-mainPart-intenseDurationValueCell'
        )
          .should('be.visible')
          .contains('20km');

        cy.getDataTest(
          'desktopWeeklyPlanWorkoutLine-mainPart-intensePaceValueCell'
        )
          .should('be.visible')
          .contains('EASY');

        cy.getDataTest(
          'desktopWeeklyPlanWorkoutLine-mainPart-recoveryDurationValueCell'
        )
          .should('be.visible')
          .contains('-');

        cy.getDataTest(
          'desktopWeeklyPlanWorkoutLine-mainPart-recoveryPaceValueCell'
        )
          .should('be.visible')
          .contains('-');
      });
    });
  });

  it('should change runners workouts as trainer', () => {
    cy.getDataTest('runnerWeeklyPlan-accordion-TestRunner')
      .should('be.visible')
      .click()
      .within(() => {
        cy.getDataTest('Wednesday')
          .should('be.visible')
          .click();
      });
    cy.getDataTest('workoutChangeLayout-main').within(() => {
      cy.findByText(/update workout:/i).should('be.visible');
      cy.findByText(/wednesday/i).should('be.visible');
      cy.getDataTest('workoutChangeLayout-closeRoundedIcon').should(
        'be.visible'
      );
      cy.getDataTest('workoutChangeLayout-workoutNameTextField')
        .should('exist')
        .type(' - Sent');

      cy.findByRole('button', { name: /add warm up/i }).should('be.visible');
      cy.findByRole('button', { name: /add repeat/i }).should('be.visible');
      cy.findByRole('button', { name: /add step/i }).should('be.visible');
      cy.findByRole('button', { name: /add cool down/i }).should('be.visible');

      cy.getDataTest('createWorkout-workoutStepTemplate-warmUp').within(() => {
        cy.getDataTest('workoutInputFields-setDuration').within(() => {
          cy.get('input').should('have.value', '3');
        });
        cy.getDataTest('workoutInputFields-selectUnits-select').contains('km');
        cy.get('#workoutInputFields-selectDurationType-select')
          .should('be.visible')
          .click();
      });
    });
    cy.getDataTest('workoutInputFields-durationType-time')
      .should('be.visible')
      .click();

    cy.getDataTest('workoutChangeLayout-main').within(() => {
      cy.getDataTest('createWorkout-workoutStepTemplate-warmUp').within(() => {
        cy.getDataTest('workoutInputFields-setDuration').within(() => {
          cy.get('input').should('be.empty');
        });

        cy.getDataTest('workoutInputFields-selectUnits-select').contains(
          'minutes'
        );
        cy.getDataTest('workoutInputFields-setDuration').type('20');
      });
    });

    cy.getDataTest('workoutChangeLayout-main').within(() => {
      cy.getDataTest('createWorkout-workoutStepTemplate-workoutStep').within(
        () => {
          cy.getDataTest('workoutInputFields-setDuration')
            .type('{selectAll}')
            .type('1000');

          cy.getDataTest('workoutInputFields-runnerPaceTextField')
            .type('{moveToStart}')
            .type('6')
            .type('{del}');
        }
      );

      cy.getDataTest('workoutChangeLayout-saveButton')
        .should('be.visible')
        .click();
    });
    cy.getDataTest('runnerWeeklyPlan-accordion-TestRunner').within(() => {
      cy.getDataTest('Wednesday').within(() => {
        cy.getDataTest('desktopWeeklyPlanWorkoutLine-workoutName')
          .should('exist')
          .should('be.visible')
          .contains('Test Workout - Wednesday - Sent');

        cy.getDataTest('desktopWeeklyPlanWorkoutLine-warmUpDuration')
          .should('be.visible')
          .contains('20min');

        cy.getDataTest('desktopWeeklyPlanWorkoutLine-mainPart-repeatValueCell')
          .should('be.visible')
          .contains('-');

        cy.getDataTest(
          'desktopWeeklyPlanWorkoutLine-mainPart-intenseDurationValueCell'
        )
          .should('be.visible')
          .contains('1000m');

        cy.getDataTest(
          'desktopWeeklyPlanWorkoutLine-mainPart-intensePaceValueCell'
        )
          .should('be.visible')
          .contains('6:30');
      });
    });
  });

  it('should assert the workout changes as a runner', () => {
    cy.logoutUser();
    cy.loginRunner(runner.email, runner.password);

    cy.getDataTest('runnerWeeklyPlan-accordion-TestRunner').within(() => {
      cy.getDataTest('Monday').within(() => {
        cy.getDataTest('desktopWeeklyPlanWorkoutLine-workoutName')
          .should('exist')
          .should('be.visible')
          .contains('Test Workout');

        cy.getDataTest('desktopWeeklyPlanWorkoutLine-warmUpDuration')
          .should('be.visible')
          .contains('20min');

        cy.getDataTest('desktopWeeklyPlanWorkoutLine-mainPart-repeatValueCell')
          .should('be.visible')
          .contains('-')
          .contains('5');

        cy.getDataTest(
          'desktopWeeklyPlanWorkoutLine-mainPart-intenseDurationValueCell'
        )
          .should('be.visible')
          .contains('500m');

        cy.getDataTest(
          'desktopWeeklyPlanWorkoutLine-mainPart-intensePaceValueCell'
        )
          .should('be.visible')
          .contains('4:30')
          .contains('4:20');

        cy.getDataTest(
          'desktopWeeklyPlanWorkoutLine-mainPart-recoveryDurationValueCell'
        )
          .should('be.visible')
          .contains('-')
          .contains('500m');

        cy.getDataTest(
          'desktopWeeklyPlanWorkoutLine-mainPart-recoveryPaceValueCell'
        )
          .should('be.visible')
          .contains('-')
          .contains('4:40');

        cy.getDataTest('desktopWeeklyPlanWorkoutLine-coolDownDuration')
          .should('be.visible')
          .contains('1km');
      });

      cy.getDataTest('Wednesday').within(() => {
        cy.getDataTest('desktopWeeklyPlanWorkoutLine-workoutName')
          .should('exist')
          .should('be.visible')
          .contains('Test Workout - Wednesday - Sent');

        cy.getDataTest('desktopWeeklyPlanWorkoutLine-warmUpDuration')
          .should('be.visible')
          .contains('20min');

        cy.getDataTest('desktopWeeklyPlanWorkoutLine-mainPart-repeatValueCell')
          .should('be.visible')
          .contains('-');

        cy.getDataTest(
          'desktopWeeklyPlanWorkoutLine-mainPart-intenseDurationValueCell'
        )
          .should('be.visible')
          .contains('1000m');

        cy.getDataTest(
          'desktopWeeklyPlanWorkoutLine-mainPart-intensePaceValueCell'
        )
          .should('be.visible')
          .contains('6:30');

        cy.getDataTest(
          'desktopWeeklyPlanWorkoutLine-mainPart-recoveryDurationValueCell'
        )
          .should('be.visible')
          .contains('-');

        cy.getDataTest(
          'desktopWeeklyPlanWorkoutLine-mainPart-recoveryPaceValueCell'
        )
          .should('be.visible')
          .contains('-');

        cy.getDataTest('desktopWeeklyPlanWorkoutLine-coolDownDuration')
          .should('be.visible')
          .contains('1km');
      });

      cy.getDataTest('Friday').within(() => {
        cy.getDataTest('desktopWeeklyPlanWorkoutLine-workoutName')
          .should('exist')
          .should('be.visible')
          .contains('Test Workout - Long Run');

        cy.getDataTest('desktopWeeklyPlanWorkoutLine-warmUpDuration').should(
          'be.empty'
        );

        cy.getDataTest('desktopWeeklyPlanWorkoutLine-mainPart-repeatValueCell')
          .should('be.visible')
          .contains('-');

        cy.getDataTest(
          'desktopWeeklyPlanWorkoutLine-mainPart-intenseDurationValueCell'
        )
          .should('be.visible')
          .contains('20km');

        cy.getDataTest(
          'desktopWeeklyPlanWorkoutLine-mainPart-intensePaceValueCell'
        )
          .should('be.visible')
          .contains('EASY');

        cy.getDataTest(
          'desktopWeeklyPlanWorkoutLine-mainPart-recoveryDurationValueCell'
        )
          .should('be.visible')
          .contains('-');

        cy.getDataTest(
          'desktopWeeklyPlanWorkoutLine-mainPart-recoveryPaceValueCell'
        )
          .should('be.visible')
          .contains('-');
      });
    });
  });

  it('should remove the workouts of test_runner', () => {
    cy.getDataTest('runnerWeeklyPlan-accordion-TestRunner')
      .should('be.visible')
      .click();

    cy.getDataTest('runnerWeeklyPlan-accordion-TestRunner').within(() => {
      cy.getDataTest('Monday')
        .should('be.visible')
        .click();
    });
    cy.getDataTest('workoutChangeLayout-main').within(() => {
      cy.getDataTest('workoutChangeLayout-removeButton')
        .should('exist')
        .click();
    });

    cy.getDataTest('runnerWeeklyPlan-accordion-TestRunner').within(() => {
      cy.getDataTest('Wednesday')
        .should('be.visible')
        .click();
    });
    cy.getDataTest('workoutChangeLayout-main').within(() => {
      cy.getDataTest('workoutChangeLayout-removeButton')
        .should('exist')
        .click();
    });

    cy.getDataTest('runnerWeeklyPlan-accordion-TestRunner').within(() => {
      cy.getDataTest('Friday')
        .should('be.visible')
        .click();
    });
    cy.getDataTest('workoutChangeLayout-main').within(() => {
      cy.getDataTest('workoutChangeLayout-removeButton')
        .should('exist')
        .click();
    });

    const weekDays = [
      'Sunday',
      'Monday',
      'Tuesday',
      'Wednesday',
      'Thursday',
      'Friday',
      'Saturday'
    ];
    cy.getDataTest('runnerWeeklyPlan-accordion-TestRunner').within(() => {
      for (const day of weekDays) {
        cy.getDataTest(day).within(() => {
          cy.get('th').should('have.length', 1);
          cy.get('td').should('have.length', 0);
        });
      }
    });
  });

  it('should assert that runners workouts removed', () => {
    cy.logoutUser();
    cy.loginRunner(runner.email, runner.password);

    const weekDays = [
      'Sunday',
      'Monday',
      'Tuesday',
      'Wednesday',
      'Thursday',
      'Friday',
      'Saturday'
    ];
    for (const day of weekDays) {
      cy.getDataTest(day).within(() => {
        cy.get('th').should('have.length', 1);
        cy.get('td').should('have.length', 0);
      });
    }
  });

  // TODO: Assert that a runner can't chagne their worktous (only a trainer user can)
  // -------------------------------------------------------------------------------------------
  // it('should assert that runner cant change their workouts', () => {
  //   cy.logoutUser();
  //   cy.loginRunner(runner.email, runner.password);

  //   const weekDays = [
  //     'Sunday',
  //     'Monday',
  //     'Tuesday',
  //     'Wednesday',
  //     'Thursday',
  //     'Friday',
  //     'Saturday'
  //   ];
  //   for (const day of weekDays) {
  //     cy.getDataTest(day).click({ force: true });
  //     // Use once() binding for just this fail
  //     cy.once('fail', err => {
  //       // Capturing the fail event swallows it and lets the test succeed

  //       // Now look for the expected messages
  //       expect(err.message).to.include(
  //         'cy.click() failed because this element'
  //       );

  //       done();
  //     });

  //     cy.getDataTest(day).should('be.visible')
  //       .click()
  //       .then(x => {
  //         // Only here if click succeeds (so test fails)
  //         done(
  //           new Error(
  //             'Expected button NOT to be clickable, but click() succeeded'
  //           )
  //         );
  //       });
  //   }
  // });

  // This is an old stuff that needs to be reviewed and check that we didn't left important tests
  // or part of test out of scope
  // -------------------------------------------------------------------------------------------
  // it('should not allow runner to edit workout plan', () => {
  //   cy.intercept(
  //     'POST',
  //     `${backendUrl}/workout/runnersWeeklyWorkoutPlan`,
  //     req => {
  //       req.reply({
  //         fixture: '../fixtures/Workout Plan/Runner/WeeklyResponse.json'
  //       });
  //     }
  //   ).as('weeklyPlan');
  //   cy.loginRunner(runner.email, runner.password);
  //   cy.findAllByText(/workout plan/i).should('have.length', 1);
  //   cy.findAllByText(/workout plan/i)
  //     .eq(0)
  //     .click({
  //       force: true,
  //       scrollBehavior: false
  //     });
  //   cy.findByText(/Runner Test/i).should('be.visible').click();
  //   cy.logoutUser();
  // });
  // it('trainner should edit workout plan workout plan', () => {
  //   cy.loginAsTrainner(trainer.email, trainer.password);
  //   cy.intercept(
  //     'POST',
  //     `${backendUrl}/workout/runnersWeeklyWorkoutPlan`,
  //     req => {
  //       req.reply({
  //         fixture: '../fixtures/Workout Plan/Trainer/WeeklyResponse.json'
  //       });
  //     }
  //   ).as('weeklyPlan');
  //   cy.wait(200);
  //   cy.findAllByText(/workout plan/i).should('have.length', 2);
  //   cy.findAllByText(/workout plan/i)
  //     .eq(1)
  //     .click({
  //       force: true,
  //       scrollBehavior: false
  //     });

  //   cy.findByText(/Runner Test/i).should('be.visible');
  //   // cy.findByText(/hello/i).should('be.visible').click();
  //   // cy.findByText(/Update workout:/i).should('be.visible');
  //   cy.logoutUser();
  // });

  afterEach(() => {
    cy.logoutUser();
  });
});
