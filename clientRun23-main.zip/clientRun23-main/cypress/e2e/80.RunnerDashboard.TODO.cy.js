import runner from './users/RunnerUser';
import '../support/commands';

describe('Runner Dashboard', () => {
  beforeEach(() => {
    cy.viewport(1920, 1080);
    cy.loginRunner(runner.email, runner.password);
  });
  afterEach(() => {
    cy.logoutUser();
  });
  it('should display the runner dashboard', () => {
    const daysOfWeek = [
      'Monday',
      'Tuesday',
      'Wednesday',
      'Thursday',
      'Friday',
      'Saturday',
      'Sunday'
    ];

    cy.findByRole('button', { name: /dashboard/i })
      .should('be.visible')
      .should('have.attr', 'href', '/dashboard')
      .click();

    for (const day of daysOfWeek) {
      cy.findByText(new RegExp(day, 'i')).should('be.visible');
    }
    cy.findByText(runner.email).should('be.visible');

    cy.findAllByRole('button', { name: /workout plan/i }).then($el => {
      cy.get($el[0])
        .should('have.attr', 'href', '/workoutPlan')
        .should('be.visible');
    });

    cy.findByRole('button', { name: /logout/i })
      .should('be.visible')
      .should('have.attr', 'href', '/sign-in');

    cy.url().should('include', '/dashboard');
    //   TODO: assert search field and choose Day/week and dayView
  });
  it('should render workout plan page', () => {
    cy.findByText(/workout plan/i)
      .should('be.visible')
      .click();
    cy.url().should('include', '/workoutPlan');
    // TODO: assert data after meeting tommorow
  });
  it('should redirect to garmin sync ', () => {
    cy.findByText(/garmin sync/i).should('be.visible');
    // TODO: uncomment after meeting tommorow
    // cy.findByText(/garmin sync/i).then($el => {
    //   cy.get($el[0])
    //     .should('have.attr', 'href', '//')
    //     .should('be.visible')
    //     .click();
    //   cy.url().should('include', 'garmin');
    //   cy.visit('/dashboard');
    // });
  });
});
