import '../support/commands';
import '../support/workoutCommands';
import trainer from './users/TrainerUser';

const daysOfWeek = [
  'Monday',
  'Tuesday',
  'Wednesday',
  'Thursday',
  'Friday',
  'Saturday',
  'Sunday'
];

describe('Create workout plan', () => {
  beforeEach(() => {
    cy.viewport(1920, 1080);
    cy.loginAsTrainner(trainer.email, trainer.password);
  });

  it('should render the CreateWorkoutPlan page', () => {
    cy.findByText(/create workout plan/i)
      .should('be.visible')
      .click();

    for (const day of daysOfWeek) {
      cy.findByText(new RegExp(day, 'i')).should('be.visible');
    }

    cy.findByText(/create a workout/i).should('be.visible');
    cy.findByText(/Select from existing workout templates/i).should(
      'be.visible'
    );
    cy.getDataTest('workoutTemplateSelection-select').should('be.visible');
    cy.get('#workoutName').should('be.visible');
    cy.findByRole('button', { name: /add warm up/i }).should('be.visible');
    cy.findByRole('button', { name: /add repeat/i }).should('be.visible');
    cy.findByRole('button', { name: /add step/i }).should('be.visible');
    cy.findByRole('button', { name: /add cool down/i }).should('be.visible');
    cy.get('#workoutNotes').should('be.visible');

    cy.getDataTest('createWorkout-saveWorkoutAsATemplateButton').should(
      'be.visible'
    );
    cy.getDataTest('createWorkout-removeButton').should('be.visible');
    cy.getDataTest('createWorkout-saveButton').should('be.visible');
    cy.getDataTest('createWorkout-previewWeeklyWorkoutsButton').should(
      'be.visible'
    );
  });

  it('should check the calendar component', () => {
    cy.findByText(/create workout plan/i)
      .should('be.visible')
      .click();
    cy.getDataTest('weekCalendar-openCalendarButton')
      .should('be.visible')
      .click();
    cy.getDataTest('customCalendar-datePickerComponent').should('be.visible');
    cy.getDataTest('customCalendar-closeCalendarIconButton')
      .should('be.visible')
      .click();
    cy.getDataTest('customCalendar-closeCalendarIconButton').should(
      'not.exist'
    );
  });

  it('should create a workout plan', () => {
    cy.findByText(/create workout plan/i)
      .should('be.visible')
      .click();

    cy.getDataTest('weekCalendar-previousWeekButton')
      .should('be.visible')
      .click();
    cy.getDataTest('Monday')
      .should('be.visible')
      .click();

    cy.removeAllSteps();

    cy.findByRole('button', { name: /add warm up/i })
      .should('be.visible')
      .click();
    cy.findByRole('button', { name: /add step/i })
      .should('be.visible')
      .click();
    cy.findByRole('button', { name: /add repeat/i })
      .should('be.visible')
      .click();
    cy.findByRole('button', { name: /add cool down/i })
      .should('be.visible')
      .click();

    cy.getDataTest('repeatStep-deleteButton').should('exist');
    cy.getDataTest('workoutStepTemplate-deleteButton').should('have.length', 3);

    cy.createFullWorkout();

    cy.getDataTest('Monday').within(() => {
      cy.getDataTest('weekCalendar-fiberManualRecordIcon').should('not.exist');
    });

    cy.getDataTest('createWorkout-saveButton')
      .should('be.visible')
      .click();
    cy.findByText(/The workout was saved to plan successfully/i).should(
      'be.visible'
    );
    cy.getDataTest('Monday').within(() => {
      cy.getDataTest('weekCalendar-fiberManualRecordIcon')
        .should('exist')
        .should('be.visible');
    });
  });

  it('should save/update a workout as a workout template', () => {
    cy.findByText(/create workout plan/i)
      .should('be.visible')
      .click();
    cy.createFullWorkout();
    cy.getDataTest('createWorkout-saveWorkoutAsATemplateButton')
      .should('be.visible')
      .click();
    // Since we currently don't a way to delete and handle the templates,
    // we assert either one of two options for notification re the workout template (saved or updated)
    cy.findByText(text => {
      return (
        text.match(/The workout template was saved to database/i) ||
        text.match(/The workout template was updated successfully/i)
      );
    }).should('be.visible');
  });

  it('should create a workout from a workout template', () => {
    cy.findByText(/create workout plan/i)
      .should('be.visible')
      .click();

    cy.getDataTest('weekCalendar-previousWeekButton')
      .should('be.visible')
      .click();

    cy.getDataTest('Wednesday')
      .should('be.visible')
      .click();
    cy.findByText(/test workout/i).should('not.exist');
    cy.getDataTest('workoutTemplateSelection-select')
      .should('be.visible')
      .click();
    cy.findByText(/test workout/i)
      .should('be.visible')
      .click();
    cy.getDataTest('createWorkout-saveButton')
      .should('be.visible')
      .click();
    cy.getDataTest('Wednesday').within(() => {
      cy.getDataTest('weekCalendar-fiberManualRecordIcon')
        .should('exist')
        .should('be.visible');
    });

    cy.getDataTest('Saturday')
      .should('be.visible')
      .click();
    cy.findByText(/test workout/i).should('not.exist');
    cy.getDataTest('workoutTemplateSelection-select')
      .should('be.visible')
      .click();
    cy.findByText(/test workout/i)
      .should('be.visible')
      .click();
    cy.getDataTest('createWorkout-saveButton')
      .should('be.visible')
      .click();
    cy.getDataTest('Wednesday').within(() => {
      cy.getDataTest('weekCalendar-fiberManualRecordIcon')
        .should('exist')
        .should('be.visible');
    });
  });

  it('should preview the workout correctly', () => {
    cy.findByText(/create workout plan/i)
      .should('be.visible')
      .click();
    cy.getDataTest('weekCalendar-previousWeekButton')
      .should('be.visible')
      .click();
    cy.getDataTest('createWorkout-previewWeeklyWorkoutsButton')
      .should('be.visible')
      .click();

    cy.findByText(/weekly plan preview/i).should('be.visible');

    cy.getDataTest('desktopWeeklyPlanTableHeading-warmUpTableCell').should(
      'not.be.visible'
    );
    cy.getDataTest('desktopWeeklyPlanTableHeading-repetitionsTableCell').should(
      'not.be.visible'
    );
    cy.getDataTest('desktopWeeklyPlanTableHeading-intensePartTableCell').should(
      'not.be.visible'
    );
    cy.getDataTest(
      'desktopWeeklyPlanTableHeading-recoveryPartTableCell'
    ).should('not.be.visible');
    cy.getDataTest('desktopWeeklyPlanTableHeading-coolDownTableCell').should(
      'not.be.visible'
    );

    cy.findByText(/test runner/i)
      .should('be.visible')
      .click();

    cy.getDataTest('runnerWeeklyPlan-accordion-TestRunner').within(() => {
      for (const day of daysOfWeek) {
        cy.getDataTest(day).should('exist');
      }

      cy.getDataTest('desktopWeeklyPlanTableHeading-warmUpTableCell').should(
        'be.visible'
      );
      cy.getDataTest(
        'desktopWeeklyPlanTableHeading-repetitionsTableCell'
      ).should('be.visible');
      cy.getDataTest(
        'desktopWeeklyPlanTableHeading-intensePartTableCell'
      ).should('be.visible');
      cy.getDataTest(
        'desktopWeeklyPlanTableHeading-recoveryPartTableCell'
      ).should('be.visible');
      cy.getDataTest('desktopWeeklyPlanTableHeading-coolDownTableCell').should(
        'be.visible'
      );

      cy.getDataTest('Monday').within(() => {
        cy.getDataTest('desktopWeeklyPlanWorkoutLine-workoutName')
          .should('exist')
          .should('be.visible')
          .contains('Test Workout');

        cy.getDataTest('desktopWeeklyPlanWorkoutLine-warmUpDuration')
          .should('be.visible')
          .contains('20min');

        cy.getDataTest('desktopWeeklyPlanWorkoutLine-mainPart-repeatValueCell')
          .should('be.visible')
          .contains('-')
          .contains('5');

        cy.getDataTest(
          'desktopWeeklyPlanWorkoutLine-mainPart-intenseDurationValueCell'
        )
          .should('be.visible')
          .contains('500m');

        cy.getDataTest(
          'desktopWeeklyPlanWorkoutLine-mainPart-intensePaceValueCell'
        )
          .should('be.visible')
          .contains('4:30')
          .contains('4:20');

        cy.getDataTest(
          'desktopWeeklyPlanWorkoutLine-mainPart-recoveryDurationValueCell'
        )
          .should('be.visible')
          .contains('-')
          .contains('500m');

        cy.getDataTest(
          'desktopWeeklyPlanWorkoutLine-mainPart-recoveryPaceValueCell'
        )
          .should('be.visible')
          .contains('-')
          .contains('4:40');

        cy.getDataTest('desktopWeeklyPlanWorkoutLine-coolDownDuration')
          .should('be.visible')
          .contains('1km');
      });
    });
    cy.visit('/');
  });

  it('should check handeling the workout plan preview modal', () => {
    cy.findByText(/create workout plan/i)
      .should('be.visible')
      .click();
    cy.getDataTest('weekCalendar-previousWeekButton')
      .should('be.visible')
      .click();
    cy.getDataTest('createWorkout-previewWeeklyWorkoutsButton')
      .should('be.visible')
      .click();

    cy.findByText(/test runner/i)
      .should('be.visible')
      .click();
    cy.getDataTest('runnerWeeklyPlan-accordion-TestRunner').within(() => {
      cy.getDataTest('Wednesday')
        .should('be.visible')
        .click();
    });
    cy.getDataTest('workoutChangeLayout-main').within(() => {
      cy.findByText(/update workout:/i).should('be.visible');
      cy.findByText(/wednesday/i).should('be.visible');
      cy.getDataTest('workoutChangeLayout-closeRoundedIcon').should(
        'be.visible'
      );
      cy.getDataTest('workoutChangeLayout-workoutNameTextField')
        .should('exist')
        .type(' - Wednesday');

      cy.findByRole('button', { name: /add warm up/i }).should('be.visible');
      cy.findByRole('button', { name: /add repeat/i }).should('be.visible');
      cy.findByRole('button', { name: /add step/i }).should('be.visible');
      cy.findByRole('button', { name: /add cool down/i }).should('be.visible');

      cy.getDataTest('createWorkout-workoutStepTemplate-warmUp').within(() => {
        cy.get('#workoutInputFields-selectDurationType-select')
          .should('be.visible')
          .click();
      });
    });
    cy.getDataTest('workoutInputFields-durationType-distance')
      .should('be.visible')
      .click();

    cy.getDataTest('workoutChangeLayout-main').within(() => {
      cy.getDataTest('createWorkout-workoutStepTemplate-warmUp').within(() => {
        cy.getDataTest('workoutInputFields-selectUnits-select')
          .should('be.visible')
          .click();
      });
    });
    cy.getDataTest('workoutInputFields-units-kilometer')
      .should('be.visible')
      .click();

    cy.getDataTest('workoutChangeLayout-main').within(() => {
      cy.getDataTest('createWorkout-workoutStepTemplate-warmUp').within(() => {
        cy.getDataTest('workoutInputFields-setDuration').type('3');
      });

      cy.getDataTest('createWorkout-workoutStepTemplate-workoutStep').within(
        () => {
          cy.getDataTest('workoutInputFields-runnerPaceTextField')
            .type('{moveToStart}')
            .type('5')
            .type('{del}');
        }
      );

      cy.getDataTest('createWorkout-repeatStep').within(() => {
        cy.getDataTest('repeatStep-deleteButton')
          .should('be.visible')
          .click();
      });
    });
    cy.getDataTest('workoutChangeLayout-saveButton')
      .should('exist')
      .click();

    cy.getDataTest('runnerWeeklyPlan-accordion-TestRunner').within(() => {
      cy.getDataTest('Wednesday').within(() => {
        cy.getDataTest('desktopWeeklyPlanWorkoutLine-workoutName')
          .should('exist')
          .should('be.visible')
          .contains('Test Workout - Wednesday');

        cy.getDataTest('desktopWeeklyPlanWorkoutLine-warmUpDuration')
          .should('be.visible')
          .contains('3km');

        cy.getDataTest('desktopWeeklyPlanWorkoutLine-mainPart-repeatValueCell')
          .should('be.visible')
          .contains('-');

        cy.getDataTest(
          'desktopWeeklyPlanWorkoutLine-mainPart-intenseDurationValueCell'
        )
          .should('be.visible')
          .contains('500m');

        cy.getDataTest(
          'desktopWeeklyPlanWorkoutLine-mainPart-intensePaceValueCell'
        )
          .should('be.visible')
          .contains('5:30');
      });
      cy.getDataTest('Friday').within(() => {
        cy.get('th')
          .should('be.visible')
          .click();
      });
    });
    cy.getDataTest('workoutChangeLayout-main').within(() => {
      cy.findByText(/update workout:/i).should('be.visible');
      cy.findByText(/friday/i).should('be.visible');
      cy.getDataTest('workoutChangeLayout-closeRoundedIcon').should(
        'be.visible'
      );

      cy.findByRole('button', { name: /add warm up/i }).should('be.visible');
      cy.findByRole('button', { name: /add repeat/i }).should('be.visible');
      cy.findByRole('button', { name: /add step/i })
        .should('be.visible')
        .click();
      cy.findByRole('button', { name: /add cool down/i }).should('be.visible');

      cy.getDataTest('workoutChangeLayout-workoutNameTextField')
        .should('exist')
        .type('Test Workout - Long Run');
    });

    cy.getDataTest('workoutChangeLayout-main').within(() => {
      cy.getDataTest('createWorkout-workoutStepTemplate-workoutStep').within(
        () => {
          cy.get('#workoutInputFields-selectDurationType-select')
            .should('be.visible')
            .click();
        }
      );
    });
    cy.getDataTest('workoutInputFields-durationType-distance')
      .should('be.visible')
      .click();

    cy.getDataTest('workoutChangeLayout-main').within(() => {
      cy.getDataTest('createWorkout-workoutStepTemplate-workoutStep').within(
        () => {
          cy.getDataTest('workoutInputFields-selectUnits-select')
            .should('be.visible')
            .click();
        }
      );
    });
    cy.getDataTest('workoutInputFields-units-kilometer')
      .should('be.visible')
      .click();

    cy.getDataTest('workoutChangeLayout-main').within(() => {
      cy.getDataTest('createWorkout-workoutStepTemplate-workoutStep').within(
        () => {
          cy.getDataTest('workoutInputFields-setDuration').type('20');
        }
      );
    });

    cy.getDataTest('workoutChangeLayout-saveButton')
      .should('be.visible')
      .click();

    cy.getDataTest('runnerWeeklyPlan-accordion-TestRunner').within(() => {
      cy.getDataTest('Friday').within(() => {
        cy.getDataTest('desktopWeeklyPlanWorkoutLine-workoutName')
          .should('exist')
          .should('be.visible')
          .contains('Test Workout - Long Run');

        cy.getDataTest(
          'desktopWeeklyPlanWorkoutLine-mainPart-intenseDurationValueCell'
        )
          .should('be.visible')
          .contains('20km');

        cy.getDataTest(
          'desktopWeeklyPlanWorkoutLine-mainPart-intensePaceValueCell'
        )
          .should('be.visible')
          .contains('EASY');
      });
    });

    cy.getDataTest('runnerWeeklyPlan-accordion-TestRunner').within(() => {
      cy.getDataTest('Saturday').within(() => {
        cy.get('th').should('have.length', 1);
        cy.get('td').should('have.length', 6);
      });
    });

    cy.getDataTest('runnerWeeklyPlan-accordion-TestRunner').within(() => {
      cy.getDataTest('Saturday')
        .should('be.visible')
        .click();
    });

    cy.getDataTest('workoutChangeLayout-main').within(() => {
      cy.getDataTest('workoutChangeLayout-removeButton')
        .should('exist')
        .click();
    });

    cy.getDataTest('runnerWeeklyPlan-accordion-TestRunner').within(() => {
      cy.getDataTest('Saturday').within(() => {
        cy.get('th').should('have.length', 1);
        cy.get('td').should('have.length', 0);
      });
    });

    cy.getDataTest('mainWeeklyWorkoutPlan-wideScreenView-sendToRunnersButton')
      .should('be.visible')
      .click();
  });

  it('should remove the test trainer weekly workouts plan', () => {
    cy.findByText(/create workout plan/i)
      .should('be.visible')
      .click();
    cy.getDataTest('weekCalendar-previousWeekButton')
      .should('be.visible')
      .click();

    cy.getDataTest('Monday')
      .should('be.visible')
      .click();
    cy.getDataTest('Monday').within(() => {
      cy.getDataTest('weekCalendar-fiberManualRecordIcon')
        .should('exist')
        .should('be.visible');
    });

    cy.getDataTest('createWorkout-removeButton')
      .should('be.visible')
      .click();
    cy.findByText(/The workout template was removed/i).should('be.visible');
    cy.getDataTest('Monday').within(() => {
      cy.getDataTest('weekCalendar-fiberManualRecordIcon').should('not.exist');
    });

    cy.getDataTest('Wednesday')
      .should('be.visible')
      .click();
    cy.getDataTest('Wednesday').within(() => {
      cy.getDataTest('weekCalendar-fiberManualRecordIcon')
        .should('exist')
        .should('be.visible');
    });

    cy.getDataTest('createWorkout-removeButton')
      .should('be.visible')
      .click();
    cy.findByText(/The workout template was removed/i).should('be.visible');
    cy.getDataTest('Wednesday').within(() => {
      cy.getDataTest('weekCalendar-fiberManualRecordIcon').should('not.exist');
    });

    cy.getDataTest('Saturday')
      .should('be.visible')
      .click();
    cy.getDataTest('Saturday').within(() => {
      cy.getDataTest('weekCalendar-fiberManualRecordIcon')
        .should('exist')
        .should('be.visible');
    });

    cy.getDataTest('createWorkout-removeButton')
      .should('be.visible')
      .click();
    cy.findByText(/The workout template was removed/i).should('be.visible');
    cy.getDataTest('Saturday').within(() => {
      cy.getDataTest('weekCalendar-fiberManualRecordIcon').should('not.exist');
    });
  });

  afterEach(() => {
    cy.logoutUser();
  });
});
