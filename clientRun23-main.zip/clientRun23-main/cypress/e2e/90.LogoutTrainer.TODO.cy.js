import trainer from './users/TrainerUser';
import '../support/commands';

describe('Logout Trainer', () => {
  beforeEach(() => {
    cy.viewport(1920, 1080);
    cy.loginAsTrainner(trainer.email, trainer.password);
  });
  it('should logout trainer without errors', () => {
    cy.findByRole('button', { name: /logout/i })
      .should('be.visible')
      .click();
    cy.url().should('equal', `${Cypress.config().baseUrl}/`);
    cy.window().then(win => {
      // i cant find the value in session, we add it key and value below
      // win.localStorage.setItem('key', 'value');
    });
  });
});
