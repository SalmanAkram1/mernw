import trainer from './users/TrainerUser';
const backendUrl = Cypress.config('backend');

import runnerGroup from './users/RunnerGroup';
import '../support/commands';

describe('Runnerlist Crud', () => {
  beforeEach(() => {
    cy.viewport(1920, 1080);
    cy.loginAsTrainner(trainer.email, trainer.password);
  });
  afterEach(() => {
    cy.logoutUser();
  });

  it('should add runner', () => {
    cy.findByText(/runners list/i).should('be.visible');
    cy.findByText(/Runners list/i).click({
      force: true,
      scrollBehavior: false
    });
    cy.findByRole('button', { name: '+ Add Runner' }).should('be.visible');
    cy.findByRole('button', { name: '+ Add Runner' }).click({
      force: true,
      scrollBehavior: false
    });

    cy.findByText(/Runner's Settings/i).should('be.visible');
    cy.findByText(/Here you can edit new runner's information/i).should(
      'be.visible'
    );

    cy.get('.MuiCardActions-root.MuiCardActions-spacing button').should(
      'be.visible'
    );

    //placeholder text assertion and type
    cy.get('[name="firstName"]').should('be.visible');
    cy.get('[name="firstName"]').type(runnerGroup.firstName);
    cy.get('[name="lastName"]').should('be.visible');
    cy.get('[name="lastName"]').type(runnerGroup.lastName);
    cy.get('[name="paceMinutes"]').should('be.visible');
    cy.get('[name="paceMinutes"]').type(runnerGroup.paceMinutes);
    cy.get('[name="paceSeconds"]').should('be.visible');
    cy.get('[name="paceSeconds"]').type(runnerGroup.paceSeconds);
    cy.get('[name="runsPerWeek"]').should('be.visible');
    cy.get('[name="runsPerWeek"]')
      .clear()
      .type(runnerGroup.runsPerWeek);
    cy.get('[name="runningGroup"]').should('be.visible');
    cy.get('[name="runningGroup"]').should('be.disabled');
    cy.getDataTest('subGroup-textField')
      .should('be.visible')
      .click();
    cy.getDataTest('subGroupRunner-selectGeneral')
      .should('be.visible')
      .click();
    cy.get('[name="email"]').should('be.visible');
    cy.get('[name="email"]').type(runnerGroup.email);
    cy.get('[name="mobile"]').should('be.visible');
    cy.get('[name="mobile"]').type(runnerGroup.mobile);

    cy.intercept('POST', `${backendUrl}/runner`).as('runnerRequest');
    // clicking on button
    cy.get('.MuiCardActions-root.MuiCardActions-spacing button')
      .should('be.visible')
      .click({
        force: true
      });

    //ASSERTING DATA THAT SHOULD PASSED TO THE API
    cy.wait('@runnerRequest').then(({ request, response }) => {
      expect(request.body.firstName).equal(response.body.runner.firstName);
      expect(request.body.lastName).equal(response.body.runner.lastName);
      expect(request.body.email).equal(response.body.runner.email);
      expect(request.body.mobile).equal(response.body.runner.mobile);
      expect(request.body).to.have.property('paceMinutes');
      expect(request.body.paceMinutes).to.equal(`0${runnerGroup.paceMinutes}`);
      expect(request.body.paceSeconds).to.equal(`0${runnerGroup.paceSeconds}`);
      expect(request.body.runsPerWeek).equal(
        `${response.body.runner.runsPerWeek}`
      );
      expect(request.body.runningGroup).equal(
        response.body.runner.runningGroup
      );
    });
    cy.findByText(/sub group/i).should('be.visible');
    cy.findByText(/base pace/i).should('be.visible');
    cy.findByText(/runs per week/i).should('be.visible');
    cy.findByText(/mobile/i).should('be.visible');

    cy.findAllByText(`${runnerGroup.firstName} ${runnerGroup.lastName}`).should(
      'have.length.gt',
      0
    );

    cy.findAllByText(`${runnerGroup.subRunningGroup}`).should(
      'have.length.gt',
      0
    );

    cy.findAllByText(
      `${runnerGroup.paceMinutes}:${runnerGroup.paceSeconds}`
    ).should('have.length.gt', 0);

    cy.findAllByText(`${runnerGroup.runsPerWeek}`).should('have.length.gt', 0);

    cy.findAllByText(`${runnerGroup.mobile}`).should('have.length.gt', 0);
  });

  it("it should update runner's details", () => {
    cy.findByText(/runners list/i).should('be.visible');
    cy.findByText(/Runners list/i).click({
      force: true,
      scrollBehavior: false
    });

    cy.findByText(/New Runner/i)
      .parent()
      .within(() => {
        cy.get('[title="Edit User"]')
          .should('be.visible')
          .click();
      });

    cy.get('.MuiCardActions-root.MuiCardActions-spacing button').should(
      'be.visible'
    );

    //placeholder text assertion and type
    cy.get('[name="firstName"]').should('be.visible');

    cy.get('[name="lastName"]').should('be.visible');

    cy.get('[name="paceMinutes"]').should('be.visible');

    cy.get('[name="paceSeconds"]').should('be.visible');

    cy.get('[name="runsPerWeek"]').should('be.visible');

    cy.get('[name="runningGroup"]').should('be.visible');
    // TODO: at the time of submit the running field is disbaled, when edit it its enabled

    cy.getDataTest('subGroup-textField').should('be.visible');

    cy.get('[name="email"]').should('be.visible');
    cy.get('[name="mobile"]').should('be.visible');

    cy.get('[name="firstName"]')
      .clear()
      .type(`a${runnerGroup.firstName}`);
    cy.get('[name="lastName"]')
      .clear()
      .type(`a${runnerGroup.lastName}`);
    cy.get('[name="paceMinutes"]')
      .clear()
      .type('30');
    cy.get('[name="paceSeconds"]')
      .clear()
      .type('10');
    cy.get('[name="runsPerWeek"]')
      .clear()
      .type(`a${runnerGroup.runsPerWeek}`);
    cy.getDataTest('subGroup-textField')
      .should('be.visible')
      .click();
    // .clear()
    // .type(`a${runnerGroup.subRunningGroup}`);
    cy.getDataTest('subGroupRunner-selectGeneral')
      .should('be.visible')
      .click();
    cy.get('[name="email"]')
      .clear()
      .type(`a${runnerGroup.email}`);
    cy.get('[name="mobile"]')
      .clear()
      .type(`${runnerGroup.mobile}`);

    cy.intercept('POST', `${backendUrl}/runner`).as('runnerRequest');
    // clicking on button
    cy.get('.MuiCardActions-root.MuiCardActions-spacing button')
      .should('be.visible')
      .click({
        force: true
      });

    cy.wait('@runnerRequest').then(({ request, response }) => {
      expect(request.body.firstName).equal(response.body.runner.firstName);
      expect(request.body.lastName).equal(response.body.runner.lastName);
      expect(request.body.email).equal(response.body.runner.email);
      expect(request.body.mobile).equal(response.body.runner.mobile);
      expect(request.body).to.have.property('paceMinutes');
      expect(request.body.paceMinutes).to.equal('30');
      expect(request.body.paceSeconds).to.equal('10');
      expect(request.body.runsPerWeek).equal(response.body.runner.runsPerWeek);
      expect(request.body.runningGroup).equal(
        response.body.runner.runningGroup
      );
    });

    cy.findAllByText(
      `a${runnerGroup.firstName} a${runnerGroup.lastName}`
    ).should('have.length.gt', 0);

    cy.findAllByText(`${runnerGroup.subRunningGroup}`).should(
      'have.length.gt',
      0
    );

    cy.findAllByText('30:10').should('have.length.gt', 0);

    cy.findAllByText('5').should('have.length.gt', 0);
  });

  // it('it should delete a running group', () => {
  //   // todo this will be tested once the functionlity implemented
  // });
});
