const runner = {
  email: 'test_runner@sub.cx',
  password: 'test_runner'
};

export default runner;
