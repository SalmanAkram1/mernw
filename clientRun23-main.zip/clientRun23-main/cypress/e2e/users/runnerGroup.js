const runnerGroup = {
  firstName: 'New',
  lastName: 'Runner',
  email: 'new_runner@sub.cx',
  mobile: '+1 234 567 8910',
  paceMinutes: '10',
  paceSeconds: '30',
  runsPerWeek: 5,
  runningGroup: 'Testing',
  subRunningGroup: 'General',
  isActive: false,
  isRegistered: true
};
export default runnerGroup;
