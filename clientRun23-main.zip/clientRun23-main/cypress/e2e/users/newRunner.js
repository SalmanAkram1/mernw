const newRunner = {
  runnerGroup: 'Example',
  fname: 'john',
  lname: 'doe',
  mobile: '+913133144444',
  email: 'new_runner@sub.cx',
  password: 'test1234'
};
export default newRunner;
