const trainer = {
  email: 'test_trainer@sub.cx',
  password: 'test_trainer',
  wrongPassword: 'wrongPassword'
};

export default trainer;
