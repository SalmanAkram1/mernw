const newTrainer = {
  runnerGroup: 'Testing',
  fname: 'New',
  lname: 'Trainer',
  mobile: '+12345678910',
  email: 'new_trainer@sub.cx',
  password: 'test1234'
};
export default newTrainer;
