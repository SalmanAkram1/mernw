import trainer from './users/TrainerUser';
import '../support/commands';

const backendUrl = Cypress.config('backend');
const loginRequest = Cypress.config('loginRequest');
const login = Cypress.config('login');

describe('Login Flow', () => {
  beforeEach(() => {
    cy.viewport(1920, 1080);
    // Visit the login page or the URL where your login page resides
    cy.visit('/sign-in');
  });

  it('should reset password successfully', () => {
    //need to change this intercept after rajib will fix the issue
    cy.intercept('POST', /.*\/accounts.*/, req => {
      req.reply({
        kind: 'identitytoolkit#GetOobConfirmationCodeResponse',
        email: `${trainer.email}`
      });
    }).as('resetPassword');

    cy.findByText(/forgot password?/i).should('be.visible');
    cy.get('[data-test="signIn-forgetPasswordConfimationDialog"]').should(
      'not.exist'
    );
    cy.findByText(/forgot password?/i)
      .should('be.visible')
      .click();
    cy.findByText(/please enter your email first!/i).should('be.visible');
    cy.get('[name="email"]').type(trainer.email);
    cy.findByText(/forgot password?/i)
      .should('be.visible')
      .click();
    cy.get('[data-test="signIn-forgetPasswordConfimationDialog"]').should(
      'be.visible'
    );
    cy.get('[data-test="signIn-forgetPasswordConfimationDialog-noButton"]')
      .should('be.visible')
      .click();
    cy.get('[data-test="signIn-forgetPasswordConfimationDialog"]').should(
      'not.exist'
    );
    cy.get('[name="email"]')
      .clear()
      .type(trainer.email);
    cy.get('[name="password"]').type(trainer.password);
    cy.findByText(/forgot password?/i)
      .should('be.visible')
      .click();
    cy.get('[data-test="signIn-forgetPasswordConfimationDialog-yesButton"]')
      .should('be.visible')
      .click();
  });

  it('should successfully log in with valid credentials', () => {
    cy.intercept('POST', `${backendUrl}/isUser`, req => {
      req.reply({
        fixture: '../fixtures/Trainer Login Flow/IsUserResponse'
      });
    }).as('isUser');

    cy.intercept('POST', loginRequest, req => {
      req.reply({ fixture: '../fixtures/Trainer Login Flow/Login.json' });
    }).as('loginRequest');
    cy.intercept('POST', login, req => {
      req.reply({
        fixture: '../fixtures/Trainer Login Flow/LoginResponse.json'
      });
    }).as('login');

    //basic assertion
    cy.findByText(/forgot password?/i).should('be.visible');
    cy.findByRole('link', { name: /sign up/i }).should('be.visible');
    cy.findByRole('button', { name: /Login/i }).should('be.disabled');
    cy.findAllByText(/sub-x/i)
      .should('be.visible')
      .should('have.length', 3);
    cy.findByText(/Welcome to Sub-X/i).should('be.visible');
    cy.findAllByText(/login/i)
      .should('be.visible')
      .should('have.length', 2);

    cy.get('[name="email"]').type(trainer.email);
    cy.get('[name="password"]').type(trainer.password);

    cy.get('[type="submit"]')
      .should('be.visible')
      .click();
    cy.wait('@loginRequest').then(({ request }) => {
      expect(request.method).to.equal('POST');
      expect(request.body.email).to.equal(trainer.email);
      expect(request.body.password).to.equal(trainer.password);
    });

    //asertion on dashboard
    cy.findByText(/dashboard/i).should('be.visible');
    cy.findByText(/runners list/i).should('be.visible');
    cy.findByText(/create workout plan/i).should('be.visible');
    cy.findAllByText(/workout plan/i)
      .should('be.visible')
      .should('have.length', 2);
    cy.findByText(/logout/i).should('be.visible');

    const daysOfWeek = [
      'Monday',
      'Tuesday',
      'Wednesday',
      'Thursday',
      'Friday',
      'Saturday',
      'Sunday'
    ];

    cy.findByRole('button', { name: /dashboard/i })
      .should('be.visible')
      .should('have.attr', 'href', '/dashboard')
      .click();

    for (const day of daysOfWeek) {
      cy.findByText(new RegExp(day, 'i')).should('be.visible');
    }

    cy.get('[type="button"]').then($el => {
      cy.get($el[1])
        .should('be.visible')
        .click();
    });
  });

  it('should display an error message with invalid credentials', () => {
    cy.intercept('POST', loginRequest).as('loginRequest');
    //empty email and password behaviour
    cy.wait(200);
    cy.get('[name="email"]').should('have.value', '');
    cy.get('[name="password"]').should('have.value', '');
    cy.get('[type="submit"]').should('be.disabled');

    //basic assertion
    cy.findByText(/forgot password?/i).should('be.visible');
    cy.findByRole('link', { name: /sign up/i }).should('be.visible');
    cy.findByRole('button', { name: /Login/i }).should('be.disabled');
    cy.findAllByText(/sub-x/i)
      .should('be.visible')
      .should('have.length', 3);
    cy.findByText(/Welcome to Sub-X/i).should('be.visible');
    cy.findAllByText(/login/i)
      .should('be.visible')
      .should('have.length', 2);

    cy.get('[name="email"]').type(trainer.email);
    cy.get('[name="password"]').type(trainer.wrongPassword);

    cy.get('[type="submit"]')
      .should('be.visible')
      .click();
    cy.wait('@loginRequest').then(({ request }) => {
      expect(request.method).to.equal('POST');
      expect(request.body.email).to.equal(trainer.email);
      expect(request.body.password).to.equal(trainer.wrongPassword);
    });
    cy.findByTestId('error').should('be.visible');
  });
});
