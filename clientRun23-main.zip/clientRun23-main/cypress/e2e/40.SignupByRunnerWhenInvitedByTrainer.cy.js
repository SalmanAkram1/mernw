import '../support/commands';
import newRunner from './users/NewRunner';
const backendUrl = Cypress.config('backend');
const login = Cypress.config('login');
const signUp = Cypress.config('signUp');
const token = Cypress.config('token');

describe('Signup runner when invited by trainer', () => {
  beforeEach(() => {
    cy.viewport(1920, 1080);
  });
  it('should successfully create account with valid credientials', () => {
    const id = '6561ecd893c3f9e7179512e0';
    cy.intercept('POST', `${backendUrl}/isUser`, req => {
      req.reply({
        fixture:
          '../fixtures/Signup Runner When Invited By Trainer/IsUserResponse.json'
      });
    }).as('isUser');
    cy.intercept('POST', /.*\/register.*/, req => {
      req.reply({ msg: 'ok', value: 'Runner updated succesfully.' });
    }).as('register');
    cy.intercept('POST', login, req => {
      req.reply({
        fixture:
          '../fixtures/Signup Runner When Invited By Trainer/AccountLookup.json'
      });
    }).as('apiResponseLookup');

    cy.intercept('POST', token, req => {
      req.reply({
        fixture: '../fixtures/Signup Runner When Invited By Trainer/Token.json'
      });
    }).as('token');

    cy.intercept('POST', `${backendUrl}/getRunner`, req => {
      req.reply({
        fixture:
          '../fixtures/Signup Runner When Invited By Trainer/GetRunner.json'
      });
    }).as('getRunner');

    cy.intercept('POST', signUp, req => {
      req.reply({
        fixture: '../fixtures/Signup As Trainer/Trainer/Signup.json'
      });
    }).as('signup');
    cy.intercept('POST', /.*\/hasGarminOAuth.*/, req => {
      req.reply(true);
    }).as('hasGarminOAuth');
    cy.visit(`/sign-up/${id}`);
    cy.get('[name="firstName"]').should('have.value', 'Test');
    cy.get('[name="lastName"]').should('have.value', 'Runner2');
    cy.get('[name="runningGroup"]').should('have.attr', 'disabled');
    cy.get('[name="runningGroup"]').should('have.value', 'Testing');

    cy.get('[type="submit"]').should('be.disabled');
    cy.get('[name="email"]').type(newRunner.email);
    cy.get('[name="mobile"]').should('have.value', '+1 234 567 8902');
    cy.get('[name="mobile"]').should('be.disabled');
    cy.get('[name="password"]').type(newRunner.password);

    // button shouldnt be disbled
    cy.get('[type="submit"]').should('not.be.disabled');
    // click submit
    cy.get('[type="submit"]')
      .should('be.visible')
      .click();
    cy.on('window:confirm', () => false);
    // cy.visit('/dashboard');
    cy.url().should('include', 'dashboard');
    cy.wait('@register').then(({ request, response }) => {
      expect(request.body.runnerId).equal(id);
      expect(response.body.msg).equal('ok');
      expect(response.body.value).equal('Runner updated succesfully.');
      expect(request.body.firstName).equal('Test');
      expect(request.body.lastName).equal('Runner2');
      expect(request.body.mobile).equal('+1 234 567 8902');
      expect(request.body.role).equal('runner');
      expect(request.body.runningGroup).equal('Testing');
    });
    cy.logoutUser();
  });
});
