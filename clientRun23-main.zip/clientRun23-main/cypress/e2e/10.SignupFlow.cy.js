import newRunner from './users/newRunner';
import newTrainer from './users/newTrainer';
const backendUrl = Cypress.config('backend');
const login = Cypress.config('login');
const signup = Cypress.config('signUp');

describe('Signup Flow', () => {
  beforeEach(() => {
    cy.viewport(1920, 1080);
    cy.visit('/sign-up');
  });

  it('should successfully create an account with valid credentials as a trainer', () => {
    interceptApiCalls();
    verifySignupPageElements();
    fillSignupForm(newTrainer);
    submitFormAndVerifyDashboard(newTrainer);
    logout();
  });

  it('should show error when user inserts wrong input', () => {
    verifyButtonIsDisabled('[type="submit"]');
    verifySignupPageElements();
    fillSignupFormWithInvalidData(newRunner);
    verifyInvalidPhoneNumberError();
    verifyInvalidEmailError();
    verifyShortPasswordError();
  });
});

function interceptApiCalls() {
  cy.intercept('POST', /.*\/register.*/, {
    fixture: 'Signup As Trainer/Trainer/Register.json'
  }).as('register');
  cy.intercept('POST', `${backendUrl}/isUser`, {
    fixture: 'Signup As Trainer/Trainer/Register.json'
  }).as('isUser');
  cy.intercept('POST', login, {
    fixture: 'Signup As Trainer/Trainer/ApiResponse.json'
  }).as('apiResponseLookup');
  cy.intercept('POST', signup, {
    fixture: 'Signup As Trainer/Trainer/Signup.json'
  }).as('signup');
}

function verifySignupPageElements() {
  cy.findByText(/already have an account/i).should('be.visible');
  cy.findByText(/log in/i).should('be.visible');
  cy.get('.MuiBox-root-19 > .MuiBox-root > :nth-child(1) > .MuiButton-label')
    .should('be.visible')
    .click();
  cy.get(
    '[name="runningGroup"], [name="firstName"], [name="lastName"], [name="mobile"], [name="email"], [name="password"]'
  ).should('be.visible');
}

function fillSignupForm(user) {
  cy.get('[name="runningGroup"]').type(user.runnerGroup);
  cy.get('[name="firstName"]').type(user.fname);
  cy.get('[name="lastName"]').type(user.lname);
  cy.get('[name="mobile"]').type(user.mobile);
  cy.get('[name="email"]').type(user.email);
  cy.get('[name="password"]').type(user.password);
}

function submitFormAndVerifyDashboard(user) {
  cy.get('[type="submit"]')
    .should('not.be.disabled')
    .click();
  cy.url().should('include', 'dashboard');
  verifyRegistration(user);
  verifySignup(user);
  verifyDashboardStaticData(user);
}

function verifyRegistration(user) {
  cy.wait('@register').then(({ request }) => {
    expect(request.method).to.equal('POST');
    expect(request.body.email).to.equal(user.email);
    expect(request.body.firstName).to.equal(user.fname);
    expect(request.body.lastName).to.equal(user.lname);
    expect(request.body.mobile.replace(/\s+/g, '')).to.equal(user.mobile);
    expect(request.body.role).to.equal('trainer');
    expect(request.body.runningGroup).to.equal('Testing');
  });
}

function verifySignup(user) {
  cy.wait('@signup').then(({ request }) => {
    expect(request.method).to.equal('POST');
    expect(request.body.email).to.equal(user.email);
    expect(request.body.password).to.equal(user.password);
  });
}

function verifyDashboardStaticData(user) {
  cy.findByText(/logout/i).should('be.visible');
  const daysOfWeek = [
    'Monday',
    'Tuesday',
    'Wednesday',
    'Thursday',
    'Friday',
    'Saturday',
    'Sunday'
  ];
  daysOfWeek.forEach(day =>
    cy.findByText(new RegExp(day, 'i')).should('be.visible')
  );
  cy.findByText(user.email).should('be.visible');
  cy.findByText(/dashboard/i).should('be.visible');
  cy.findAllByText(/workout plan/i)
    .should('be.visible')
    .should('have.length', 2);
  cy.findByText(/logout/i).should('be.visible');
}

function logout() {
  cy.get('[type="button"]').then($el =>
    cy
      .get($el[1])
      .should('be.visible')
      .click()
  );
}

function fillSignupFormWithInvalidData(user) {
  cy.get('[name="runningGroup"]').type(user.runnerGroup);
  cy.get('[name="firstName"]').type(user.fname);
  cy.get('[name="lastName"]').type(user.lname);
  cy.get('[name="mobile"]').type(
    user.mobile.slice(0, Math.floor(user.mobile.length / 2))
  );
  cy.get('[name="email"]').type(
    user.email.slice(0, Math.floor(user.email.length / 2))
  );
  cy.get('[name="password"]').type(
    user.password.slice(0, Math.floor(user.password.length / 2))
  );
}

function verifyInvalidPhoneNumberError() {
  cy.findByText(/Invalid phone number/i).should('be.visible');
  cy.get('[name="mobile"]').type(
    newRunner.mobile.slice(Math.floor(newRunner.mobile.length / 2))
  );
  cy.findByText(/Invalid phone number/i).should('not.exist');
}

function verifyInvalidEmailError() {
  cy.findByText(/Email is not a valid email/i).should('be.visible');
  cy.get('[name="email"]').type(
    newRunner.email.slice(Math.floor(newRunner.email.length / 2))
  );
  cy.findByText(/Email is not a valid email/i).should('not.exist');
}

function verifyShortPasswordError() {
  cy.contains('Password is too short').should('be.visible');
  cy.get('[name="password"]').type(
    newRunner.password.slice(Math.floor(newRunner.password.length / 2))
  );
  cy.findByText(/Password is too short (minimum is 6 characters)/i).should(
    'not.exist'
  );
}

function verifyButtonIsDisabled(selector) {
  cy.get(selector).should('be.disabled');
}

// import newRunner from './users/newRunner';
// import newTrainer from './users/newTrainer';
// const backendUrl = Cypress.config('backend');
// const login = Cypress.config('login');
// const signup = Cypress.config('signUp');

// describe('Signup Flow', () => {
//   beforeEach(() => {
//     cy.viewport(1920, 1080);
//     cy.visit('/sign-up');
//   });

//   // Signup as a runner was disabled for now. Only trainers can subscribe to the platform.
//   // Runners are invited by their trainers only.
//   // -------------------------------------------
//   // it('should pass data as runner', () => {
//   //   cy.intercept('POST', /.*\/register.*/, req => {
//   //     req.reply({
//   //       fixture: '../fixtures/Signup As Trainer/Runner/Register.json'
//   //     });
//   //   }).as('register');
//   //   cy.intercept('POST', /.*\/hasGarminOAuth.*/, req => {
//   //     req.reply(true);
//   //   }).as('hasGarminOAuth');
//   //   cy.intercept('GET', 'https://connect.garmin.com/signin/*').as(
//   //     'garminSignIn'
//   //   );

//   //   //sent sattus 200
//   //   cy.intercept('POST', `${backendUrl}/isUser`, req => {
//   //     req.reply({
//   //       fixture: '../fixtures/Signup As Trainer/Runner/Register.json'
//   //     });
//   //   }).as('isUser');

//   //   cy.intercept('POST', login, req => {
//   //     req.reply({
//   //       fixture: '../fixtures/Signup As Trainer/Runner/ApiResponse.json'
//   //     });
//   //   }).as('apiResponseLookup');
//   //   cy.intercept('POST', signup, req => {
//   //     req.reply({
//   //       fixture: '../fixtures/Signup As Trainer/Runner/Signup.json'
//   //     });
//   //   }).as('signup');

//   //   cy.findByText(/already have an account/i).should('be.visible');
//   //   cy.findByText(/log in/i).should('be.visible');
//   //   cy.get('.makeStyles-optionButton-16 > .MuiButton-label')
//   //     .eq(1) // Use index 1 (zero-based) to select the second element
//   //     .should('be.visible').click();

//   //   // static assertion
//   //   cy.get('[name="runningGroup"]').should('be.visible');
//   //   cy.get('[name="firstName"]').should('be.visible');
//   //   cy.get('[name="lastName"]').should('be.visible');
//   //   cy.get('[name="mobile"]').should('be.visible');
//   //   cy.get('[name="email"]').should('be.visible');
//   //   cy.get('[name="password"]').should('be.visible');

//   //   cy.get('[name="runningGroup"]').type(newRunner.runnerGroup);
//   //   cy.get('[name="firstName"]').type(newRunner.fname);
//   //   cy.get('[name="lastName"]').type(newRunner.lname);
//   //   cy.get('[name="mobile"]').type(newRunner.mobile);
//   //   cy.get('[name="email"]').type(newRunner.email);
//   //   cy.get('[name="password"]').type(newRunner.password);

//   //   // button shouldnt be disbled
//   //   cy.get('[type="submit"]').should('not.be.disabled');
//   //   // click submit
//   //   cy.get('[type="submit"]').should('be.visible').click();
//   //   // cy.url().should('include', 'dashboard');

//   //   //asserting regitering user register

//   //   cy.wait('@register').then(({ request }) => {
//   //     expect(request.method).to.equal('POST');
//   //     expect(request.method).to.equal('POST');
//   //     expect(request.body.email).to.equal(newRunner.email);
//   //     expect(request.body.firstName).to.equal(newRunner.fname);
//   //     expect(request.body.lastName).to.equal(newRunner.lname);
//   //     expect(request.body.mobile.replace(/\s+/g, '')).to.equal(
//   //       newRunner.mobile
//   //     );
//   //     expect(request.body.role).to.equal('runner');
//   //     expect(request.body.runningGroup).to.equal('Example');
//   //   });
//   //   //asserting that login credientials are passed correctly
//   //   cy.wait('@signup').then(({ request }) => {
//   //     expect(request.method).to.equal('POST');
//   //     expect(request.body.email).to.equal(newRunner.email);
//   //     expect(request.body.password).to.equal(newRunner.password);
//   //   });
//   //   cy.on('window:confirm', () => false);

//   //   cy.findByText(/logout/i).should('be.visible');
//   //   const daysOfWeek = [
//   //     'Monday',
//   //     'Tuesday',
//   //     'Wednesday',
//   //     'Thursday',
//   //     'Friday',
//   //     'Saturday',
//   //     'Sunday'
//   //   ];

//   //   for (const day of daysOfWeek) {
//   //     cy.findByText(new RegExp(day, 'i')).should('be.visible');
//   //   }

//   //   cy.findByText(newRunner.email).should('be.visible');
//   //   cy.findByText(/dashboard/i).should('be.visible');
//   //   cy.findByText(/Garmin sync/i).should('be.visible');
//   //   cy.findAllByText(/workout plan/i)
//   //     .should('be.visible')
//   //     .should('have.length', 1);
//   //   cy.findByText(/logout/i).should('be.visible');
//   //   //logout
//   //   cy.get('[type="button"]').then($el => {
//   //     cy.get($el[1]).should('be.visible').click();
//   //   });
//   // });

//   it('should successfully create account with valid credientials as trainner', () => {
//     cy.intercept('POST', /.*\/register.*/, req => {
//       req.reply({
//         fixture: '../fixtures/Signup As Trainer/Trainer/Register.json'
//       });
//     }).as('register');

//     //sent sattus 200
//     cy.intercept('POST', `${backendUrl}/isUser`, req => {
//       req.reply({
//         fixture: '../fixtures/Signup As Trainer/Trainer/Register.json'
//       });
//     }).as('isUser');

//     cy.intercept('POST', login, req => {
//       req.reply({
//         fixture: '../fixtures/Signup As Trainer/Trainer/ApiResponse.json'
//       });
//     }).as('apiResponseLookup');
//     cy.intercept('POST', signup, req => {
//       req.reply({
//         fixture: '../fixtures/Signup As Trainer/Trainer/Signup.json'
//       });
//     }).as('signup');

//     cy.findByText(/already have an account/i).should('be.visible');
//     cy.findByText(/log in/i).should('be.visible');
//     cy.get('.MuiBox-root-19 > .MuiBox-root > :nth-child(1) > .MuiButton-label')
//       .should('be.visible')
//       .click();

//     // static assertion
//     cy.get('[name="runningGroup"]').should('be.visible');
//     cy.get('[name="firstName"]').should('be.visible');
//     cy.get('[name="lastName"]').should('be.visible');
//     cy.get('[name="mobile"]').should('be.visible');
//     cy.get('[name="email"]').should('be.visible');
//     cy.get('[name="password"]').should('be.visible');

//     cy.get('[name="runningGroup"]').type(newTrainer.runnerGroup);
//     cy.get('[name="firstName"]').type(newTrainer.fname);
//     cy.get('[name="lastName"]').type(newTrainer.lname);
//     cy.get('[name="mobile"]').type(newTrainer.mobile);
//     cy.get('[name="email"]').type(newTrainer.email);
//     cy.get('[name="password"]').type(newTrainer.password);

//     // button shouldnt be disbled
//     cy.get('[type="submit"]').should('not.be.disabled');
//     // click submit
//     cy.get('[type="submit"]')
//       .should('be.visible')
//       .click();
//     cy.url().should('include', 'dashboard');

//     //asserting regitering user register

//     cy.wait('@register').then(({ request }) => {
//       expect(request.method).to.equal('POST');
//       expect(request.method).to.equal('POST');
//       expect(request.body.email).to.equal(newTrainer.email);
//       expect(request.body.firstName).to.equal(newTrainer.fname);
//       expect(request.body.lastName).to.equal(newTrainer.lname);
//       expect(request.body.mobile.replace(/\s+/g, '')).to.equal(
//         newTrainer.mobile
//       );
//       expect(request.body.role).to.equal('trainer');
//       expect(request.body.runningGroup).to.equal('Testing');
//     });
//     //asserting that login credientials are passed correctly
//     cy.wait('@signup').then(({ request }) => {
//       expect(request.method).to.equal('POST');
//       expect(request.body.email).to.equal(newTrainer.email);
//       expect(request.body.password).to.equal(newTrainer.password);
//     });

//     //asserting dashboards static data
//     cy.findByText(/logout/i).should('be.visible');
//     const daysOfWeek = [
//       'Monday',
//       'Tuesday',
//       'Wednesday',
//       'Thursday',
//       'Friday',
//       'Saturday',
//       'Sunday'
//     ];

//     for (const day of daysOfWeek) {
//       cy.findByText(new RegExp(day, 'i')).should('be.visible');
//     }

//     cy.findByText(newTrainer.email).should('be.visible');
//     cy.findByText(/dashboard/i).should('be.visible');
//     cy.findAllByText(/workout plan/i)
//       .should('be.visible')
//       .should('have.length', 2);
//     cy.findByText(/logout/i).should('be.visible');
//     //logout
//     cy.get('[type="button"]').then($el => {
//       cy.get($el[1])
//         .should('be.visible')
//         .click();
//     });
//   });

//   it('should show error when user insert wrong input', () => {
//     //assert submit button it should be disabled
//     cy.get('[type="submit"]').should('be.disabled');

//     cy.findByText(/already have an account/i).should('be.visible');
//     cy.findByText(/log in/i).should('be.visible');
//     cy.get('.MuiBox-root-19 > .MuiBox-root > :nth-child(1) > .MuiButton-label')
//       .should('be.visible')
//       .click();

//     // static assertion
//     cy.get('[name="runningGroup"]').should('be.visible');
//     cy.get('[name="firstName"]').should('be.visible');
//     cy.get('[name="lastName"]').should('be.visible');
//     cy.get('[name="mobile"]').should('be.visible');
//     cy.get('[name="email"]').should('be.visible');
//     cy.get('[name="password"]').should('be.visible');

//     cy.get('[name="runningGroup"]').type(newRunner.runnerGroup);
//     cy.get('[name="firstName"]').type(newRunner.fname);
//     cy.get('[name="lastName"]').type(newRunner.lname);

//     newRunner.mobile.slice(0, Math.floor(newRunner.mobile.length / 2));
//     newRunner.mobile.slice(Math.floor(newRunner.mobile.length / 2));
//     //asserting wrong phone number

//     cy.get('[name="mobile"]').type(
//       newRunner.mobile.slice(0, Math.floor(newRunner.mobile.length / 2))
//     );
//     cy.findByText(/Invalid phone number/i).should('be.visible');
//     cy.get('[name="mobile"]').type(
//       newRunner.mobile.slice(Math.floor(newRunner.mobile.length / 2))
//     );
//     cy.findByText(/Invalid phone number/i).should('not.exist');

//     //asserting wrong email
//     cy.get('[name="email"]').type(
//       newRunner.email.slice(0, Math.floor(newRunner.email.length / 2))
//     );
//     cy.findByText(/Email is not a valid email/i).should('be.visible');
//     cy.get('[name="email"]').type(
//       newRunner.email.slice(Math.floor(newRunner.email.length / 2))
//     );
//     cy.findByText(/Email is not a valid email/i).should('not.exist');

//     // asserting wrong password
//     cy.get('[name="password"]').type(
//       newRunner.password.slice(0, Math.floor(newRunner.password.length / 2))
//     );
//     cy.contains('Password is too short').should('be.visible');

//     cy.get('[name="password"]').type(
//       newRunner.password.slice(Math.floor(newRunner.password.length / 2))
//     );
//     cy.findByText(/Password is too short (minimum is 6 characters)/i).should(
//       'not.exist'
//     );

//     cy.get('[name="password"]').type(newRunner.password);
//   });
// });
