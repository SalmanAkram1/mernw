import trainer from './users/TrainerUser';
const backendUrl = Cypress.config('backend');
import '../support/commands';

const daysOfWeek = [
  'Monday',
  'Tuesday',
  'Wednesday',
  'Thursday',
  'Friday',
  'Saturday',
  'Sunday'
];
describe('Trainer Dashboard', () => {
  beforeEach(() => {
    cy.viewport(1920, 1080);
    cy.loginAsTrainner(trainer.email, trainer.password);
  });

  afterEach(() => {
    cy.logoutUser();
  });

  it('Should render Dashboard with no errors', () => {
    const daysOfWeek = [
      'Monday',
      'Tuesday',
      'Wednesday',
      'Thursday',
      'Friday',
      'Saturday',
      'Sunday'
    ];

    cy.findByRole('button', { name: /dashboard/i })
      .should('be.visible')
      .should('have.attr', 'href', '/dashboard')
      .click();

    for (const day of daysOfWeek) {
      cy.findByText(new RegExp(day, 'i')).should('be.visible');
    }
    cy.findByText(trainer.email).should('be.visible');

    cy.findByRole('button', { name: /Runners list/i })
      .should('be.visible')
      .should('have.attr', 'href', '/runnersList');

    cy.findByRole('button', { name: /create workout plan/i })
      .should('be.visible')
      .should('have.attr', 'href', '/createWorkoutPlan');

    cy.findAllByRole('button', { name: /workout plan/i }).then($el => {
      cy.get($el[1])
        .should('have.attr', 'href', '/workoutPlan')
        .should('be.visible');
    });

    cy.findByRole('button', { name: /logout/i })
      .should('be.visible')
      .should('have.attr', 'href', '/sign-in');

    cy.url().should('include', '/dashboard');
    //   TODO: assert search field and choose Day/week and dayView
  });

  it('should render runnerlist page', () => {
    cy.findByText(/runners list/i).should('be.visible');
    cy.findByText(/Runners list/i).click({
      force: true,
      scrollBehavior: false
    });
    cy.findByRole('button', { name: '+ Add Runner' }).should('be.visible');
    cy.findByText(/Name/i).should('be.visible');
    cy.findByText(/sub group/i).should('be.visible');
    cy.findByText(/Base pace/i).should('be.visible');
    cy.findByText(/runs per week/i).should('be.visible');
    cy.findByText(/mobile/i).should('be.visible');
    cy.findAllByText(/runners list/i).should('have.length', 2);
  });

  it('should render createWorkoutPlan page', () => {
    cy.intercept('POST', `${backendUrl}/workout/templatesFromDB`, req => {
      req.reply({
        severity: 'info',
        msg: 'The workout template was retrieved successfully',
        workoutTemplates: []
      });
    }).as('loginRequest');

    // for (const day of daysOfWeek) {
    //   cy.findByText(new RegExp(day, 'i')).should('be.visible');
    // }

    cy.findByText(/create workout plan/i).should('be.visible');
    cy.findByText(/create workout plan/i).click({
      force: true,
      scrollBehavior: false
    });

    cy.findByText(/Create a workout/i).should('be.visible');
    cy.findByRole('button', { name: /add warm up/i }).should('be.visible');
    cy.findByRole('button', { name: /add repeat/i }).should('be.visible');
    cy.findByRole('button', { name: /add step/i }).should('be.visible');
    cy.findByRole('button', { name: /add cool down/i }).should('be.visible');
  });
});
