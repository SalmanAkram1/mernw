import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Grid from '@material-ui/core/Grid';
import Button from '@material-ui/core/Button';

const useStyles = makeStyles((theme) => ({
  root: { marginTop: 15 },
  customButton: {
    backgroundColor: '#969696',
    color: '#000000',
    fontWeight: 500,
    // marginLeft: 18,
    boxShadow: 'none',
    textTransform: 'none',
    marginTop: 7,
    paddingLeft: 30,
    paddingRight: 30,
  },
  customButtonBorder: {
    border: '1px solid #969696',
    color: '#000000',
    fontWeight: 500,
    boxShadow: 'none',
    textTransform: 'none',
    marginTop: 7,
    paddingLeft: 30,
    paddingRight: 30,
  },
}));

export default function MobileButtonsGroup(props) {
  const classes = useStyles();

  return (
    <div className={classes.root}>
      <Grid justifyContent="center" container>
        <Grid item>
          <Button
            variant="contained"
            size="small"
            className={classes.customButtonBorder}
            onClick={props.handleCancel}
          >
            Cancel
          </Button>
          <Button
            variant="contained"
            size="small"
            style={{ marginLeft: 5, marginRight: 5 }}
            className={classes.customButton}
            onClick={props.handleSave}
          >
            Save
          </Button>
          <Button
            variant="contained"
            size="small"
            className={classes.customButton}
            onClick={props.handleDelete}
          >
            Delete
          </Button>
        </Grid>
      </Grid>
    </div>
  );
}
