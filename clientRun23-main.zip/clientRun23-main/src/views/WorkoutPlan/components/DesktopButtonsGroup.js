import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';

const useStyles = makeStyles((theme) => ({
  customButton: {
    backgroundColor: '#969696',
    color: '#000000',
    fontWeight: 500,
    // marginLeft: 18,
    boxShadow: 'none',
    textTransform: 'none',
    marginTop: 7,
    paddingLeft: 30,
    paddingRight: 30,
  },
  customButtonBorder: {
    border: '1px solid #969696',
    color: '#000000',
    fontWeight: 500,
    boxShadow: 'none',
    textTransform: 'none',
    marginTop: 7,
    paddingLeft: 30,
    paddingRight: 30,
  },
}));

export default function DesktopButtonsGroup(props) {
  const classes = useStyles();

  return (
    <>
      <Button
        variant="contained"
        size="small"
        className={classes.customButton}
        onClick={props.handleOpen}
      >
        Delete
      </Button>
      <Button
        variant="contained"
        size="small"
        style={{ marginLeft: 5, marginRight: 5 }}
        className={classes.customButton}
      >
        Edit
      </Button>
      <Button variant="contained" size="small" className={classes.customButton}>
        Save
      </Button>
    </>
  );
}
