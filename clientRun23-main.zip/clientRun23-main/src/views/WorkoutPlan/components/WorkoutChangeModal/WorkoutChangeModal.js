import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Modal from '@material-ui/core/Modal';
import { Card } from '@material-ui/core';
import WorkoutChangeLayout from './WorkoutChangeLayout';

function rand() {
  return Math.round(Math.random() * 20) - 10;
}

function getModalStyle() {
  const top = 50 + rand();
  const left = 50 + rand();

  return {
    top: `${top}%`,
    left: `${left}%`,
    transform: `translate(-${top}%, -${left}%)`
  };
}

const useStyles = makeStyles(theme => ({
  paper: {
    position: 'absolute',
    width: 400,
    backgroundColor: theme.palette.background.paper,
    border: '2px solid #000',
    boxShadow: theme.shadows[5],
    padding: theme.spacing(2, 4, 3)
  },
  scrollableModal: {
    overflow: 'scroll'
  }
}));

export default function WorkoutChangeModal(props) {
  const {
    open,
    workout,
    isModalOpen,
    handleModalClose,
    type,
    setWorkoutName,
    setWorkoutSteps,
    setWorkout,
    user,
    updateWorkouts
    // setActiveDate
  } = props;

  const classes = useStyles();
  // getModalStyle is not a pure function, we roll the style only on the first render
  const [modalStyle] = React.useState(getModalStyle);

  return (
    <Modal
      className={classes.scrollableModal}
      open={open}
      onClose={handleModalClose}
      aria-labelledby="simple-modal-title"
      aria-describedby="simple-modal-description"
      style={{
        // display: 'flex',
        // justifyContent: 'center',
        // alignItems: 'center',
        marginLeft: '7.5%',
        marginRight: '7.5%'
      }}>
      <Card>
        <WorkoutChangeLayout
          workout={workout}
          handleModalClose={handleModalClose}
          type={type}
          setWorkoutName={setWorkoutName}
          setWorkoutSteps={setWorkoutSteps}
          setWorkout={setWorkout}
          user={user}
          updateWorkouts={updateWorkouts}
          // setActiveDate={setActiveDate}
        />
      </Card>
    </Modal>
  );
}
