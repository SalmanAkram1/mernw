import React, { useEffect, useState } from 'react';
import { makeStyles } from '@material-ui/core/styles';
// import { useTheme } from '@material-ui/core/styles';
import Typography from '@material-ui/core/Typography';
import Grid from '@material-ui/core/Grid';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
import InputLabel from '@material-ui/core/InputLabel';
import MenuItem from '@material-ui/core/MenuItem';
import Divider from '@material-ui/core/Divider';
import { TextField } from '@material-ui/core';

const useStyles = makeStyles(theme => ({
  select: {
    '& span': {
      fontWeight: '600'
    }
  },
  formControl: {
    width: '100%',
    marginTop: '7px'
  },
  unitsBGColor: {
    // backgroundColor: '#A4A4A4',
    borderRadius: '0px 4px 4px 0px'
  },
  priamryTextColor: {
    color: theme.palette.primary.main
  },
  secondaryTextColor: {
    color: theme.palette.secondary.main
  }
}));

const convertSecondsToPace = totalSeconds => {
  if (isNaN(totalSeconds)) return totalSeconds;
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  const paddedSeconds = seconds < 10 ? '0' + seconds : seconds;
  return `${minutes}:${paddedSeconds}`;
};

const convertPaceToSeconds = (minutes, seconds) => minutes * 60 + seconds;

function WorkoutInputFields(props) {
  const { step, trigger } = props;
  const classes = useStyles();
  const [durationType, setDurationType] = useState(step?.durationType || '');
  const [units, setUnits] = useState('');
  const [duration, setDuration] = useState('');
  const [pace, setPace] = useState('');
  const [runnerPace, setRunnerPace] = useState(
    convertSecondsToPace(step.runnerPace)
  );

  useEffect(() => {
    if (
      !step.durationType &&
      !step.durationValue &&
      !step.durationValueType &&
      !step.targetValue
    ) {
      setDurationType('');
      setUnits('');
      setDuration('');
      setPace('');
    }
  }, [trigger]);

  const handleDurationTypeChange = event => {
    step.durationType = event.target.value;
    if (step.durationType == 'TIME') {
      setUnits('MINUTE');
      step.durationValueType = 'MINUTE';
    }
    if (step.durationType == 'DISTANCE') setUnits(step.durationValueType || '');

    if (step.durationType == 'OPEN') {
      setUnits('');
      setDuration('');
    }
    step.durationValue = '';
    setDuration('');
    setDurationType(event.target.value);
  };

  const handleDurationChange = event => {
    const durationValue = event.target.value;
    step.durationValue = durationValue;
    setDuration(durationValue);
  };

  const handleRunnerPaceChange = event => {
    const runnerPaceValue = event.target.value;
    setRunnerPace(runnerPaceValue);
    const [mins, secs] = runnerPaceValue.split(':');
    const runnerPaceInSeconds = convertPaceToSeconds(
      parseInt(mins),
      parseInt(secs)
    );
    if (runnerPaceInSeconds) step.runnerPace = runnerPaceInSeconds;
  };

  const handleUnitsChange = event => {
    step.durationValueType = event.target.value;
    setUnits(event.target.value);
  };

  const handlePaceChange = event => {
    step.targetType = 'PACE';
    step.targetValue = event.target.value;
    setPace(event.target.value);
  };

  if (step.targetValue == 0) step.targetValue = '0';

  return (
    <Grid container spacing={2}>
      <Grid item xs={12} sm={4}>
        <div className={classes.select}>
          <Typography variant="h6">Duration Type</Typography>
          <FormControl variant="outlined" className={classes.formControl}>
            <InputLabel
              id="workoutInputFields-selectDurationType-inputLabel"
              margin="dense">
              Select Duration Type
            </InputLabel>
            <Select
              labelId="demo-simple-select-outlined-label"
              id="workoutInputFields-selectDurationType-select"
              data-test="workoutInputFields-selectDurationType-select"
              margin="dense"
              label="Select Duration Type"
              value={durationType}
              onChange={handleDurationTypeChange}>
              <MenuItem
                data-test={'workoutInputFields-durationType-distance'}
                value={'DISTANCE'}>
                Distance
              </MenuItem>
              <MenuItem
                data-test={'workoutInputFields-durationType-time'}
                value={'TIME'}>
                Time
              </MenuItem>
              <MenuItem
                data-test={'workoutInputFields-durationType-open'}
                value={'OPEN'}>
                Until Lap Press
              </MenuItem>
            </Select>
          </FormControl>
        </div>
      </Grid>
      <Grid item xs={12} sm={4}>
        <div className={classes.select}>
          <Typography variant="h6">Duration</Typography>
          <Grid container spacing={0}>
            <Grid item xs={8} sm={8}>
              <TextField
                data-test={'workoutInputFields-setDuration'}
                disabled={
                  durationType == 'OPEN' ||
                  step.durationType == 'OPEN' ||
                  (!units && !step.durationValue)
                }
                fullWidth
                variant="outlined"
                margin="dense"
                value={step.durationValue || duration}
                onChange={handleDurationChange}
                style={{ marginTop: '7px' }}
                color="primary"
                label={'Set Duration'}
              />
            </Grid>
            <Grid item xs={4} sm={4}>
              <FormControl
                variant="outlined"
                className={`${classes.formControl} ${classes.unitsBGColor}`}>
                <InputLabel
                  disabled={
                    !durationType ||
                    durationType == 'OPEN' ||
                    step.durationType == 'OPEN'
                  }
                  id="demo-simple-select-outlined-label"
                  margin="dense">
                  Units
                </InputLabel>
                <Select
                  data-test={'workoutInputFields-selectUnits-select'}
                  disabled={
                    !durationType ||
                    durationType == 'OPEN' ||
                    step.durationType == 'OPEN'
                  }
                  labelId="workoutInputFields-selectUnits-select"
                  id="workoutInputFields-selectUnits-select"
                  margin="dense"
                  label="Units"
                  value={step.durationValueType || units}
                  onChange={handleUnitsChange}>
                  {durationType === 'DISTANCE' && [
                    <MenuItem
                      data-test={'workoutInputFields-units-meter'}
                      className={classes.secondaryTextColor}
                      value={'METER'}>
                      meters
                    </MenuItem>,
                    <MenuItem
                      data-test={'workoutInputFields-units-kilometer'}
                      className={classes.secondaryTextColor}
                      value={'KILOMETER'}>
                      km
                    </MenuItem>
                  ]}
                  {durationType === 'TIME' && (
                    <MenuItem
                      data-test={'workoutInputFields-units-minute'}
                      className={classes.secondaryTextColor}
                      value={'MINUTE'}>
                      minutes
                    </MenuItem>
                  )}
                </Select>
              </FormControl>
            </Grid>
          </Grid>
        </div>
      </Grid>
      <Grid item xs={12} sm={4}>
        {!step.runnerPace ? (
          <div className={classes.select}>
            <Typography variant="h6">Pace</Typography>
            <FormControl variant="outlined" className={classes.formControl}>
              <InputLabel
                id="workoutInputFields-setPace-inputLabel"
                margin="dense">
                Set Pace
              </InputLabel>
              <Select
                data-test={'workoutInputFields-setPace-select'}
                labelId="workoutInputFields-setPace-select"
                id="workoutInputFields-setPace-select"
                margin="dense"
                label="Set Pace"
                value={step.targetValue || pace}
                onChange={handlePaceChange}>
                <MenuItem
                  data-test={'workoutInputFields-setPace-menuItem-easy'}
                  className={classes.secondaryTextColor}
                  value={'EASY'}>
                  Easy
                </MenuItem>
                <MenuItem
                  data-test={'workoutInputFields-setPace-menuItem-rest'}
                  className={classes.secondaryTextColor}
                  value={'REST'}>
                  Rest
                </MenuItem>
                <Divider />
                <MenuItem className={classes.secondaryTextColor} value={60}>
                  +60s
                </MenuItem>
                <MenuItem className={classes.secondaryTextColor} value={55}>
                  +55s
                </MenuItem>
                <MenuItem className={classes.secondaryTextColor} value={50}>
                  +50s
                </MenuItem>
                <MenuItem className={classes.secondaryTextColor} value={45}>
                  +45s
                </MenuItem>
                <MenuItem className={classes.secondaryTextColor} value={40}>
                  +40s
                </MenuItem>
                <MenuItem className={classes.secondaryTextColor} value={35}>
                  +35s
                </MenuItem>
                <MenuItem className={classes.secondaryTextColor} value={30}>
                  +30s
                </MenuItem>
                <MenuItem className={classes.secondaryTextColor} value={25}>
                  +25s
                </MenuItem>
                <MenuItem className={classes.secondaryTextColor} value={20}>
                  +20s
                </MenuItem>
                <MenuItem className={classes.secondaryTextColor} value={15}>
                  +15s
                </MenuItem>
                <MenuItem
                  data-test={'workoutInputFields-setPace-menuItem-+10s'}
                  className={classes.secondaryTextColor}
                  value={10}>
                  +10s
                </MenuItem>
                <MenuItem
                  data-test={'workoutInputFields-setPace-menuItem-+5s'}
                  className={classes.secondaryTextColor}
                  value={5}>
                  +5s
                </MenuItem>
                <MenuItem
                  data-test={'workoutInputFields-setPace-menuItem-basePace'}
                  className={classes.secondaryTextColor}
                  value={0}>
                  0 (Base Pace)
                </MenuItem>
                <MenuItem
                  data-test={'workoutInputFields-setPace-menuItem--5s'}
                  className={classes.secondaryTextColor}
                  value={-5}>
                  -5s
                </MenuItem>
                <MenuItem
                  data-test={'workoutInputFields-setPace-menuItem--10s'}
                  className={classes.secondaryTextColor}
                  value={-10}>
                  -10s
                </MenuItem>
                <MenuItem className={classes.secondaryTextColor} value={-15}>
                  -15s
                </MenuItem>
                <MenuItem className={classes.secondaryTextColor} value={-20}>
                  -20s
                </MenuItem>
                <MenuItem className={classes.secondaryTextColor} value={-25}>
                  -25s
                </MenuItem>
                <MenuItem className={classes.secondaryTextColor} value={-30}>
                  -30s
                </MenuItem>
                <MenuItem className={classes.secondaryTextColor} value={-35}>
                  -35s
                </MenuItem>
                <MenuItem className={classes.secondaryTextColor} value={-40}>
                  -40s
                </MenuItem>
                <MenuItem className={classes.secondaryTextColor} value={-45}>
                  -45s
                </MenuItem>
                <MenuItem className={classes.secondaryTextColor} value={-50}>
                  -50s
                </MenuItem>
                <MenuItem className={classes.secondaryTextColor} value={-55}>
                  -55s
                </MenuItem>
                <MenuItem className={classes.secondaryTextColor} value={-60}>
                  -60s
                </MenuItem>
              </Select>
            </FormControl>
          </div>
        ) : (
          <>
            <Typography className={classes.priamryTextColor} variant="h6">
              Pace
            </Typography>
            <TextField
              fullWidth
              className={classes.priamryTextColor}
              data-test={'workoutInputFields-runnerPaceTextField'}
              variant="outlined"
              margin="dense"
              value={convertSecondsToPace(runnerPace)}
              onChange={handleRunnerPaceChange}
              style={{ marginTop: '7px' }}
              label={'Runner Pace'}
            />
          </>
        )}
      </Grid>
    </Grid>
  );
}

export default WorkoutInputFields;
