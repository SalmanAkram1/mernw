import { Grid } from '@material-ui/core';
import Button from '@material-ui/core/Button';
import TextField from '@material-ui/core/TextField';
import TextareaAutosize from '@material-ui/core/TextareaAutosize';
import Typography from '@material-ui/core/Typography';
import { makeStyles } from '@material-ui/core/styles';
import AddOutlinedIcon from '@material-ui/icons/AddOutlined';
import RepeatIcon from '@material-ui/icons/Repeat';
import TrendingDownOutlinedIcon from '@material-ui/icons/TrendingDownOutlined';
import TrendingUpOutlinedIcon from '@material-ui/icons/TrendingUpOutlined';
import axios from 'axios';
import React, { useEffect, useState } from 'react';

import RepeatStep from './RepeatStep';
import WeekCalendar from './WeekCalendar';
import WorkoutStepTemplate from './WorkoutStepTemplate';
import WorkoutTemplateSelection from './WorkoutTemplateSelection';

import getCooldownStepTemplate from './Templates/cooldownStepTemplate';
import getWarmupStepTemplate from './Templates/warmupStepTemplate';
import getNewRepeatStep from './Templates/workoutRepeatStepTemplate';
import getNewWorkoutStep from './Templates/workoutStepTemplate';
import getWorkoutTemplate from './Templates/workoutTemplate';
import WeeklyPlanPreviewModal from './WeeklyPlanPreviewModal/WeeklyPlanPreviewModal';

import { SnackbarNotification } from 'components';
import LoadingScreen from 'components/LoadingScreen/LoadingScreen';
import SubGroup from './SubGroup/SubGroup';
import workoutTemplate from './Templates/workoutTemplate';

const useStyles = makeStyles(theme => ({
  toolbar: theme.mixins.toolbar,
  content: {
    textAlign: 'start',
    flexGrow: 1,
    padding: theme.spacing(2),
    display: 'flex',
    flexDirection: 'column',

    [theme.breakpoints.up('sm')]: {
      paddingLeft: theme.spacing(10),
      paddingRight: theme.spacing(10)
    }
  },
  subTitle: {
    fontWeight: 'bold',
    marginTop: theme.spacing(4),
    marginBottom: theme.spacing(3),
    color: theme.palette.primary.main
  },
  button: {
    width: '100%',
    marginTop: theme.spacing(2),
    backgroundColor: theme.palette.primary.main,
    // backgroundColor: '#A4A4A4',
    color: theme.palette.white,
    boxShadow: 'none',
    textTransform: 'none',

    [theme.breakpoints.up('sm')]: {
      width: 'fit-content',
      minWidth: '18.91rem'
    },

    '&:hover': {
      // backgroundColor: '#a4a4a4a3'
      backgroundColor: theme.palette.secondary.main
    }
  },
  fit_button: {
    flex: '1',

    [theme.breakpoints.up('sm')]: {
      width: 'fit-content',
      minWidth: 'unset'
    }
  },
  btn_margin: {
    marginRight: theme.spacing(2)
  },
  btn_padding: {
    padding: '0 2rem',
    [theme.breakpoints.up('sm')]: {
      padding: '0'
    }
  },
  iconButton: {
    marginRight: '8px',
    [theme.breakpoints.down('sm')]: {
      display: 'none'
    }
  },
  textField: {
    width: '100%',
    maxWidth: 'unset',
    marginTop: theme.spacing(2)

    // [theme.breakpoints.up('sm')]: {
    //   maxWidth: '18.91rem',
    // },
  },
  buttons: {
    display: 'flex',

    [theme.breakpoints.up('sm')]: {
      display: 'inline-table'
    }
  },
  cancel_save_buttons: {
    display: 'flex',

    [theme.breakpoints.up('sm')]: {
      maxWidth: '18.9rem'
    }
  },
  box_title: {
    fontSize: '1.1rem',
    fontWeight: 'bold',
    marginBottom: '1rem',
    color: theme.palette.primary.main
  },
  textArea: {
    borderRadius: '4px',
    width: '100%',
    backgroundColor: 'transparent',
    color: 'rgba(0, 0, 0, 0.87)',
    cursor: 'text',
    display: 'inline-flex',
    position: 'relative',
    fontSize: '1rem',
    boxSizing: 'border-box',
    alignItems: 'center',
    fontFamily: 'inherit',
    fontWeight: '400',
    lineHeight: '1.1876em',
    letterSpacing: '0.00938em',
    padding: '10.5px 14px'
  },
  mTop3: {
    marginTop: theme.spacing(3)
  },
  btn_remove: {
    backgroundColor: '#ffffff',
    color: 'black',
    border: '1px solid #000000',
    '&:hover': {
      backgroundColor: theme.palette.secondary.main,
      color: 'white',
      borderColor: 'white'
    }
  },
  priamryTextColor: {
    color: theme.palette.primary.main
  },
  secondaryTextColor: {
    color: theme.palette.secondary.main
  }
}));

const getThisWeekStartDate = () => {
  const today = new Date();
  const dayOfWeek = today.getUTCDay();
  const startDateOfWeek = new Date(
    today.getTime() - dayOfWeek * 24 * 60 * 60 * 1000
  );
  return startDateOfWeek;
};

const getNextWeeksSundayDate = () => {
  const today = new Date();
  const dayOfWeek = today.getUTCDay();
  const startDateOfWeek = new Date(
    today.getTime() + (7 - dayOfWeek) * 24 * 60 * 60 * 1000
  );
  return startDateOfWeek;
};

const isSameDate = (date1, date2) => {
  const startOfDate1 = new Date(date1).setHours(0, 0, 0, 0);
  const endOfDate1 = new Date(date1).setHours(23, 59, 59, 999);
  const dateTwo = new Date(date2).getTime();
  return dateTwo >= startOfDate1 && dateTwo <= endOfDate1;
};

const getWorkoutTemplateOfDate = (weeklyWorkoutTemplatesPlan, dateObject) => {
  if (weeklyWorkoutTemplatesPlan.length == 0) return null;
  const workoutTemplate = weeklyWorkoutTemplatesPlan.filter(workout =>
    isSameDate(workout.dateObject, dateObject)
  );
  if (workoutTemplate.length == 0) return null;

  // const workoutTemplates = workoutTemplate.map(workoutTemplate => {
  //   return workoutTemplate.workoutTemplate;
  // });

  // const workoutTemplatesWithoutSameSubGroup = [];

  // workoutTemplates.forEach(filteredWorkout => {
  //   const found = workoutTemplatesWithoutSameSubGroup.find(template => {
  //     return template.subGroup === filteredWorkout.subGroup;
  //   });

  //   if (!found) workoutTemplatesWithoutSameSubGroup.push(filteredWorkout);
  // });

  return workoutTemplate[0].workoutTemplate; // workoutTemplatesWithoutSameSubGroup;
};

const formatWeeklyWorkoutTempplatesPlan = (
  startWeekDate,
  weeklyWorkoutTemplatesPlan,
  subGroup
) => {
  let weeklyWorkoutTemplates = [];

  for (let i = 0; i < 7; i++) {
    let date = new Date(startWeekDate.getTime() + i * 24 * 60 * 60 * 1000);
    // let dayOfWeek = date.toLocaleString('default', { weekday: 'long' });
    let day = date.getDate();
    let month = date.getMonth() + 1; // Month is 0-based
    let dayNumber = date.getDay();
    let days = [
      'Sunday',
      'Monday',
      'Tuesday',
      'Wednesday',
      'Thursday',
      'Friday',
      'Saturday'
    ];
    let actualDayOfWeek = days[dayNumber];
    let workoutTemplate = getWorkoutTemplateOfDate(
      weeklyWorkoutTemplatesPlan,
      date
    );
    let formattedDate = {
      dateObject: date,
      dayOfWeek: `${actualDayOfWeek}`,
      date: `${day}/${month}`,
      workoutTemplate,
      isActive: false,
      isWorkout: workoutTemplate ? true : false,
      subGroup
    };

    weeklyWorkoutTemplates[i] = formattedDate;
  }
  // set the first day of the week as active by default
  // it changes once the user clicks on a different date
  weeklyWorkoutTemplates[0].isActive = true;

  return weeklyWorkoutTemplates;
};

const getPreviousWeekStartDate = date => {
  return new Date(date.getTime() - 7 * 24 * 60 * 60 * 1000);
};

const getNextWeekStartDate = date => {
  return new Date(date.getTime() + 7 * 24 * 60 * 60 * 1000);
};

const getWeeklyWorkoutsPlanByStartDate = async (
  userEmail,
  startWeekDate,
  selectedSubgroup
) => {
  const weeklyWorkoutsPlanTemplateRaw = await axios.post(
    `${process.env.REACT_APP_SERVER_URL}/workout/workoutsPlan`,
    {
      userEmail,
      startWeekDate
    }
  );
  const workoutsPlanTemplatesOfTheWeek = weeklyWorkoutsPlanTemplateRaw.data.workoutPlanTemplates.filter(
    item => item.subGroup === selectedSubgroup
  );

  const weeklyWorkoutTemplatesPlan = formatWeeklyWorkoutTempplatesPlan(
    startWeekDate,
    workoutsPlanTemplatesOfTheWeek,
    selectedSubgroup
  );

  return weeklyWorkoutTemplatesPlan;
};

const getPlannedWorkoutTemplateByUser = async userEmail => {
  const PlannedWorkoutTemplateRaw = await axios.post(
    `${process.env.REACT_APP_SERVER_URL}/workout/getWorkoutTemplate`,
    { userEmail }
  );

  const PlannedWorkoutTemplateData =
    PlannedWorkoutTemplateRaw.data.workoutPlanTemplates;

  return PlannedWorkoutTemplateData;
};

function CreateWorkout(props) {
  const { user } = props;
  const classes = useStyles();

  const [loading, setLoading] = useState(false);
  const [workoutName, setWorkoutName] = useState('');
  const [steps, setSteps] = useState([
    getWarmupStepTemplate(),
    getNewWorkoutStep('INTERVAL'),
    getNewRepeatStep(),
    getCooldownStepTemplate()
  ]);
  const [workoutNotes, setWorkoutNotes] = useState('');

  // const [startWeekDate, setStartWeekDate] = useState(getThisWeekStartDate());
  const [startWeekDate, setStartWeekDate] = useState(getNextWeeksSundayDate());
  const [weeklyWorkoutsPlan, setWeeklyWorkoutsPlan] = useState([]);
  const [weeklyWorkoutsPlanTemplate, setWeeklyWorkoutsPlanTemplate] = useState(
    []
  );
  const [workoutsPlanTemplate, setWorkoutsPlanTemplate] = useState([]);
  const [activeDateObject, setActiveDateObject] = useState(startWeekDate);

  // This trigger is a helper variable for calling a function from child components
  const [trigger, setTrigger] = useState(false);

  const [isNotification, setIsNotification] = React.useState(false);
  const [notificationSeverity, setNotificationSeverity] = React.useState(
    'info'
  );
  const [notificationMessage, setNotificationMessage] = React.useState('');

  // Handling Subgroups
  const [selectedSubgroup, setSelectedSubgroup] = useState('General');
  const [subgroups, setSubgroups] = useState(['General']);
  const [anchorEl, setAnchorEl] = useState(null);
  const [newSubgroupName, setNewSubgroupName] = useState('');
  const [subgroupModalOpen, setSubgroupModalOpen] = useState(false);
  const [deleteConfirmationOpen, setDeleteConfirmationOpen] = useState(false);
  const [subgroupToDelete, setSubgroupToDelete] = useState('');

  useEffect(() => {
    clearAllInputFields();
    getWeeklyWorkoutsPlanByStartDate(
      user.email,
      startWeekDate,
      selectedSubgroup
    )
      .then(weeklyWorkoutTemplates => {
        // setWeeklyWorkoutsPlanTemplate(weeklyWorkoutTemplates);
        setWeeklyWorkoutsPlan(weeklyWorkoutTemplates);
        return weeklyWorkoutTemplates;
      })
      .then(weeklyWorkoutTemplates => {
        if (weeklyWorkoutTemplates[0].workoutTemplate)
          displayWorkoutTemplate(weeklyWorkoutTemplates[0].workoutTemplate);
      });

    getPlannedWorkoutTemplateByUser(user.email).then(workoutTemplatesOfUser => {
      setWorkoutsPlanTemplate(workoutTemplatesOfUser);
      return workoutTemplatesOfUser;
    });
  }, [startWeekDate, selectedSubgroup]);

  const addWarmUp = () => setSteps([getWarmupStepTemplate(), ...steps]);

  const addWorkoutStep = () =>
    setSteps([...steps, getNewWorkoutStep('INTERVAL')]);

  const addRepeatStep = () => setSteps([...steps, getNewRepeatStep()]);

  const addCoolDown = () => setSteps([...steps, getCooldownStepTemplate()]);

  const handleWorkoutNameChange = event => setWorkoutName(event.target.value);
  const handleWorkoutNotesChange = event => setWorkoutNotes(event.target.value);

  const removeStep = step => {
    const revisedSteps = steps.filter(currentStep => currentStep != step);
    setSteps(revisedSteps);
  };

  const prepareWorkoutTemplate = () => {
    const workoutTemplate = getWorkoutTemplate();
    workoutTemplate.userEmail = user.email;
    workoutTemplate.workoutName = workoutName;
    workoutTemplate.steps = steps;
    workoutTemplate.workoutNotes = workoutNotes;
    workoutTemplate.subGroup = selectedSubgroup;
    return workoutTemplate;
  };

  const handleSaveWorkoutTemplate = async () => {
    const workoutTemplate = prepareWorkoutTemplate();
    const response = await axios.post(
      `${process.env.REACT_APP_SERVER_URL}/workout/template`,
      workoutTemplate
    );

    setNotificationSeverity(response.data.severity);
    setNotificationMessage(response.data.msg);
    setIsNotification(true);
    setInterval(() => setIsNotification(false), 6000);
  };

  const handleWorkoutTemplateDisplay = event => {
    const workoutTemplate = event.target.value;
    setWorkoutName(workoutTemplate.workoutName);
    setSteps(workoutTemplate.steps);
    setWorkoutNotes(workoutTemplate.workoutNotes);
  };

  const clearAllInputFields = () => {
    setWorkoutName('');
    setSteps([
      getWarmupStepTemplate(),
      getNewWorkoutStep('INTERVAL'),
      getNewRepeatStep(),
      getCooldownStepTemplate()
    ]);
    setWorkoutNotes('');
    setTrigger(!trigger);
  };

  const displayWorkoutTemplate = workoutTemplate => {
    setWorkoutName(
      workoutTemplate[0]?.workoutName || workoutTemplate.workoutName
    );
    setSteps(workoutTemplate[0]?.steps || workoutTemplate.steps);
    setWorkoutNotes(
      workoutTemplate[0]?.workoutNotes || workoutTemplate.workoutNotes
    );
  };

  const changeDate = day => {
    clearAllInputFields();
    const newWeeklyWorkoutsPlan = weeklyWorkoutsPlan.map(item => {
      if (isSameDate(item.dateObject, day.dateObject)) {
        item.isActive = true;
      } else {
        item.isActive = false;
      }
      return item;
    });
    if (day.workoutTemplate) displayWorkoutTemplate(day.workoutTemplate);

    setActiveDateObject(day.dateObject);
    setWeeklyWorkoutsPlan(newWeeklyWorkoutsPlan);
  };

  const handlePreviousWeek = () => {
    const previousWeekStartDate = getPreviousWeekStartDate(startWeekDate);
    setActiveDateObject(previousWeekStartDate);
    setStartWeekDate(previousWeekStartDate);
  };

  const handleNextWeek = () => {
    const nextWeekStartDate = getNextWeekStartDate(startWeekDate);
    setActiveDateObject(nextWeekStartDate);
    setStartWeekDate(nextWeekStartDate);
  };

  const handleSelectedDateFromCalendar = startWeekDate => {
    setLoading(true);
    setActiveDateObject(startWeekDate);
    setStartWeekDate(startWeekDate);

    setTimeout(() => {
      setLoading(false);
    }, 1400);
  };

  const saveWorkoutToPlan = async () => {
    const workoutPlanTemplate = {};
    const workoutTemplate = prepareWorkoutTemplate();
    workoutPlanTemplate.userEmail = user.email;
    workoutPlanTemplate.dateObject = activeDateObject;
    workoutPlanTemplate.workoutTemplate = workoutTemplate;
    workoutPlanTemplate.workoutTemplate.sport = 'RUNNING';
    workoutPlanTemplate.subGroup = selectedSubgroup;

    const response = await axios.post(
      `${process.env.REACT_APP_SERVER_URL}/workout/toPlanTemplate`,
      workoutPlanTemplate
    );

    setNotificationSeverity(response.data.severity);
    setNotificationMessage(response.data.msg);
    setIsNotification(true);
    setInterval(() => setIsNotification(false), 4000);
  };

  const handleSaveWeeklyWorkoutsPlan = async () => {
    await saveWorkoutToPlan();
    const newWeeklyWorkoutsPlan = weeklyWorkoutsPlan.map(workout => {
      if (isSameDate(workout.dateObject, activeDateObject)) {
        workout.isWorkout = true;
        workout.workoutTemplate = prepareWorkoutTemplate();
      }
      return workout;
    });
    setWeeklyWorkoutsPlan(newWeeklyWorkoutsPlan);
  };

  const handlePreviewWeeklyWorkoutsPlan = async () => {
    handleModalOpen();
  };

  const removeWorkoutFromPlanTemplate = async () => {
    const response = await axios.post(
      `${process.env.REACT_APP_SERVER_URL}/workout/removeFromPlanTemplate`,
      { userEmail: user.email, activeDateObject }
    );

    setNotificationSeverity(response.data.severity);
    setNotificationMessage(response.data.msg);
    setIsNotification(true);
    setInterval(() => setIsNotification(false), 4000);
  };

  const handleRemoveWeeklyWorkoutFromPlan = async () => {
    await removeWorkoutFromPlanTemplate();
    clearAllInputFields();
    const newWeeklyWorkoutsPlan = weeklyWorkoutsPlan.map(workout => {
      if (isSameDate(workout.dateObject, activeDateObject)) {
        workout.isWorkout = false;
        workout.workoutTemplate = null;
      }
      return workout;
    });
    setWeeklyWorkoutsPlan(newWeeklyWorkoutsPlan);
  };

  const [isModalOpen, setIsModalOpen] = React.useState(false);

  const handleModalOpen = () => {
    setIsModalOpen(true);
  };

  const handleModalClose = () => {
    setIsModalOpen(false);
  };

  const [runnersList, setRunnersList] = React.useState();
  useEffect(() => {
    const getActiveRunnersList = async () => {
      const payload =
        user.role == 'trainer'
          ? { trainerUserId: user._id, isActive: true }
          : { runnerId: user._id, isActive: true };

      const runnersList = await axios.post(
        `${process.env.REACT_APP_SERVER_URL}/runners`,
        payload
      );
      const activeRunnersList = runnersList.data.filter(
        runner => runner.isActive && runner.subGroup === selectedSubgroup
      );
      setRunnersList(activeRunnersList);
    };
    getActiveRunnersList();
  }, [selectedSubgroup]);

  // Handling Sub groups
  const handleAddSubgroup = async () => {
    const payload = user.role == 'trainer' && { trainerUserId: user._id };
    if (user.role == 'trainer') {
      const response = await axios.patch(
        `${process.env.REACT_APP_SERVER_URL}/createSubgroup`,
        {
          id: payload.trainerUserId,
          subgroup: newSubgroupName
        }
      );
      setSubgroups(prevSubgroups => {
        const updatedSubgroups = [...prevSubgroups, newSubgroupName];
        return updatedSubgroups;
      });
      setSubgroupModalOpen(false);
      setNewSubgroupName('');
    }
  };

  const handleDeleteConfirmation = async subgroup => {
    const payload = user.role == 'trainer' && { trainerUserId: user._id };
    if (user.role == 'trainer') {
      const response = await axios.patch(
        `${process.env.REACT_APP_SERVER_URL}/removeSubgroup`,
        {
          id: payload.trainerUserId,
          subgroup: subgroup
        }
      );
      setSelectedSubgroup(response.data.updatedTrainer.subGroup);
      setSubgroups(prevSubgroups =>
        prevSubgroups.filter(item => item !== subgroupToDelete)
      );
      setDeleteConfirmationOpen(false);
    }
  };

  useEffect(() => {
    const fetchSubGroups = async () => {
      const payload = user.role == 'trainer' && { trainerUserId: user._id };
      const trainerUserId = payload.trainerUserId;
      const response = await axios.post(
        `${process.env.REACT_APP_SERVER_URL}/getSubgroups`,
        { trainerUserId }
      );
      // Need to change it and make sure every trainer has at least General subgroup in their subgroups when created
      // and that you cannot delete this subgroup
      setSubgroups(['General', ...response.data.subGroups]);
    };

    fetchSubGroups();
  }, []);

  const handleClick = event => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const handleSubgroupChange = subgroup => {
    setSelectedSubgroup(subgroup);
    handleClose();
  };

  const handleCloseSubgroupModal = () => {
    setSubgroupModalOpen(false);
    setNewSubgroupName('');
  };

  const handleOpenSubgroupModal = () => {
    setSubgroupModalOpen(true);
  };

  const handleRemoveSubgroup = subgroup => {
    setSubgroupToDelete(subgroup);
    setDeleteConfirmationOpen(true);
  };

  const handleCloseDeleteConfirmation = () => {
    setDeleteConfirmationOpen(false);
    setSubgroupToDelete('');
  };

  return (
    <main className={classes.content}>
      <LoadingScreen open={loading} />
      <SubGroup
        onSubgroupChange={handleSubgroupChange}
        selectedSubgroup={selectedSubgroup}
        anchorEl={anchorEl}
        subgroups={subgroups}
        setNewSubgroupName={setNewSubgroupName}
        onHandleClick={handleClick}
        onHandleAddSubgroup={handleAddSubgroup}
        onHandleClose={handleClose}
        newSubgroupName={newSubgroupName}
        onHandleCloseSubgroupModal={handleCloseSubgroupModal}
        onHandleDeleteConfirmation={handleDeleteConfirmation}
        subgroupModalOpen={subgroupModalOpen}
        onHandleOpenSubgroupModal={handleOpenSubgroupModal}
        deleteConfirmationOpen={deleteConfirmationOpen}
        subgroupToDelete={subgroupToDelete}
        onHandleRemoveSubgroup={handleRemoveSubgroup}
        onHandleCloseDeleteConfirmation={handleCloseDeleteConfirmation}
      />
      <WeekCalendar
        changeDate={changeDate}
        handleNextWeek={handleNextWeek}
        handlePreviousWeek={handlePreviousWeek}
        handleSelectedDateFromCalendar={handleSelectedDateFromCalendar}
        highlightedDate={workoutsPlanTemplate}
        weekDays={weeklyWorkoutsPlan}
      />
      <Typography
        className={classes.subTitle}
        data-test="createWorkout-title"
        variant="h3">
        Create a workout
      </Typography>
      <WorkoutTemplateSelection
        handleWorkoutTemplateDisplay={handleWorkoutTemplateDisplay}
        user={user}
        selectedSubgroup={selectedSubgroup}
      />
      <Grid container spacing={2}>
        <Grid item sm={4} xs={12}>
          <TextField
            InputLabelProps={{
              // className: classes.priamryTextColor,
              style: { fontWeight: 'bold' }
            }}
            InputProps={
              {
                // className: classes.priamryTextColor,
                // style: { fontWeight: 'bold' }
              }
            }
            className={classes.textField}
            id="workoutName"
            label={workoutName ? '' : 'Workout name'}
            margin="dense"
            onChange={handleWorkoutNameChange}
            value={workoutName}
            variant="outlined"
          />
        </Grid>
      </Grid>
      <div className={classes.buttons}>
        <Button
          className={`${classes.button} ${classes.fit_button} ${classes.btn_margin}`}
          onClick={addWarmUp}
          variant="contained">
          <TrendingUpOutlinedIcon className={classes.iconButton} />
          Add Warm Up
        </Button>

        <Button
          className={`${classes.button} ${classes.fit_button} ${classes.btn_margin}`}
          onClick={addRepeatStep}
          variant="contained">
          <RepeatIcon className={classes.iconButton} />
          Add repeat
        </Button>

        <Button
          className={`${classes.button} ${classes.fit_button} ${classes.btn_margin}`}
          onClick={addWorkoutStep}
          variant="contained">
          <AddOutlinedIcon className={classes.iconButton} />
          Add step
        </Button>

        <Button
          className={`${classes.button} ${classes.fit_button}`}
          onClick={addCoolDown}
          variant="contained">
          <TrendingDownOutlinedIcon className={classes.iconButton} />
          Add Cool Down
        </Button>
      </div>
      {steps.map((step, index) => {
        if (step.type == 'WorkoutStep')
          return (
            <WorkoutStepTemplate
              key={index}
              name={step.name}
              removeStep={removeStep}
              step={step}
              trigger={trigger}
            />
          );
        if (step.type == 'WorkoutRepeatStep')
          return (
            <RepeatStep
              key={index}
              removeStep={removeStep}
              step={step}
              trigger={trigger}
            />
          );
      })}
      <div className={classes.mTop3}>
        <Typography className={classes.box_title} variant="h6">
          Notes
        </Typography>
        <TextareaAutosize
          aria-label="minimum height"
          className={classes.textArea}
          id="workoutNotes"
          minRows={4}
          onChange={handleWorkoutNotesChange}
          placeholder=""
          value={workoutNotes}
        />
      </div>
      <div>
        <Button
          className={classes.button}
          onClick={handleSaveWorkoutTemplate}
          data-test="createWorkout-saveWorkoutAsATemplateButton"
          variant="contained">
          Save workout as a template
        </Button>
        {/* <br /> */}
        <div className={classes.cancel_save_buttons}>
          <Button
            className={`${classes.button} ${classes.fit_button} ${classes.btn_margin} ${classes.btn_remove}`}
            onClick={handleRemoveWeeklyWorkoutFromPlan}
            data-test="createWorkout-removeButton"
            variant="contained">
            Remove
          </Button>
          <Button
            className={`${classes.button} ${classes.fit_button}`}
            onClick={handleSaveWeeklyWorkoutsPlan}
            data-test="createWorkout-saveButton">
            Save
          </Button>
        </div>
        <Button
          className={classes.button}
          onClick={handlePreviewWeeklyWorkoutsPlan}
          data-test="createWorkout-previewWeeklyWorkoutsButton"
          variant="contained">
          Preview Weekly Workouts
        </Button>
      </div>
      <WeeklyPlanPreviewModal
        handleModalClose={handleModalClose}
        isModalOpen={isModalOpen}
        runnersList={runnersList}
        user={user}
        weeklyWorkoutTemplatesPlan={weeklyWorkoutsPlan}
        selectedSubgroup={selectedSubgroup}
        handleRemoveWeeklyWorkoutFromPlan={handleRemoveWeeklyWorkoutFromPlan}
      />
      {isNotification && (
        <SnackbarNotification
          isActive
          message={notificationMessage}
          severity={notificationSeverity}
        />
      )}
    </main>
  );
}

export default CreateWorkout;
