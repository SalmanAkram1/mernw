import {
  Button,
  Dialog,
  DialogContent,
  DialogTitle,
  Divider,
  IconButton,
  Menu,
  MenuItem,
  TextField,
  makeStyles
} from '@material-ui/core';
import AddIcon from '@material-ui/icons/Add';
import ArrowDropDownIcon from '@material-ui/icons/ArrowDropDown';
import DeleteIcon from '@material-ui/icons/Delete';

const useStyles = makeStyles(theme => ({
  subgroupTextField: {
    width: '290px'
  },
  subGroupContainer: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    width: '100%',
    height: '100%',
    background: theme.palette.common.white,
    '&:hover': {
      background: '#F5F5F5'
    }
  },
  addSubGroupModel: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    height: '70px',
    gap: '10px',
    paddingBottom: '30px',
    overflow: 'hidden'
  },

  addSubGroupModelDelete: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    height: '80px',
    gap: '10px'
  },
  divider: {
    margin: theme.spacing(2, 0),
    borderBottom: '1px solid #BABABA'
  },

  addSubGroupBtn: {
    fontWeight: 700,
    color: theme.palette.primary.main,
    paddingBlock: '12px',
    background: 'none',
    width: '100%'
  }
}));

const SubGroup = ({
  selectedSubgroup,
  subgroups,
  onSubgroupChange,
  anchorEl,
  onHandleClick,
  onHandleClose,
  onHandleAddSubgroup,
  newSubgroupName,
  onHandleCloseSubgroupModal,
  subgroupModalOpen,
  deleteConfirmationOpen,
  subgroupToDelete,
  onHandleRemoveSubgroup,
  onHandleCloseDeleteConfirmation,
  onHandleDeleteConfirmation,
  onHandleOpenSubgroupModal,
  setNewSubgroupName,
}) => {
  const classes = useStyles();
  return (
    <div>
      <TextField className={classes.subgroupTextField} onClick={onHandleClick} value={selectedSubgroup}  margin='dense' id="outlined-basic"
        label="Sub Group" variant="outlined"
        InputProps={{
        readOnly: true,
        endAdornment: (
            <ArrowDropDownIcon />
          ),
        }}
      />
        <Menu
          style={{height: '500px', top: '54px' }}
          anchorEl={anchorEl}
          keepMounted
          open={Boolean(anchorEl)}
          onClose={onHandleClose}
          >      
          {subgroups && subgroups.map((subgroup, index) => (
            <div className={classes.subGroupContainer} key={index}>
              <MenuItem
                style={{ background: 'none', cursor: 'auto' }}
                onClick={() => onSubgroupChange(subgroup)}>
                {subgroup}
              </MenuItem>
              <IconButton onClick={() => onHandleRemoveSubgroup(subgroup)}>
                <DeleteIcon />
              </IconButton>
            </div>
          ))}
        <Divider className={classes.divider} />
        <div className={classes.addSubGroupBtnContainer}>
          <MenuItem
            style={{ width: '278px' }}
            className={classes.addSubGroupBtn}
            onClick={onHandleOpenSubgroupModal}>
            Add Subgroup
            <AddIcon style={{ marginLeft: 'auto', marginRight: '6px' }} />
          </MenuItem>
        </div>
      </Menu>

      {/* Subgroup Modal */}
      <Dialog open={subgroupModalOpen} onClose={onHandleCloseSubgroupModal}>
        <DialogTitle>Add Sub-Group</DialogTitle>
        <DialogContent className={classes.addSubGroupModel}>
          <TextField
            className={classes.addSubGroupField}
            variant="outlined"
            value={newSubgroupName}
            onChange={e => setNewSubgroupName(e.target.value)}
            InputProps={{
              style: {
                height: '35px',
                padding: '8px'
              }
            }}
          />
          <Button onClick={onHandleAddSubgroup}>Add</Button>
        </DialogContent>
      </Dialog>

      <Dialog
        open={deleteConfirmationOpen}
        onClose={onHandleCloseDeleteConfirmation}>
        <DialogTitle>{`Are you sure to delete ${subgroupToDelete}?`}</DialogTitle>
        <DialogContent className={classes.addSubGroupModelDelete}>
          {/* You can add additional content or styling for the confirmation dialog */}
          <Button onClick={() => onHandleDeleteConfirmation(subgroupToDelete)}>Confirm</Button>
          <Button onClick={onHandleCloseDeleteConfirmation}>Cancel</Button>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default SubGroup;
