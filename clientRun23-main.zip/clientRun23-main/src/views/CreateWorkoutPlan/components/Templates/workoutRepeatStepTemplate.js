import getNewWorkoutStep from './workoutStepTemplate';

export default (repeatValue = null) => ({
  type: 'WorkoutRepeatStep',
  stepOrder: null,
  repeatType: 'REPEAT_UNTIL_STEPS_CMPLT',
  repeatValue,
  steps: [getNewWorkoutStep('INTERVAL'), getNewWorkoutStep('RECOVERY')]
});
