export default (workoutName, subGroup, description = null) => ({
  workoutName,
  description,
  sport: 'RUNNING',
  steps: [],
  subGroup
});
