import React, { useState, useEffect } from 'react';
import { makeStyles } from '@material-ui/core/styles';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
import InputLabel from '@material-ui/core/InputLabel';
import MenuItem from '@material-ui/core/MenuItem';
import { Grid } from '@material-ui/core';
import axios from 'axios';

const useStyles = makeStyles(theme => {
  return {
    menu: {
      borderRadius: '4px'
    },
    menuText: {
      fontWeight: 'bold'
    }
  };
});

function WorkoutTemplateSelection(props) {
  const { user, handleWorkoutTemplateDisplay, selectedSubgroup } = props;
  const classes = useStyles();
  const [workoutTemplates, setWorkoutTemplates] = useState('');

    const fetchWorkoutTemplates = async () => {
        const response = await axios.post(
          `${process.env.REACT_APP_SERVER_URL}/workout/templatesFromDB`,
          { ...user }
        );
        return response.data.workoutTemplates;
    };

    const filterWorkoutTemplates = (templates, subgroup) => {
      return templates.filter(obj => obj.subGroup === subgroup);
    };

    useEffect(() => {
      const fetchData = async () => {
        const templatesFromDB = await fetchWorkoutTemplates();
        const filteredTemplates = filterWorkoutTemplates(
          templatesFromDB,
          selectedSubgroup
        );
        setWorkoutTemplates(filteredTemplates);
      };

      fetchData();
    }, [user.email, selectedSubgroup]);
  return (
    <Grid container spacing={2}>
      <Grid item xs={12} sm={4}>
        <FormControl
          variant="outlined"
          disabled={!workoutTemplates.length}
          className={classes.menu}
          fullWidth>
          <InputLabel
            id="select-workout-template"
            margin="dense"
            className={classes.menuText}>
            {workoutTemplates.length
              ? 'Select from existing workout templates'
              : 'No templates. Please create some'}
          </InputLabel>
          <Select
            data-test={'workoutTemplateSelection-select'}
            labelId="workoutTemplateSelection-select"
            id="workoutTemplateSelection-select"
            // value={workout}
            value={''}
            label="Select from existing workout template"
            margin="dense"
            onChange={handleWorkoutTemplateDisplay}>
            {workoutTemplates.length ? (
              workoutTemplates.map(workoutTemplate => (
                <MenuItem
                  data-test={'workoutTemplateSelection-menuItem'}
                  key={workoutTemplate._id}
                  value={workoutTemplate}>
                  {workoutTemplate.workoutName}
                </MenuItem>
              ))
            ) : (
              <MenuItem value={0}>No available templates</MenuItem>
            )}
          </Select>
        </FormControl>
      </Grid>
    </Grid>
  );
}

export default WorkoutTemplateSelection;
