import React from 'react';
import { makeStyles } from '@material-ui/styles';
import { Grid, Paper } from '@material-ui/core';
import CssBaseline from '@material-ui/core/CssBaseline';
import CreateWorkout from './components/CreateWorkout';

const useStyles = makeStyles(theme => ({
  root: {
    margin: theme.spacing(2)
  }
}));

const CreateWorkoutPlan = props => {
  const { user } = props;
  const classes = useStyles();

  return (
    <Paper className={classes.root} square>
      <Grid container spacing={2}>
        <Grid item lg={12} sm={12} xl={12} xs={12}>
          <CssBaseline />
          <CreateWorkout user={user} />
        </Grid>
      </Grid>
    </Paper>
  );
};

export default CreateWorkoutPlan;
