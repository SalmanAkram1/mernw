export { default as AccountView } from './Account';
export { default as CreateWorkoutPlanView } from './CreateWorkoutPlan';
export { default as DashboardView } from './Dashboard';
export { default as HomeView } from './Home';
export { default as IconsView } from './Icons';
export { default as NotFoundView } from './NotFound';
export { default as PrivacyView } from './Privacy';
export { default as ProductListView } from './ProductList';
export { default as RecoverPasswordView } from './RecoverPassword';
export { default as RunnersListView } from './RunnersList';
export { default as SettingsView } from './Settings';
export { default as SignInView } from './SignIn';
export { default as SignUpView } from './SignUp';
export { default as TemplateDashboardView } from './TemplateDashboard';
export { default as TypographyView } from './Typography';
export { default as UserListView } from './UserList';
export { default as WorkoutPlanView } from './WorkoutPlan';

