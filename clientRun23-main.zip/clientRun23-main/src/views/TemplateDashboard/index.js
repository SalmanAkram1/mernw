export { default } from './TemplateDashboard';
