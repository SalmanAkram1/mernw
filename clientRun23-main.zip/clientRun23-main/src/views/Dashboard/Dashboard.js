import React, { useState } from 'react';
import Grid from '@material-ui/core/Grid';
import Paper from '@material-ui/core/Paper';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import DayView from './components/DayView/DayView';
import WeekView from './components/WeekView/WeekView';

const Dashboard = props => {
  const { user } = props;

  const [value, setValue] = useState(0);

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  return (
    <>
      <Paper square>
        <Tabs
          indicatorColor="primary"
          onChange={handleChange}
          textColor="primary"
          value={value}>
          <Tab label="Week View" />
          <Tab label="Day View" />
        </Tabs>
      </Paper>
      <Grid container spacing={4}>
        <Grid item lg={12} sm={12} xl={12} xs={12}>
          {value ? <DayView user={user} /> : <WeekView user={user} />}
        </Grid>
      </Grid>
    </>
  );
};

export default Dashboard;
