import React from 'react';
import { size } from 'underscore';

const PricingSection = () => {
  const [isMonth, setIsMonth] = React.useState(true);

  const handleMonthlyClick = () => setIsMonth(true);
  const handleYearlyClick = () => setIsMonth(false);

  return (
    <section id="pricing" className="pricing-section pt-30 pb-30">
      <div className="container">
        <div className="row justify-content-center">
          <div className="col-xxl-8 col-xl-8 col-lg-8 col-md-9">
            <div className="section-title text-center mb-30">
              <h2 className="wow fadeInUp" data-wow-delay=".2s">
                Choose a Plan
              </h2>
              <h3>
                During our test-run period, all the services of Sub-X will be
                <b> free of charge</b>. Enjoy it!
              </h3>
              {/* <h4>We are confident in the value SubX provides.</h4>
              <h5>
                We will not charge you for the first 60 days and you can cancel
                anytime. If you contiue using the service, we will charge from
                the date of registration.
              </h5> */}
            </div>
          </div>
        </div>
        <div className="pricing-nav-wrapper mb-20">
          <ul className="nav nav-pills" id="pills-tab" role="tablist">
            <li role="presentation">
              <a
                onClick={handleMonthlyClick}
                className={isMonth ? 'active' : ''}
                style={{ cursor: 'pointer' }}
                id="pills-month-tab"
                data-bs-toggle="pill"
                // href="#pills-month"
                role="tab"
                aria-controls="pills-month"
                aria-selected="true">
                Monthly
              </a>
            </li>
            <li role="presentation">
              <a
                className={isMonth ? '' : 'active'}
                onClick={handleYearlyClick}
                id="pills-year-tab"
                data-bs-toggle="pill"
                // href="#pills-year"
                role="tab"
                style={{ cursor: 'pointer' }}
                aria-controls="pills-year"
                aria-selected="false">
                Yearly
              </a>
            </li>
          </ul>
        </div>
        <div className="tab-content" id="pills-tabContent">
          <div
            className="tab-pane fade show active"
            id="pills-month"
            role="tabpanel"
            aria-labelledby="pills-month-tab">
            <div className="row justify-content-center">
              <div className="col-lg-4 col-md-8 col-sm-10">
                <div className="single-pricing">
                  <div className="pricing-header">
                    {isMonth ? (
                      <h1 className="price">
                        <s>$9.99</s>
                      </h1>
                    ) : (
                      <h1 className="price">
                        <s>
                          <s style={{ color: 'lightGrey' }}>$120</s> $100
                        </s>
                      </h1>
                    )}
                    <h3 className="package-name">Basic Account</h3>
                  </div>
                  <div className="content">
                    <ul>
                      <li>
                        <i className="lni lni-checkmark active"></i>
                        All Capabilities & Features
                      </li>
                      <li>
                        <i className="lni lni-checkmark active"></i>
                        Up To 20 trainees
                      </li>
                      <li>
                        <i className="lni lni-checkmark active"></i>
                        Single Trainer Per Group
                      </li>
                      <li>
                        <i className="lni lni-checkmark active"></i>
                        Your Own Workouts
                      </li>
                      <li>
                        <i className="lni lni-checkmark active"></i>
                        Community Support
                      </li>
                    </ul>
                  </div>
                  <div className="pricing-btn">
                    <a
                      onClick={() => (window.location.href = '/sign-up')}
                      // href="/sign-up"
                      className="main-btn btn-hover border-btn">
                      Get Started
                    </a>
                  </div>
                </div>
              </div>
              <div className="col-lg-4 col-md-8 col-sm-10">
                <div className="single-pricing">
                  <div className="pricing-header">
                    {isMonth ? (
                      <h1 className="price">
                        <s>$19.99</s>
                      </h1>
                    ) : (
                      <h1 className="price">
                        <s>
                          <s style={{ color: 'lightGrey' }}>$220</s> $200
                        </s>
                      </h1>
                    )}
                    <h3 className="package-name">Business Account</h3>
                  </div>
                  <div className="content">
                    <ul>
                      <li>
                        <i className="lni lni-checkmark active"></i>
                        Everything In Basic
                      </li>
                      <li>
                        <i className="lni lni-checkmark active"></i>
                        Up To 75 Trainees
                      </li>
                      <li>
                        <i className="lni lni-checkmark active"></i>
                        Single Trainer Per Group
                      </li>
                      <li>
                        <i className="lni lni-checkmark active"></i>
                        +100 Ready Workouts
                      </li>
                      <li>
                        <i className="lni lni-checkmark active"></i>
                        Email Support
                      </li>
                    </ul>
                  </div>
                  <div className="pricing-btn">
                    <a
                      onClick={() => (window.location.href = '/sign-up')}
                      // href="/sign-up"
                      className="main-btn btn-hover">
                      Get Started
                    </a>
                  </div>
                </div>
              </div>
              <div className="col-lg-4 col-md-8 col-sm-10">
                <div className="single-pricing">
                  <div className="pricing-header">
                    <h1 className="price">$</h1>
                    <h3 className="package-name">Enterprise Account</h3>
                  </div>
                  <div className="content">
                    <ul>
                      <li>
                        <i className="lni lni-question-circle active"></i>
                        Need something else?
                      </li>
                      <li>
                        <i className="lni lni-information active"></i>
                        We are right here
                      </li>
                      <li>
                        <i className="lni lni-thumbs-up active"></i>
                        Cotact us and let's discuss:
                      </li>
                      <li>
                        <i className="lni lni-envelope active"></i>
                        sales@sub.cx
                      </li>
                      <li>
                        <i className="lni lni-whatsapp active"></i>
                        +972-54-8312543
                      </li>
                    </ul>
                  </div>
                  <div className="pricing-btn">
                    <a
                      onClick={() => {
                        console.log('ENTERPRIZE');
                        window.location.href =
                          'mailto:sales@sub.cx?subject=A query regarding your Enterprize Account';
                      }}
                      className="main-btn btn-hover border-btn">
                      Contact Us
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          {/* <div
            className="tab-pane fade"
            id="pills-year"
            role="tabpanel"
            aria-labelledby="pills-year-tab">
            <div className="row justify-content-center">
              <div className="col-lg-4 col-md-8 col-sm-10">
                <div className="single-pricing">
                  <div className="pricing-header">
                    <h1 className="price">$136</h1>
                    <h3 className="package-name">Basic Account</h3>
                  </div>
                  <div className="content">
                    <ul>
                      <li>
                        <i className="lni lni-checkmark active"></i>
                        Unlimited Acces
                      </li>
                      <li>
                        <i className="lni lni-checkmark active"></i>
                        Single User
                      </li>
                      <li>
                        <i className="lni lni-checkmark active"></i>
                        Unlimited Storage
                      </li>
                      <li>
                        <i className="lni lni-close"></i>
                        24/7 Support
                      </li>
                      <li>
                        <i className="lni lni-close"></i>
                        Free Future Updates
                      </li>
                    </ul>
                  </div>
                  <div className="pricing-btn">
                    <a href="#" className="main-btn btn-hover border-btn">
                      Get Start
                    </a>
                  </div>
                </div>
              </div>
              <div className="col-lg-4 col-md-8 col-sm-10">
                <div className="single-pricing">
                  <div className="pricing-header">
                    <h1 className="price">$156</h1>
                    <h3 className="package-name">Standard Account</h3>
                  </div>
                  <div className="content">
                    <ul>
                      <li>
                        <i className="lni lni-checkmark active"></i>
                        Unlimited Acces
                      </li>
                      <li>
                        <i className="lni lni-checkmark active"></i>
                        20+ Users
                      </li>
                      <li>
                        <i className="lni lni-checkmark active"></i>
                        Unlimited Storage
                      </li>
                      <li>
                        <i className="lni lni-checkmark active"></i>
                        24/7 Support
                      </li>
                      <li>
                        <i className="lni lni-close"></i> Free Future Updates
                      </li>
                    </ul>
                  </div>
                  <div className="pricing-btn">
                    <a href="#" className="main-btn btn-hover">
                      Get Start
                    </a>
                  </div>
                </div>
              </div>
              <div className="col-lg-4 col-md-8 col-sm-10">
                <div className="single-pricing">
                  <div className="pricing-header">
                    <h1 className="price">$189</h1>
                    <h3 className="package-name">Premium Account</h3>
                  </div>
                  <div className="content">
                    <ul>
                      <li>
                        <i className="lni lni-checkmark active"></i>
                        Unlimited Acces
                      </li>
                      <li>
                        <i className="lni lni-checkmark active"></i>
                        Unlimited Users
                      </li>
                      <li>
                        <i className="lni lni-checkmark active"></i> U nlimited
                        Storage
                      </li>
                      <li>
                        <i className="lni lni-checkmark active"></i>
                        24/7 Support
                      </li>
                      <li>
                        <i className="lni lni-checkmark active"></i>
                        Free Future Updates
                      </li>
                    </ul>
                  </div>
                  <div className="pricing-btn">
                    <a href="#" className="main-btn btn-hover border-btn">
                      Get Start
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div> */}
        </div>
      </div>
    </section>
  );
};

export default PricingSection;
