// import { useState, useEffect } from 'react';
// import axios from 'api/axios';
import axios from 'axios';

const sortRunnersByActive = runners => {
  runners.sort((a, b) => {
    if (a.isActive && !b.isActive) {
      return -1; // a is active, b is inactive - a should come first
    } else if (!a.isActive && b.isActive) {
      return 1; // a is inactive, b is active - b should come first
    }
    return 0; // both runners have the same isActive status - maintain the order
  });

  return runners;
};

// const useGetRunners = () => {
//   const [loading, setLoading] = useState(false);
//   const [error, setError] = useState({ isError: false, message: '' });
//   const [runners, setRunners] = useState([]);

//   useEffect(() => {
//     const getRunners = async () => {
//       setLoading(true);
//       try {
//         const response = await axios.post(
//           `${process.env.REACT_APP_SERVER_URL}/runners`
//         );

//         //Add calculated pace total in seconds to array. Need for sorting
//         const runners = response.data.map(runner => {
//           return {
//             ...runner,
//             pace:
//               (runner.basePace?.minutes * 60 || 0) +
//               (runner.basePace?.seconds || 0)
//           };
//         });

//         const sortedRunnersByActive = sortRunnersByActive(runners);
//         setRunners(sortedRunnersByActive);
//         setLoading(false);
//       } catch (error) {
//         console.error(error);
//         setError({
//           isError: true,
//           message: error.message || 'Could not fetch'
//         });
//         setLoading(false);
//       }
//     };
//     getRunners();
//   }, []);

//   return { loading, error, runnersList: runners };
// };

const useGetRunners = async () => {
  const response = await axios.post(
    `${process.env.REACT_APP_SERVER_URL}/runners`
  );

  //Add calculated pace total in seconds to array. Need for sorting
  const runners = response.data.map(runner => {
    return {
      ...runner,
      pace:
        (runner.basePace?.minutes * 60 || 0) + (runner.basePace?.seconds || 0)
    };
  });

  const sortedRunnersByActive = sortRunnersByActive(runners);
  return sortedRunnersByActive;
};

export default useGetRunners;
