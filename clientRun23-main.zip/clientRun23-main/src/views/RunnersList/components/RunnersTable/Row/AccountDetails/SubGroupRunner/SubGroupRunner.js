import {
  Button,
  Dialog,
  DialogContent,
  DialogTitle,
  Divider,
  IconButton,
  Menu,
  MenuItem,
  TextField,
  makeStyles
} from '@material-ui/core';
import AddIcon from '@material-ui/icons/Add';
import ArrowDropDownIcon from '@material-ui/icons/ArrowDropDown';
import DeleteIcon from '@material-ui/icons/Delete';
import { useState } from 'react';

const useStyles = makeStyles(theme => ({
  subGroupContainer: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    width: '100%',
    height: '100%',
    background: theme.palette.common.white,
    '&:hover': {
      background: '#F5F5F5'
    }
  },
  dropdownContainer: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    width: '270px',
    height: '44px',
    border: '1px solid #BABABA',
    padding: '3px 10px',
    borderRadius: '4px'
  },
  subGroupText: {
    paddingLeft: '5px',
    paddingBottom: theme.spacing(1),
    color: theme.palette.primary.main,
    fontWeight: 500
  },
  dropdownIcon: {
    cursor: 'pointer',
    paddingRight: '8px'
  },
  addSubGroupModel: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    height: '70px',
    gap: '10px',
    paddingBottom: '30px',
    overflow: 'hidden'
  },

  addSubGroupModelDelete: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    height: '80px',
    gap: '10px'
  },
  divider: {
    margin: theme.spacing(2, 0),
    borderBottom: '1px solid #BABABA'
  },

  addSubGroupBtn: {
    fontWeight: 700,
    color: theme.palette.primary.main,
    paddingBlock: '12px',
    background: 'none',
    width: '100%'
  }
}));

const SubGroupRunner = ({
  subgroups,
  selectedSubgroup,
  newSubgroupName,
  subgroupModalOpen,
  setSelectedSubgroup,
  setNewSubgroupName,
  subgroupToDelete,
  deleteConfirmationOpen,
  anchorEl,
  values,
  onHandleClick,
  onHandleClose,
  onHandleSubgroupChange,
  onHandleAddSubgroup,
  onHandleCloseSubgroupModal,
  onHandleOpenSubgroupModal,
  onHandleDeleteConfirmation,
  onHandleCloseConfirmation,
  onHandleRemoveSubgroup
}) => {
  const classes = useStyles();
  return (
    <>
      <TextField
        onClick={onHandleClick}
        value={values.subGroup}
        fullWidth
        margin="dense"
        id="outlined-basic"
        label="Sub Group"
        data-test="subGroup-textField"
        variant="outlined"
        InputProps={{
          readOnly: true,
          endAdornment: <ArrowDropDownIcon />
        }}
      />
      <Menu
        style={{ height: '430px' }}
        anchorEl={anchorEl}
        keepMounted
        open={Boolean(anchorEl)}
        onClose={onHandleClose}
        // anchorOrigin={{
        //   vertical: 'bottom',
        //   horizontal: 'right',
        // }}
        // transformOrigin={{
        //   vertical: 'top',
        //   horizontal: 'right',
        // }}
      >
        {subgroups.map((subGroup, index) => (
          <div className={classes.subGroupContainer} key={index}>
            <MenuItem
              data-test={
                subGroup === 'General' ? 'subGroupRunner-selectGeneral' : ''
              }
              style={{ background: 'none', cursor: 'auto' }}
              onClick={() => onHandleSubgroupChange(subGroup)}>
              {subGroup}
            </MenuItem>
            <IconButton onClick={() => onHandleRemoveSubgroup(subGroup)}>
              <DeleteIcon />
            </IconButton>
          </div>
        ))}
        <Divider className={classes.divider} />
        <div className={classes.addSubGroupBtnContainer}>
          <MenuItem
            style={{ width: '300px' }}
            className={classes.addSubGroupBtn}
            onClick={onHandleOpenSubgroupModal}>
            Add Sub-Group
            <AddIcon style={{ marginLeft: 'auto', marginRight: '6px' }} />
          </MenuItem>
        </div>
      </Menu>

      {/* Subgroup Modal */}
      <Dialog open={subgroupModalOpen} onClose={onHandleCloseSubgroupModal}>
        <DialogTitle>Add Sub-Group</DialogTitle>
        <DialogContent className={classes.addSubGroupModel}>
          <TextField
            className={classes.addSubGroupField}
            variant="outlined"
            value={newSubgroupName}
            onChange={e => setNewSubgroupName(e.target.value)}
            InputProps={{
              style: {
                height: '35px',
                padding: '8px'
              }
            }}
          />
          <Button onClick={onHandleAddSubgroup}>Add</Button>
        </DialogContent>
      </Dialog>

      <Dialog open={deleteConfirmationOpen} onClose={onHandleCloseConfirmation}>
        <DialogTitle>{`Are you sure you want to delete ${subgroupToDelete}?`}</DialogTitle>
        <DialogContent className={classes.addSubGroupModelDelete}>
          <Button onClick={onHandleDeleteConfirmation}>Confirm</Button>
          <Button onClick={onHandleCloseConfirmation}>Cancel</Button>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default SubGroupRunner;
