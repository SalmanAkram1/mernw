import React from 'react';
import RunnersTable from './components/RunnersTable';
import { useTheme } from '@material-ui/core/styles';
import useMediaQuery from '@material-ui/core/useMediaQuery';
import {
  Box,
  Button,
  IconButton,
  Paper,
  TablePagination,
  Typography
} from '@material-ui/core';
import { AddCircleOutline } from '@material-ui/icons';
import { makeStyles } from '@material-ui/styles';

const useStyles = makeStyles(theme => ({
  root: {
    // margin: theme.spacing(2),
    [theme.breakpoints.up('md')]: {
      padding: theme.spacing(2)
    }
  },
  paper: {
    brderRadius: '4px'
  },
  header: {
    [theme.breakpoints.up('md')]: {
      justifyContent: 'space-between',
      paddingBottom: theme.spacing(5)
    },
    display: 'flex',
    justifyContent: 'center',
    padding: theme.spacing(2),
    paddingTop: theme.spacing(4),
    position: 'relative'
  },
  title: {
    [theme.breakpoints.down('sm')]: {
      padding: theme.spacing(2)
    }
  },
  addRunnerIconWrapper: {
    position: 'absolute',
    right: theme.spacing(2),
    top: theme.spacing(4),
    fontSize: '2rem'
  },
  addRunnerIcon: {
    fontSize: '2rem'
  },
  addRunnerBtn: {
    textTransform: 'none'
  }
}));

const RunnersList = props => {
  const { user } = props;

  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  const classes = useStyles();

  const [newRunnerTrigger, setNewRunnerTrigger] = React.useState(false);

  const handleAddRunner = () => {
    setNewRunnerTrigger(true);
  };

  return (
    <Box className={classes.root}>
      <Paper className={classes.paper}>
        <Box className={classes.header}>
          <Typography className={classes.title} variant="h3">
            Runners List
          </Typography>
          {isMobile ? (
            <IconButton
              className={classes.addRunnerIconWrapper}
              onClick={handleAddRunner}>
              <AddCircleOutline className={classes.addRunnerIcon} />
            </IconButton>
          ) : (
            <Button
              className={classes.addRunnerBtn}
              color="primary"
              variant="contained"
              onClick={handleAddRunner}>
              + Add Runner
            </Button>
          )}
        </Box>
        <RunnersTable
          user={user}
          newRunnerTrigger={newRunnerTrigger}
          setNewRunnerTrigger={setNewRunnerTrigger}
        />
      </Paper>
    </Box>
  );
};

export default RunnersList;
