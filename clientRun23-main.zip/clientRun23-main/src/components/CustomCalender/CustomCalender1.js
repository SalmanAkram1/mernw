import DateFnsUtils from '@date-io/date-fns';
import { Dialog, DialogContent, Tooltip, createTheme } from '@material-ui/core';
import CloseIcon from '@material-ui/icons/Close';
import { DatePicker, MuiPickersUtilsProvider } from '@material-ui/pickers';
import { ThemeProvider } from '@material-ui/styles';
import { startOfWeek } from 'date-fns';
import React, { useEffect, useState } from 'react';
const materialTheme = createTheme({
  overrides: {
    MuiPickersToolbar: {
      toolbar: {
        backgroundColor: '#3F51B5'
      }
    },
    MuiPickersCalendarHeader: {
      switchHeader: {
        backgroundColor: 'white',
        color: '#3F51B5'
      }
    }
  }
});

const useStyles = makeStyles(theme => ({
  backdrop: {
    zIndex: theme.zIndex.drawer + 1,
    color: '#fff'
  }
}));

import Backdrop from '@material-ui/core/Backdrop';
import { makeStyles } from '@material-ui/core/styles';

const formatDate = isoDate => {
  const dateObj = new Date(isoDate);
  // const formattedDate = format(dateObj, 'EEE MMM dd yyyy HH:mm:ss \'GMT\'xxx (zzzz)', { timeZone: 'Asia/Dhaka' });
  return dateObj;
};

export default function CustomCalendar({
  open,
  onClose,
  weekData,
  handleSelectedDateFromCalender,
  higlightedDates,
  specificDate,
  setSpecificDate
}) {
  const getMonthOfTheWeek = () => {
    if (weekData.length > 0) {
      const minDate = new Date(
        Math.min(...weekData.map(day => day.dateObject.getTime()))
      );
      setSelectedDate(new Date(minDate.getFullYear(), minDate.getMonth(), 1));
    }
  };
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [startDateOfWeek, setStartWeekDate] = useState(new Date());

  useEffect(() => {
    if (weekData.length > 0) {
      const minDate = new Date(
        Math.min(...weekData.map(day => day.dateObject.getTime()))
      );
      console.log('sp: ');
      console.log(minDate.getDate());
      setSelectedDate(
        new Date(
          minDate.getFullYear(),
          minDate.getMonth(),
          specificDate.getDate() || minDate.getDate()
        )
      );
    }
  }, [weekData]);

  const t = higlightedDates.map(h => formatDate(h.dateObject));

  const isDayHighlighted = date => {
    return t.some(day => day.toDateString() === date.toDateString());
  };
  const getStartOfWeek = date => {
    return startOfWeek(date, { weekStartsOn: 0 }); // 1 for Monday, adjust as needed
  };

  const onSelectDate = date => {
    setSpecificDate(date);
    setSelectedDate(date);
    const startOfWeek = getStartOfWeek(date);
    setStartWeekDate(startOfWeek);
    handleSelectedDateFromCalender(startOfWeek);
  };

  const handleOnCalenderClose = () => {
    onClose();
  };

  return (
    <div>
      <Dialog onClose={handleOnCalenderClose} open={open}>
        <Tooltip
          arrow
          data-testid="close-calender"
          onClick={handleOnCalenderClose}
          placement="top"
          style={{ margin: '8 8 8 auto', cursor: 'pointer' }}
          title="Close Calendar">
          <CloseIcon fontSize="medium" />
        </Tooltip>

        <DialogContent>
          <MuiPickersUtilsProvider utils={DateFnsUtils}>
            <ThemeProvider theme={materialTheme}>
              <DatePicker
                onChange={onSelectDate}
                renderDay={(
                  date,
                  _selectedDate,
                  dayInCurrentMonth,
                  dayComponent
                ) => {
                  const isHighlighted =
                    isDayHighlighted(date) && dayInCurrentMonth;
                  // const isHighlighted = date.isWorkout
                  return React.cloneElement(dayComponent, {
                    style: isHighlighted
                      ? { textDecoration: 'underline 2px' }
                      : {}
                  });
                }}
                value={selectedDate}
                variant="static"
              />
            </ThemeProvider>
          </MuiPickersUtilsProvider>
        </DialogContent>
      </Dialog>
    </div>
  );
}
