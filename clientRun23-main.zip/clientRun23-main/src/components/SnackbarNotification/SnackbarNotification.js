import React, { useState } from 'react';
import { Snackbar } from '@material-ui/core';
import Alert from '../Alert';

function SnackbarNotification(props) {
  const { isActive, severity, message } = props;

  const [open, setOpen] = useState(isActive);
  const handleClose = (event, reason) => {
    if (reason === 'clickaway') {
      return;
    }

    setOpen(false);
  };

  return (
    <Snackbar
      anchorOrigin={{ vertical: 'bottom', horizontal: 'left' }}
      autoHideDuration={5000}
      onClose={handleClose}
      open={open}>
      <Alert onClose={handleClose} severity={severity}>
        {message}
      </Alert>
    </Snackbar>
  );
}

export default SnackbarNotification;
