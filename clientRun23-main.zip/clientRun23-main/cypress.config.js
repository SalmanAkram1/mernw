/* eslint-disable import/no-extraneous-dependencies */
const { defineConfig } = require('cypress');
const dotenv = require('dotenv').config();

module.exports = defineConfig({
  numTestsKeptInMemory: 15,
  defaultCommandTimeout: 15000,
  userAgent:
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.190 Safari/537.36',

  e2e: {
    baseUrl: dotenv.parsed.BASE_URL,
    backend: dotenv.parsed.BACKEND_URL,
    loginRequest: dotenv.parsed.LOGIN_REQUEST,
    signUp: dotenv.parsed.SIGNUP,
    login: dotenv.parsed.LOGIN,
    token: dotenv.parsed.TOKEN,
    experimentalRunAllSpecs: true,
    chromeWebSecurity: false,
    module: true
  }
});
